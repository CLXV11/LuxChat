/**
 * SQLite database setup using built-in node:sqlite (Node 24).
 * All schema initialization happens here on startup.
 */
import { DatabaseSync } from "node:sqlite";
import path from "node:path";
import fs from "node:fs";

const workspaceRoot = process.cwd().endsWith(
  path.join("artifacts", "api-server"),
)
  ? path.resolve(process.cwd(), "../..")
  : process.cwd();

const dataDir = path.resolve(workspaceRoot, "artifacts/api-server/data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.resolve(dataDir, "luxchat.db");
export const db = new DatabaseSync(dbPath);

db.exec("PRAGMA journal_mode = WAL;");
db.exec("PRAGMA foreign_keys = ON;");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id        TEXT PRIMARY KEY,
    username  TEXT UNIQUE NOT NULL,
    password  TEXT NOT NULL,
    displayName TEXT NOT NULL,
    avatar    TEXT,
    coverBanner TEXT,
    bio       TEXT DEFAULT '',
    coins     INTEGER DEFAULT 100,
    joinedAt  TEXT NOT NULL,
    isVerified INTEGER DEFAULT 0,
    title     TEXT,
    theme     TEXT DEFAULT 'default',
    profileBorder TEXT,
    couplePartnerId TEXT
  );

  CREATE TABLE IF NOT EXISTS messages (
    id        TEXT PRIMARY KEY,
    roomId    TEXT NOT NULL,
    senderId  TEXT NOT NULL,
    content   TEXT,
    type      TEXT DEFAULT 'text',
    mediaUrl  TEXT,
    reactions TEXT DEFAULT '{}',
    createdAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS friendships (
    id        TEXT PRIMARY KEY,
    userId    TEXT NOT NULL,
    friendId  TEXT NOT NULL,
    status    TEXT DEFAULT 'pending',
    createdAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS couple_requests (
    id          TEXT PRIMARY KEY,
    fromUserId  TEXT NOT NULL,
    toUserId    TEXT NOT NULL,
    status      TEXT DEFAULT 'pending',
    createdAt   TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS promo_usages (
    id      TEXT PRIMARY KEY,
    userId  TEXT NOT NULL,
    code    TEXT NOT NULL,
    usedAt  TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS follows (
    followerId  TEXT NOT NULL,
    followingId TEXT NOT NULL,
    createdAt   TEXT DEFAULT (datetime('now')),
    PRIMARY KEY (followerId, followingId)
  );

  CREATE TABLE IF NOT EXISTS posts (
    id        TEXT PRIMARY KEY,
    userId    TEXT NOT NULL,
    imageUrl  TEXT,
    caption   TEXT DEFAULT '',
    createdAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS post_likes (
    postId  TEXT NOT NULL,
    userId  TEXT NOT NULL,
    PRIMARY KEY (postId, userId)
  );

  CREATE TABLE IF NOT EXISTS comments (
    id        TEXT PRIMARY KEY,
    postId    TEXT NOT NULL,
    userId    TEXT NOT NULL,
    content   TEXT NOT NULL,
    createdAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS reports (
    id TEXT PRIMARY KEY,
    reporterId TEXT NOT NULL,
    recipientId TEXT,
    message TEXT NOT NULL,
    createdAt TEXT NOT NULL,
    status TEXT DEFAULT 'new'
  );
`);

// Migrate existing tables with new columns — ignore if already present
const alterStatements = [
  "ALTER TABLE users ADD COLUMN followersBoost INTEGER DEFAULT 0",
  "ALTER TABLE users ADD COLUMN isAdmin INTEGER DEFAULT 0",
  "ALTER TABLE users ADD COLUMN goldBadge INTEGER DEFAULT 0",
  "ALTER TABLE users ADD COLUMN isDeveloper INTEGER DEFAULT 0",
  "ALTER TABLE messages ADD COLUMN replyToId TEXT",
  "ALTER TABLE messages ADD COLUMN editedAt TEXT",
  "ALTER TABLE messages ADD COLUMN deletedForAll INTEGER DEFAULT 0",
];
for (const stmt of alterStatements) {
  try { db.exec(stmt); } catch { /* already exists */ }
}

// Keep the privileged developer identity and remove retired store privileges.
// This is intentionally normalized on every startup so deleted store badges
// cannot reappear from stale database rows.
db.prepare(`
  UPDATE users SET
    isVerified = CASE WHEN LOWER(username) = 'fadi' THEN 1 ELSE 0 END,
    isDeveloper = CASE WHEN LOWER(username) = 'fadi' THEN 1 ELSE 0 END,
    isAdmin = CASE WHEN LOWER(username) = 'fadi' THEN 1 ELSE 0 END,
    coins = 0,
    followersBoost = 0,
    goldBadge = 0,
    title = NULL,
    theme = 'default',
    profileBorder = NULL
`).run();

/** Generate a unique short ID */
export function genId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 9);
}
