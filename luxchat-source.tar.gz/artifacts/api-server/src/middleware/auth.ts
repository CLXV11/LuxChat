/**
 * JWT authentication middleware.
 * Verifies Bearer token from Authorization header and attaches user to req.
 */
import type { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

// Use a stable hardcoded secret so tokens remain valid across server restarts.
// SESSION_SECRET is intentionally NOT used here — it rotates and would invalidate all sessions.
const JWT_SECRET = "luxchat-jwt-stable-v1-2026";

export interface JwtPayload {
  userId: string;
  username: string;
}

// Extend Express Request with user info
declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

/** Sign a JWT token for a user */
export function signToken(payload: JwtPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "30d" });
}

/** Middleware: require valid JWT */
export function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const token = authHeader.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET) as JwtPayload;
    req.user = payload;
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}

/** Verify a token string (for socket.io handshake) */
export function verifyToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JwtPayload;
  } catch {
    return null;
  }
}
