import type { Request, Response, NextFunction } from "express";
import { db } from "../db/index.js";

/**
 * Hidden developer gate.
 * The identity is tied to the database account, not a client-side flag.
 */
export function requireDeveloper(req: Request, res: Response, next: NextFunction): void {
  const userId = req.user?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const developer = db
    .prepare("SELECT username, isDeveloper, isVerified FROM users WHERE id = ?")
    .get(userId) as { username: string; isDeveloper: number; isVerified: number } | undefined;

  if (!developer || !developer.isDeveloper || !developer.isVerified || developer.username.toLowerCase() !== "fadi") {
    res.status(403).json({ error: "Developer access required" });
    return;
  }

  next();
}