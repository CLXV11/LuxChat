/**
 * Entry point — creates HTTP server, attaches Socket.io, and starts listening.
 */
import http from "node:http";
import app from "./app.js";
import { setupSocket } from "./socket/index.js";
import { logger } from "./lib/logger.js";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error("PORT environment variable is required but was not provided.");
}

const port = Number(rawPort);
if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// Create HTTP server from Express app so Socket.io can share the same port
const httpServer = http.createServer(app);
setupSocket(httpServer);

httpServer.listen(port, () => {
  logger.info({ port }, "LuxChat server listening");
});
