/**
 * Auth routes: register + login.
 */
import { Router } from "express";
import bcrypt from "bcryptjs";
import { db, genId } from "../db/index.js";
import { signToken } from "../middleware/auth.js";

const router = Router();

// POST /api/auth/register
router.post("/register", (req, res) => {
  const { username, password, displayName } = req.body as {
    username: string;
    password: string;
    displayName: string;
  };

  if (!username || !password || !displayName) {
    res.status(400).json({ error: "All fields are required" });
    return;
  }
  if (username.length < 3) {
    res.status(400).json({ error: "Username must be at least 3 characters" });
    return;
  }
  if (password.length < 6) {
    res.status(400).json({ error: "Password must be at least 6 characters" });
    return;
  }

  // Check username uniqueness
  const existing = db
    .prepare("SELECT id FROM users WHERE username = ?")
    .get(username);
  if (existing) {
    res.status(409).json({ error: "Username already taken" });
    return;
  }

  const hashedPassword = bcrypt.hashSync(password, 10);
  const id = genId();
  const joinedAt = new Date().toISOString();

  db.prepare(
    `INSERT INTO users (id, username, password, displayName, coins, joinedAt)
     VALUES (?, ?, ?, ?, 0, ?)`,
  ).run(id, username.toLowerCase(), hashedPassword, displayName, joinedAt);

  const token = signToken({ userId: id, username: username.toLowerCase() });
  res.status(201).json({
    token,
    user: {
      id,
      username: username.toLowerCase(),
      displayName,
      avatar: null,
      coverBanner: null,
      bio: "",
       coins: 0,
      joinedAt,
      isVerified: false,
      isAdmin: false,
      isDeveloper: false,
      title: null,
      theme: "default",
      profileBorder: null,
      couplePartnerId: null,
    },
  });
});

// POST /api/auth/login
router.post("/login", (req, res) => {
  const { username, password } = req.body as {
    username: string;
    password: string;
  };

  if (!username || !password) {
    res.status(400).json({ error: "Username and password are required" });
    return;
  }

  const user = db
    .prepare("SELECT * FROM users WHERE username = ?")
    .get(username.toLowerCase()) as Record<string, unknown> | undefined;

  if (!user || !bcrypt.compareSync(password, user["password"] as string)) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const token = signToken({
    userId: user["id"] as string,
    username: user["username"] as string,
  });

  res.json({
    token,
    user: {
      id: user["id"],
      username: user["username"],
      displayName: user["displayName"],
      avatar: user["avatar"],
      coverBanner: user["coverBanner"],
      bio: user["bio"],
      coins: user["coins"],
      joinedAt: user["joinedAt"],
      isVerified: !!user["isVerified"],
      isAdmin: !!user["isAdmin"],
      isDeveloper: !!user["isDeveloper"],
      title: user["title"],
      theme: user["theme"],
      profileBorder: user["profileBorder"],
      couplePartnerId: user["couplePartnerId"],
    },
  });
});

export default router;
