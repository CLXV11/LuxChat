/**
 * Couple / partnership system routes.
 * Allows two users to link as a "Couple" with a heart badge.
 */
import { Router } from "express";
import { db, genId } from "../db/index.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

// GET /api/couple — get current couple status
router.get("/", requireAuth, (req, res) => {
  const userId = req.user!.userId;
  const user = db
    .prepare("SELECT couplePartnerId FROM users WHERE id = ?")
    .get(userId) as { couplePartnerId: string | null } | undefined;

  if (!user?.couplePartnerId) {
    // Check for pending outgoing requests
    const outgoing = db
      .prepare(
        "SELECT * FROM couple_requests WHERE fromUserId = ? AND status = 'pending'",
      )
      .get(userId) as Record<string, unknown> | undefined;

    // Check for pending incoming requests
    const incoming = db
      .prepare(
        "SELECT * FROM couple_requests WHERE toUserId = ? AND status = 'pending'",
      )
      .get(userId) as Record<string, unknown> | undefined;

    res.json({
      status: "single",
      outgoing: outgoing ?? null,
      incoming: incoming ?? null,
    });
    return;
  }

  const partner = db
    .prepare(
      "SELECT id, username, displayName, avatar, isVerified, title FROM users WHERE id = ?",
    )
    .get(user.couplePartnerId) as Record<string, unknown> | undefined;

  res.json({
    status: "coupled",
    partner: partner
      ? {
          id: partner["id"],
          username: partner["username"],
          displayName: partner["displayName"],
          avatar: partner["avatar"],
          isVerified: !!partner["isVerified"],
          title: partner["title"],
        }
      : null,
  });
});

// POST /api/couple/request — send couple request
router.post("/request", requireAuth, (req, res) => {
  const { toUserId } = req.body as { toUserId: string };
  const fromUserId = req.user!.userId;

  if (toUserId === fromUserId) {
    res.status(400).json({ error: "Cannot couple with yourself" });
    return;
  }

  // Check both users are single
  const fromUser = db
    .prepare("SELECT couplePartnerId FROM users WHERE id = ?")
    .get(fromUserId) as { couplePartnerId: string | null } | undefined;
  const toUser = db
    .prepare("SELECT couplePartnerId FROM users WHERE id = ?")
    .get(toUserId) as { couplePartnerId: string | null } | undefined;

  if (fromUser?.couplePartnerId) {
    res.status(409).json({ error: "You are already in a couple" });
    return;
  }
  if (toUser?.couplePartnerId) {
    res.status(409).json({ error: "That user is already in a couple" });
    return;
  }

  // Check existing pending request
  const existing = db
    .prepare(
      `SELECT id FROM couple_requests WHERE
       ((fromUserId = ? AND toUserId = ?) OR (fromUserId = ? AND toUserId = ?))
       AND status = 'pending'`,
    )
    .get(fromUserId, toUserId, toUserId, fromUserId);

  if (existing) {
    res.status(409).json({ error: "Request already exists" });
    return;
  }

  const id = genId();
  db.prepare(
    "INSERT INTO couple_requests (id, fromUserId, toUserId, status, createdAt) VALUES (?, ?, ?, 'pending', ?)",
  ).run(id, fromUserId, toUserId, new Date().toISOString());

  res.status(201).json({ requestId: id });
});

// PUT /api/couple/:id/accept — accept couple request
router.put("/:id/accept", requireAuth, (req, res) => {
  const requestId = req.params["id"] as string;
  const request = db
    .prepare("SELECT * FROM couple_requests WHERE id = ?")
    .get(requestId) as Record<string, unknown> | undefined;

  if (!request || request["toUserId"] !== req.user!.userId) {
    res.status(404).json({ error: "Request not found or not authorized" });
    return;
  }

  const fromUserId = request["fromUserId"] as string;
  const toUserId = request["toUserId"] as string;

  // Update couple status for both users
  db.prepare("UPDATE users SET couplePartnerId = ? WHERE id = ?").run(
    toUserId,
    fromUserId,
  );
  db.prepare("UPDATE users SET couplePartnerId = ? WHERE id = ?").run(
    fromUserId,
    toUserId,
  );
  db.prepare(
    "UPDATE couple_requests SET status = 'accepted' WHERE id = ?",
  ).run(requestId as string);

  res.json({ success: true });
});

// DELETE /api/couple — break up
router.delete("/", requireAuth, (req, res) => {
  const userId = req.user!.userId;
  const user = db
    .prepare("SELECT couplePartnerId FROM users WHERE id = ?")
    .get(userId) as { couplePartnerId: string | null } | undefined;

  if (!user?.couplePartnerId) {
    res.status(400).json({ error: "Not in a couple" });
    return;
  }

  const partnerId = user.couplePartnerId;
  db.prepare("UPDATE users SET couplePartnerId = NULL WHERE id = ?").run(userId);
  db.prepare("UPDATE users SET couplePartnerId = NULL WHERE id = ?").run(partnerId);

  res.json({ success: true });
});

export default router;
