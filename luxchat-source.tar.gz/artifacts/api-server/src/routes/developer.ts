/**
 * Hidden developer controls. Mounted only behind authentication + developer gate.
 */
import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "../db/index.js";
import { requireAuth } from "../middleware/auth.js";
import { requireDeveloper } from "../middleware/developer.js";

const router = Router();
const backupCode = process.env["DEVELOPER_BACKUP_CODE"] || process.env["SESSION_SECRET"];

router.use(requireAuth, requireDeveloper);

router.get("/users", (_req, res) => {
  const users = db.prepare(`
    SELECT id, username, displayName, avatar, isVerified, isAdmin,
           isDeveloper, coins, title, theme, profileBorder, joinedAt
    FROM users ORDER BY joinedAt DESC
  `).all() as Record<string, unknown>[];
  res.json(users.map((u) => ({
    id: u["id"],
    username: u["username"],
    displayName: u["displayName"],
    avatar: u["avatar"],
    isVerified: !!u["isVerified"],
    isAdmin: !!u["isAdmin"],
    isDeveloper: !!u["isDeveloper"],
    coins: u["coins"] ?? 0,
    title: u["title"],
    theme: u["theme"],
    profileBorder: u["profileBorder"],
    joinedAt: u["joinedAt"],
  })));
});

router.post("/users/:id/verification", (req, res) => {
  const targetId = req.params["id"] as string;
  const enabled = Boolean((req.body as { enabled?: boolean }).enabled);
  const target = db.prepare("SELECT id, username FROM users WHERE id = ?").get(targetId) as { id: string; username: string } | undefined;
  if (!target) { res.status(404).json({ error: "User not found / المستخدم غير موجود" }); return; }
  db.prepare("UPDATE users SET isVerified = ? WHERE id = ?").run(enabled ? 1 : 0, targetId);
  res.json({ success: true, userId: targetId, isVerified: enabled });
});

router.post("/users/:id/reset-password", (req, res) => {
  const targetId = req.params["id"] as string;
  const { newPassword, code } = req.body as { newPassword?: string; code?: string };
  if (!backupCode || !code || code !== backupCode) {
    res.status(403).json({ error: "Invalid backup code / رمز الاحتياط غير صحيح" });
    return;
  }
  if (!newPassword || newPassword.length < 6) {
    res.status(400).json({ error: "Password must be at least 6 characters / كلمة المرور 6 أحرف على الأقل" });
    return;
  }
  const target = db.prepare("SELECT id FROM users WHERE id = ?").get(targetId);
  if (!target) { res.status(404).json({ error: "User not found / المستخدم غير موجود" }); return; }
  db.prepare("UPDATE users SET password = ? WHERE id = ?").run(bcrypt.hashSync(newPassword, 12), targetId);
  res.json({ success: true, message: "Password reset successfully / تم تغيير كلمة المرور بنجاح" });
});

router.delete("/users/:id", (req, res) => {
  const targetId = req.params["id"] as string;
  if (targetId === req.user!.userId) {
    res.status(400).json({ error: "Developer account cannot be deleted" });
    return;
  }
  const target = db.prepare("SELECT id FROM users WHERE id = ?").get(targetId);
  if (!target) { res.status(404).json({ error: "User not found / المستخدم غير موجود" }); return; }

  db.prepare("DELETE FROM post_likes WHERE userId = ?").run(targetId);
  db.prepare("DELETE FROM comments WHERE userId = ?").run(targetId);
  db.prepare("DELETE FROM posts WHERE userId = ?").run(targetId);
  db.prepare("DELETE FROM messages WHERE senderId = ?").run(targetId);
  db.prepare("DELETE FROM follows WHERE followerId = ? OR followingId = ?").run(targetId, targetId);
  db.prepare("DELETE FROM friendships WHERE userId = ? OR friendId = ?").run(targetId, targetId);
  db.prepare("DELETE FROM users WHERE id = ?").run(targetId);
  res.json({ success: true });
});

router.delete("/posts/:id", (req, res) => {
  const postId = req.params["id"] as string;
  const post = db.prepare("SELECT id FROM posts WHERE id = ?").get(postId);
  if (!post) { res.status(404).json({ error: "Post not found / المنشور غير موجود" }); return; }
  db.prepare("DELETE FROM post_likes WHERE postId = ?").run(postId);
  db.prepare("DELETE FROM comments WHERE postId = ?").run(postId);
  db.prepare("DELETE FROM posts WHERE id = ?").run(postId);
  res.json({ success: true });
});

export default router;