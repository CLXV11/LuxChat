/**
 * Coins routes: get balance, redeem promo codes.
 */
import { Router } from "express";
import { db, genId } from "../db/index.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

type PromoReward =
  | { type: "coins"; amount: number }
  | { type: "followers"; amount: number }
  | { type: "border"; value: string }
  | { type: "admin" }
  | { type: "goldBadge" };

const PROMO_CODES: Record<string, PromoReward> = {
  DEVMASTER999: { type: "coins", amount: 99999999 },
  LUXCHAT100:   { type: "coins", amount: 100 },
  GOLD1000:     { type: "coins", amount: 1000 },
  SPECIAL1200:  { type: "coins", amount: 1200 },
  VIP5000:      { type: "coins", amount: 5000 },
  LUCKY500:     { type: "coins", amount: 500 },
  BONUS2000:    { type: "coins", amount: 2000 },
  ROYAL3000:    { type: "coins", amount: 3000 },
  SECRET750:    { type: "coins", amount: 750 },
  DIAMOND8888:  { type: "coins", amount: 8888 },
  // Special codes
  "123654":     { type: "followers", amount: 100000 },
  "654321":     { type: "goldBadge" },
  FGR:          { type: "border", value: "profile_border_dragon_gold" },
  LUXADMIN2026: { type: "admin" },
};

// GET /api/coins — get current coin balance
router.get("/", requireAuth, (req, res) => {
  const user = db.prepare("SELECT coins FROM users WHERE id = ?").get(req.user!.userId) as { coins: number } | undefined;
  res.json({ coins: user?.coins ?? 0 });
});

// POST /api/coins/redeem — redeem a promo code
router.post("/redeem", requireAuth, (req, res) => {
  const { code } = req.body as { code: string };
  if (!code) { res.status(400).json({ error: "Code is required" }); return; }

  const upperCode = code.toUpperCase().trim();
  const reward = PROMO_CODES[upperCode] ?? PROMO_CODES[code.trim()];
  if (!reward) { res.status(400).json({ error: "Invalid promo code" }); return; }

  const codeKey = upperCode;
  const existing = db.prepare("SELECT id FROM promo_usages WHERE userId = ? AND code = ?").get(req.user!.userId, codeKey);
  if (existing) { res.status(409).json({ error: "You have already used this code" }); return; }

  db.prepare("INSERT INTO promo_usages (id, userId, code, usedAt) VALUES (?, ?, ?, ?)")
    .run(genId(), req.user!.userId, codeKey, new Date().toISOString());

  if (reward.type === "coins") {
    db.prepare("UPDATE users SET coins = coins + ? WHERE id = ?").run(reward.amount, req.user!.userId);
    const updatedUser = db.prepare("SELECT coins FROM users WHERE id = ?").get(req.user!.userId) as { coins: number };
    res.json({ type: "coins", reward: reward.amount, newBalance: updatedUser.coins });

  } else if (reward.type === "followers") {
    db.prepare("UPDATE users SET followersBoost = followersBoost + ? WHERE id = ?").run(reward.amount, req.user!.userId);
    res.json({ type: "followers", reward: reward.amount, newFollowers: reward.amount });

  } else if (reward.type === "border") {
    db.prepare("UPDATE users SET profileBorder = ? WHERE id = ?").run(reward.value, req.user!.userId);
    res.json({ type: "border", reward: 0, newBorder: reward.value, newBalance: 0 });

  } else if (reward.type === "admin") {
    db.prepare("UPDATE users SET isAdmin = 1 WHERE id = ?").run(req.user!.userId);
    res.json({ type: "admin", reward: 0, message: "Admin access granted!" });

  } else if (reward.type === "goldBadge") {
    db.prepare("UPDATE users SET goldBadge = 1 WHERE id = ?").run(req.user!.userId);
    res.json({ type: "goldBadge", reward: 0, message: "🏅 Gold Seal Badge unlocked!" });
  }
});

export default router;
