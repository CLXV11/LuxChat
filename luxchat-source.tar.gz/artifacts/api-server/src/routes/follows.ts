/**
 * Follow routes: follow/unfollow, stats, followers/following lists.
 */
import { Router } from "express";
import { db } from "../db/index.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

function formatUserBasic(u: Record<string, unknown>) {
  return {
    id: u["id"],
    username: u["username"],
    displayName: u["displayName"],
    avatar: u["avatar"],
    isVerified: !!u["isVerified"],
    isAdmin: !!u["isAdmin"],
    title: u["title"],
    profileBorder: u["profileBorder"],
  };
}

// GET /api/follows/me/stats — own follower stats
router.get("/me/stats", requireAuth, (req, res) => {
  const myId = req.user!.userId;

  const followersCount = (db.prepare("SELECT COUNT(*) as cnt FROM follows WHERE followingId = ?").get(myId) as { cnt: number }).cnt;
  const followingCount = (db.prepare("SELECT COUNT(*) as cnt FROM follows WHERE followerId = ?").get(myId) as { cnt: number }).cnt;

  res.json({
    followers: followersCount,
    following: followingCount,
  });
});

// GET /api/follows/me/followers — list of my followers
router.get("/me/followers", requireAuth, (req, res) => {
  const myId = req.user!.userId;
  const rows = db
    .prepare(`SELECT u.* FROM users u INNER JOIN follows f ON f.followerId = u.id WHERE f.followingId = ? ORDER BY f.createdAt DESC LIMIT 100`)
    .all(myId) as Record<string, unknown>[];
  res.json(rows.map(formatUserBasic));
});

// GET /api/follows/me/following — list of people I follow
router.get("/me/following", requireAuth, (req, res) => {
  const myId = req.user!.userId;
  const rows = db
    .prepare(`SELECT u.* FROM users u INNER JOIN follows f ON f.followingId = u.id WHERE f.followerId = ? ORDER BY f.createdAt DESC LIMIT 100`)
    .all(myId) as Record<string, unknown>[];
  res.json(rows.map(formatUserBasic));
});

// POST /api/follows/:id — follow a user
router.post("/:id", requireAuth, (req, res) => {
  const targetId = req.params["id"] as string;
  const myId = req.user!.userId;

  if (targetId === myId) { res.status(400).json({ error: "Cannot follow yourself" }); return; }

  const target = db.prepare("SELECT id FROM users WHERE id = ?").get(targetId);
  if (!target) { res.status(404).json({ error: "User not found" }); return; }

  try {
    db.prepare("INSERT OR IGNORE INTO follows (followerId, followingId) VALUES (?, ?)").run(myId, targetId);
  } catch {}

  const followersCount = (db.prepare("SELECT COUNT(*) as cnt FROM follows WHERE followingId = ?").get(targetId) as { cnt: number }).cnt;

  res.json({ success: true, following: true, followersCount });
});

// DELETE /api/follows/:id — unfollow a user
router.delete("/:id", requireAuth, (req, res) => {
  const targetId = req.params["id"] as string;
  db.prepare("DELETE FROM follows WHERE followerId = ? AND followingId = ?").run(req.user!.userId, targetId);

  const followersCount = (db.prepare("SELECT COUNT(*) as cnt FROM follows WHERE followingId = ?").get(targetId) as { cnt: number }).cnt;

  res.json({ success: true, following: false, followersCount });
});

// GET /api/follows/:id/stats — followers/following count + is-following flag
router.get("/:id/stats", requireAuth, (req, res) => {
  const targetId = req.params["id"] as string;
  const myId = req.user!.userId;

  const followersCount = (db.prepare("SELECT COUNT(*) as cnt FROM follows WHERE followingId = ?").get(targetId) as { cnt: number }).cnt;
  const followingCount = (db.prepare("SELECT COUNT(*) as cnt FROM follows WHERE followerId = ?").get(targetId) as { cnt: number }).cnt;
  const isFollowing = !!(db.prepare("SELECT 1 FROM follows WHERE followerId = ? AND followingId = ?").get(myId, targetId));

  res.json({ followers: followersCount, following: followingCount, isFollowing });
});

// GET /api/follows/:id/followers — public: list of followers for any user
router.get("/:id/followers", requireAuth, (req, res) => {
  const targetId = req.params["id"] as string;
  const rows = db
    .prepare(`SELECT u.* FROM users u INNER JOIN follows f ON f.followerId = u.id WHERE f.followingId = ? ORDER BY f.createdAt DESC LIMIT 100`)
    .all(targetId) as Record<string, unknown>[];
  res.json(rows.map(formatUserBasic));
});

// GET /api/follows/:id/following — public: list of people a user follows
router.get("/:id/following", requireAuth, (req, res) => {
  const targetId = req.params["id"] as string;
  const rows = db
    .prepare(`SELECT u.* FROM users u INNER JOIN follows f ON f.followingId = u.id WHERE f.followerId = ? ORDER BY f.createdAt DESC LIMIT 100`)
    .all(targetId) as Record<string, unknown>[];
  res.json(rows.map(formatUserBasic));
});

export default router;
