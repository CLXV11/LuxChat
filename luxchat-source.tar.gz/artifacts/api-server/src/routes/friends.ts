/**
 * Friends system routes.
 */
import { Router } from "express";
import { db, genId } from "../db/index.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

function formatUser(u: Record<string, unknown>) {
  return {
    id: u["id"],
    username: u["username"],
    displayName: u["displayName"],
    avatar: u["avatar"],
    isVerified: !!u["isVerified"],
    title: u["title"],
    profileBorder: u["profileBorder"],
  };
}

// GET /api/friends — get accepted friends + pending requests
router.get("/", requireAuth, (req, res) => {
  const userId = req.user!.userId;

  const friends = db
    .prepare(
      `SELECT u.* FROM users u
       INNER JOIN friendships f ON (f.userId = u.id OR f.friendId = u.id)
       WHERE (f.userId = ? OR f.friendId = ?) AND f.status = 'accepted' AND u.id != ?`,
    )
    .all(userId, userId, userId) as Record<string, unknown>[];

  const incoming = db
    .prepare(
      `SELECT f.id as requestId, u.* FROM users u
       INNER JOIN friendships f ON f.userId = u.id
       WHERE f.friendId = ? AND f.status = 'pending'`,
    )
    .all(userId) as Record<string, unknown>[];

  const outgoing = db
    .prepare(
      `SELECT f.id as requestId, u.* FROM users u
       INNER JOIN friendships f ON f.friendId = u.id
       WHERE f.userId = ? AND f.status = 'pending'`,
    )
    .all(userId) as Record<string, unknown>[];

  res.json({
    // Each friend wrapped as { requestId: null, user: {...} } to match client FriendEntry type
    friends: friends.map((u) => ({ requestId: null, user: formatUser(u) })),
    // incoming/outgoing: { requestId, user: {...} }
    incoming: incoming.map((u) => ({ requestId: u["requestId"], user: formatUser(u) })),
    outgoing: outgoing.map((u) => ({ requestId: u["requestId"], user: formatUser(u) })),
  });
});

// POST /api/friends/request — send friend request
router.post("/request", requireAuth, (req, res) => {
  const { toUserId } = req.body as { toUserId: string };
  const fromUserId = req.user!.userId;

  if (toUserId === fromUserId) {
    res.status(400).json({ error: "Cannot add yourself" });
    return;
  }

  // Check if friendship already exists
  const existing = db
    .prepare(
      `SELECT id FROM friendships WHERE
       (userId = ? AND friendId = ?) OR (userId = ? AND friendId = ?)`,
    )
    .get(fromUserId, toUserId, toUserId, fromUserId);

  if (existing) {
    res.status(409).json({ error: "Request already exists or already friends" });
    return;
  }

  const id = genId();
  db.prepare(
    "INSERT INTO friendships (id, userId, friendId, status, createdAt) VALUES (?, ?, ?, 'pending', ?)",
  ).run(id, fromUserId, toUserId, new Date().toISOString());

  res.status(201).json({ requestId: id });
});

// PUT /api/friends/:id/accept — accept friend request
router.put("/:id/accept", requireAuth, (req, res) => {
  const requestId = req.params["id"] as string;
  const friendship = db
    .prepare("SELECT * FROM friendships WHERE id = ?")
    .get(requestId) as Record<string, unknown> | undefined;

  if (!friendship) {
    res.status(404).json({ error: "Request not found" });
    return;
  }

  if (friendship["friendId"] !== req.user!.userId) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  db.prepare("UPDATE friendships SET status = 'accepted' WHERE id = ?").run(
    requestId as string,
  );
  res.json({ success: true });
});

// DELETE /api/friends/:id — remove friend or reject request
router.delete("/:id", requireAuth, (req, res) => {
  const requestId = req.params["id"] as string;
  const userId = req.user!.userId;

  db.prepare(
    "DELETE FROM friendships WHERE id = ? AND (userId = ? OR friendId = ?)",
  ).run(requestId as string, userId, userId);

  res.json({ success: true });
});

export default router;
