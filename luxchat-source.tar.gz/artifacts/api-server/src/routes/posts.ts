/**
 * Posts routes: create posts with images, get feed, like/unlike, comments.
 */
import { Router } from "express";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import { db, genId } from "../db/index.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

const workspaceRoot = process.cwd().endsWith(path.join("artifacts", "api-server"))
  ? path.resolve(process.cwd(), "../..")
  : process.cwd();

const uploadsDir = path.resolve(workspaceRoot, "artifacts/api-server/uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || ".jpg";
    cb(null, `post-${Date.now()}-${Math.random().toString(36).substring(2, 7)}${ext}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 20 * 1024 * 1024 } });

function formatPost(p: Record<string, unknown>, myId: string) {
  const likesCount = (db.prepare("SELECT COUNT(*) as cnt FROM post_likes WHERE postId = ?").get(p["id"] as string) as { cnt: number }).cnt;
  const isLiked = !!(db.prepare("SELECT 1 FROM post_likes WHERE postId = ? AND userId = ?").get(p["id"] as string, myId));
  const commentsCount = (db.prepare("SELECT COUNT(*) as cnt FROM comments WHERE postId = ?").get(p["id"] as string) as { cnt: number }).cnt;
  const author = db
    .prepare("SELECT id, username, displayName, avatar, isVerified, isAdmin, title, profileBorder FROM users WHERE id = ?")
    .get(p["userId"] as string) as Record<string, unknown> | undefined;

  return {
    id: p["id"],
    imageUrl: p["imageUrl"],
    caption: p["caption"],
    createdAt: p["createdAt"],
    likesCount,
    isLiked,
    commentsCount,
    author: author
      ? {
          id: author["id"],
          username: author["username"],
          displayName: author["displayName"],
          avatar: author["avatar"],
          isVerified: !!author["isVerified"],
          isAdmin: !!author["isAdmin"],
          title: author["title"],
          profileBorder: author["profileBorder"],
        }
      : null,
  };
}

// POST /api/posts — create a new post
router.post("/", requireAuth, upload.single("image"), (req, res) => {
  const { caption } = req.body as { caption?: string };
  const imageUrl = req.file ? `/api/uploads/${req.file.filename}` : null;

  if (!imageUrl && !caption?.trim()) {
    res.status(400).json({ error: "Post must have an image or caption" });
    return;
  }

  const id = genId();
  db.prepare("INSERT INTO posts (id, userId, imageUrl, caption, createdAt) VALUES (?, ?, ?, ?, ?)")
    .run(id, req.user!.userId, imageUrl, caption?.trim() ?? "", new Date().toISOString());

  const post = db.prepare("SELECT * FROM posts WHERE id = ?").get(id) as Record<string, unknown>;
  res.status(201).json(formatPost(post, req.user!.userId));
});

// GET /api/posts/feed — latest posts from all users
router.get("/feed", requireAuth, (req, res) => {
  const posts = db.prepare("SELECT * FROM posts ORDER BY createdAt DESC LIMIT 50").all() as Record<string, unknown>[];
  res.json(posts.map((p) => formatPost(p, req.user!.userId)));
});

// GET /api/posts/user/:id — posts by a specific user
router.get("/user/:id", requireAuth, (req, res) => {
  const posts = db.prepare("SELECT * FROM posts WHERE userId = ? ORDER BY createdAt DESC LIMIT 50").all(req.params["id"] as string) as Record<string, unknown>[];
  res.json(posts.map((p) => formatPost(p, req.user!.userId)));
});

// POST /api/posts/:id/like — toggle like
router.post("/:id/like", requireAuth, (req, res) => {
  const postId = req.params["id"] as string;
  const myId = req.user!.userId;

  const existing = db.prepare("SELECT 1 FROM post_likes WHERE postId = ? AND userId = ?").get(postId, myId);
  if (existing) {
    db.prepare("DELETE FROM post_likes WHERE postId = ? AND userId = ?").run(postId, myId);
  } else {
    db.prepare("INSERT OR IGNORE INTO post_likes (postId, userId) VALUES (?, ?)").run(postId, myId);
  }

  const likesCount = (db.prepare("SELECT COUNT(*) as cnt FROM post_likes WHERE postId = ?").get(postId) as { cnt: number }).cnt;
  res.json({ liked: !existing, likesCount });
});

// DELETE /api/posts/:id — delete own post (or admin)
router.delete("/:id", requireAuth, (req, res) => {
  const postId = req.params["id"] as string;
  const post = db.prepare("SELECT userId FROM posts WHERE id = ?").get(postId) as { userId: string } | undefined;

  if (!post) { res.status(404).json({ error: "Post not found" }); return; }

  const userRow = db.prepare("SELECT isAdmin FROM users WHERE id = ?").get(req.user!.userId) as { isAdmin: number } | undefined;
  const isAdmin = !!userRow?.isAdmin;

  if (post.userId !== req.user!.userId && !isAdmin) {
    res.status(403).json({ error: "Cannot delete another user's post" });
    return;
  }

  db.prepare("DELETE FROM post_likes WHERE postId = ?").run(postId);
  db.prepare("DELETE FROM comments WHERE postId = ?").run(postId);
  db.prepare("DELETE FROM posts WHERE id = ?").run(postId);
  res.json({ success: true });
});

// GET /api/posts/:id/comments — get comments for a post
router.get("/:id/comments", requireAuth, (req, res) => {
  const postId = req.params["id"] as string;
  const rows = db
    .prepare("SELECT c.*, u.username, u.displayName, u.avatar, u.isVerified, u.isAdmin, u.title, u.profileBorder FROM comments c LEFT JOIN users u ON c.userId = u.id WHERE c.postId = ? ORDER BY c.createdAt ASC LIMIT 100")
    .all(postId) as Record<string, unknown>[];

  const comments = rows.map((r) => ({
    id: r["id"],
    postId: r["postId"],
    content: r["content"],
    createdAt: r["createdAt"],
    author: {
      id: r["userId"],
      username: r["username"],
      displayName: r["displayName"],
      avatar: r["avatar"],
      isVerified: !!r["isVerified"],
      isAdmin: !!r["isAdmin"],
      title: r["title"],
      profileBorder: r["profileBorder"],
    },
  }));

  res.json(comments);
});

// POST /api/posts/:id/comments — add a comment
router.post("/:id/comments", requireAuth, (req, res) => {
  const postId = req.params["id"] as string;
  const { content } = req.body as { content?: string };

  if (!content?.trim()) {
    res.status(400).json({ error: "Comment content is required" });
    return;
  }

  const post = db.prepare("SELECT id FROM posts WHERE id = ?").get(postId);
  if (!post) { res.status(404).json({ error: "Post not found" }); return; }

  const id = genId();
  db.prepare("INSERT INTO comments (id, postId, userId, content, createdAt) VALUES (?, ?, ?, ?, ?)")
    .run(id, postId, req.user!.userId, content.trim(), new Date().toISOString());

  const row = db
    .prepare("SELECT c.*, u.username, u.displayName, u.avatar, u.isVerified, u.isAdmin, u.title, u.profileBorder FROM comments c LEFT JOIN users u ON c.userId = u.id WHERE c.id = ?")
    .get(id) as Record<string, unknown>;

  res.status(201).json({
    id: row["id"],
    postId: row["postId"],
    content: row["content"],
    createdAt: row["createdAt"],
    author: {
      id: row["userId"],
      username: row["username"],
      displayName: row["displayName"],
      avatar: row["avatar"],
      isVerified: !!row["isVerified"],
      isAdmin: !!row["isAdmin"],
      title: row["title"],
      profileBorder: row["profileBorder"],
    },
  });
});

// DELETE /api/posts/:id/comments/:commentId
router.delete("/:id/comments/:commentId", requireAuth, (req, res) => {
  const commentId = req.params["commentId"] as string;
  const comment = db.prepare("SELECT userId FROM comments WHERE id = ?").get(commentId) as { userId: string } | undefined;
  if (!comment) { res.status(404).json({ error: "Comment not found" }); return; }

  const userRow = db.prepare("SELECT isAdmin FROM users WHERE id = ?").get(req.user!.userId) as { isAdmin: number } | undefined;
  if (comment.userId !== req.user!.userId && !userRow?.isAdmin) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  db.prepare("DELETE FROM comments WHERE id = ?").run(commentId);
  res.json({ success: true });
});

export default router;
