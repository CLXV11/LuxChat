/**
 * Message routes: get history, reactions, delete, edit.
 * Real-time sending/deleting/editing goes through Socket.io.
 */
import { Router } from "express";
import { db } from "../db/index.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

function enrichMessages(msgs: Record<string, unknown>[]) {
  return msgs.map((m) => {
    const sender = db
      .prepare("SELECT id, username, displayName, avatar, isVerified, isAdmin, goldBadge, title, profileBorder FROM users WHERE id = ?")
      .get(m["senderId"] as string) as Record<string, unknown> | undefined;

    // Fetch reply-to preview
    let replyTo: Record<string, unknown> | null = null;
    if (m["replyToId"]) {
      const replyMsg = db
        .prepare("SELECT id, content, type, senderId FROM messages WHERE id = ?")
        .get(m["replyToId"] as string) as Record<string, unknown> | undefined;
      if (replyMsg) {
        const replySender = db.prepare("SELECT displayName FROM users WHERE id = ?").get(replyMsg["senderId"] as string) as { displayName: string } | undefined;
        replyTo = {
          id: replyMsg["id"],
          content: replyMsg["content"],
          type: replyMsg["type"],
          senderName: replySender?.displayName ?? "Unknown",
        };
      }
    }

    return {
      ...m,
      reactions: JSON.parse((m["reactions"] as string) || "{}"),
      deletedForAll: !!(m["deletedForAll"] as number),
      replyTo,
      sender: sender
        ? {
            id: sender["id"],
            username: sender["username"],
            displayName: sender["displayName"],
            avatar: sender["avatar"],
            isVerified: !!sender["isVerified"],
            isAdmin: !!sender["isAdmin"],
            goldBadge: !!sender["goldBadge"],
            title: sender["title"],
            profileBorder: sender["profileBorder"],
          }
        : null,
    };
  });
}

// GET /api/messages/global — global chat history (excludes deleted)
router.get("/global", requireAuth, (req, res) => {
  const { before } = req.query as { before?: string };
  let msgs: Record<string, unknown>[];
  if (before) {
    msgs = db.prepare(`SELECT * FROM messages WHERE roomId = 'global' AND deletedForAll = 0 AND createdAt < ? ORDER BY createdAt DESC LIMIT 50`).all(before) as Record<string, unknown>[];
  } else {
    msgs = db.prepare(`SELECT * FROM messages WHERE roomId = 'global' AND deletedForAll = 0 ORDER BY createdAt DESC LIMIT 50`).all() as Record<string, unknown>[];
  }
  res.json(enrichMessages(msgs).reverse());
});

// GET /api/messages/room/:roomId — private room history (excludes deleted)
router.get("/room/:roomId", requireAuth, (req, res) => {
  const roomId = req.params["roomId"] as string;
  const { before } = req.query as { before?: string };

  const [u1, u2] = roomId.split("_");
  if (u1 !== req.user!.userId && u2 !== req.user!.userId) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  let msgs: Record<string, unknown>[];
  if (before) {
    msgs = db.prepare(`SELECT * FROM messages WHERE roomId = ? AND deletedForAll = 0 AND createdAt < ? ORDER BY createdAt DESC LIMIT 50`).all(roomId, before) as Record<string, unknown>[];
  } else {
    msgs = db.prepare(`SELECT * FROM messages WHERE roomId = ? AND deletedForAll = 0 ORDER BY createdAt DESC LIMIT 50`).all(roomId) as Record<string, unknown>[];
  }
  res.json(enrichMessages(msgs).reverse());
});

// GET /api/messages/room/:roomId/media — all media (images + videos) in a room
router.get("/room/:roomId/media", requireAuth, (req, res) => {
  const roomId = req.params["roomId"] as string;
  const [u1, u2] = roomId.split("_");
  if (u1 !== req.user!.userId && u2 !== req.user!.userId) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  const msgs = db
    .prepare(`SELECT * FROM messages WHERE roomId = ? AND deletedForAll = 0 AND type IN ('image','video') AND mediaUrl IS NOT NULL ORDER BY createdAt DESC LIMIT 200`)
    .all(roomId) as Record<string, unknown>[];
  res.json(enrichMessages(msgs));
});

// DELETE /api/messages/room/:roomId — delete entire conversation (both sides)
router.delete("/room/:roomId", requireAuth, (req, res) => {
  const roomId = req.params["roomId"] as string;
  const [u1, u2] = roomId.split("_");
  if (u1 !== req.user!.userId && u2 !== req.user!.userId) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  db.prepare("DELETE FROM messages WHERE roomId = ?").run(roomId);
  res.json({ success: true });
});

// POST /api/messages/:id/reaction — toggle emoji reaction
router.post("/:id/reaction", requireAuth, (req, res) => {
  const { emoji } = req.body as { emoji: string };
  const messageId = req.params["id"] as string;

  const msg = db.prepare("SELECT * FROM messages WHERE id = ? AND deletedForAll = 0").get(messageId) as Record<string, unknown> | undefined;
  if (!msg) { res.status(404).json({ error: "Message not found" }); return; }

  const reactions = JSON.parse((msg["reactions"] as string) || "{}") as Record<string, string[]>;
  const users: string[] = reactions[emoji] ?? [];
  const userId = req.user!.userId;

  if (users.includes(userId)) {
    reactions[emoji] = users.filter((u) => u !== userId);
    if (reactions[emoji]!.length === 0) delete reactions[emoji];
  } else {
    reactions[emoji] = [...users, userId];
  }

  db.prepare("UPDATE messages SET reactions = ? WHERE id = ?").run(JSON.stringify(reactions), messageId as string);
  res.json({ reactions });
});

// DELETE /api/messages/:id — delete a message (own or admin)
router.delete("/:id", requireAuth, (req, res) => {
  const messageId = req.params["id"] as string;
  const msg = db.prepare("SELECT senderId, roomId FROM messages WHERE id = ?").get(messageId) as { senderId: string; roomId: string } | undefined;
  if (!msg) { res.status(404).json({ error: "Message not found" }); return; }

  const userRow = db.prepare("SELECT isAdmin FROM users WHERE id = ?").get(req.user!.userId) as { isAdmin: number } | undefined;
  const isAdmin = !!userRow?.isAdmin;

  if (msg.senderId !== req.user!.userId && !isAdmin) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  db.prepare("UPDATE messages SET deletedForAll = 1, content = NULL, mediaUrl = NULL WHERE id = ?").run(messageId as string);
  res.json({ success: true, roomId: msg.roomId });
});

// PUT /api/messages/:id — edit a message (own only)
router.put("/:id", requireAuth, (req, res) => {
  const messageId = req.params["id"] as string;
  const { content } = req.body as { content?: string };

  if (!content?.trim()) { res.status(400).json({ error: "Content required" }); return; }

  const msg = db.prepare("SELECT senderId FROM messages WHERE id = ? AND deletedForAll = 0").get(messageId) as { senderId: string } | undefined;
  if (!msg) { res.status(404).json({ error: "Message not found" }); return; }
  if (msg.senderId !== req.user!.userId) { res.status(403).json({ error: "Forbidden" }); return; }

  const editedAt = new Date().toISOString();
  db.prepare("UPDATE messages SET content = ?, editedAt = ? WHERE id = ?").run(content.trim(), editedAt, messageId as string);
  res.json({ success: true, editedAt });
});

export default router;
