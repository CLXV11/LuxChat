/**
 * User routes: list, get, update profile, upload avatar/cover.
 */
import { Router } from "express";
import bcrypt from "bcryptjs";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import { db } from "../db/index.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

const workspaceRoot = process.cwd().endsWith(path.join("artifacts", "api-server"))
  ? path.resolve(process.cwd(), "../..")
  : process.cwd();

const uploadsDir = path.resolve(workspaceRoot, "artifacts/api-server/uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || ".jpg";
    cb(null, `${Date.now()}-${Math.random().toString(36).substring(2, 9)}${ext}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

function formatUser(u: Record<string, unknown>) {
  return {
    id: u["id"],
    username: u["username"],
    displayName: u["displayName"],
    avatar: u["avatar"],
    coverBanner: u["coverBanner"],
    bio: u["bio"],
    coins: u["coins"],
    joinedAt: u["joinedAt"],
    isVerified: !!u["isVerified"],
    isAdmin: !!u["isAdmin"],
    isDeveloper: !!u["isDeveloper"],
    goldBadge: !!u["goldBadge"],
    title: u["title"],
    theme: u["theme"],
    profileBorder: u["profileBorder"],
    couplePartnerId: u["couplePartnerId"],
  };
}

// GET /api/users — search users (partial username or displayName match)
router.get("/", requireAuth, (req, res) => {
  const { q } = req.query as { q?: string };
  if (!q || !q.trim()) {
    res.json([]);
    return;
  }
  const term = `%${q.trim().toLowerCase()}%`;
  const users = db
    .prepare("SELECT * FROM users WHERE (LOWER(username) LIKE ? OR LOWER(displayName) LIKE ?) AND id != ? LIMIT 10")
    .all(term, term, req.user!.userId) as Record<string, unknown>[];
  res.json(users.map(formatUser));
});

// GET /api/users/me — current user's full profile
router.get("/me", requireAuth, (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user!.userId) as Record<string, unknown> | undefined;
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(formatUser(user));
});

// GET /api/users/:id — user profile by id
router.get("/:id", requireAuth, (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.params["id"] as string) as Record<string, unknown> | undefined;
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(formatUser(user));
});

// PUT /api/users/me — update own profile
router.put("/me", requireAuth, (req, res) => {
  const { displayName, bio, avatar, coverBanner } = req.body as {
    displayName?: string; bio?: string; avatar?: string; coverBanner?: string;
  };

  const fields: string[] = [];
  const values: (string | null)[] = [];

  if (displayName !== undefined) { fields.push("displayName = ?"); values.push(displayName); }
  if (bio !== undefined) { fields.push("bio = ?"); values.push(bio); }
  if (avatar !== undefined) { fields.push("avatar = ?"); values.push(avatar); }
  if (coverBanner !== undefined) { fields.push("coverBanner = ?"); values.push(coverBanner); }

  if (fields.length === 0) { res.status(400).json({ error: "No fields to update" }); return; }

  values.push(req.user!.userId);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  db.prepare(`UPDATE users SET ${fields.join(", ")} WHERE id = ?`).run(...(values as any[]));

  const updated = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user!.userId) as Record<string, unknown>;
  res.json(formatUser(updated));
});

// POST /api/users/me/password — change own password
router.post("/me/password", requireAuth, (req, res) => {
  const { currentPassword, newPassword } = req.body as {
    currentPassword?: string;
    newPassword?: string;
  };
  if (!currentPassword || !newPassword) {
    res.status(400).json({ error: "Current and new passwords are required" });
    return;
  }
  if (newPassword.length < 6) {
    res.status(400).json({ error: "New password must be at least 6 characters" });
    return;
  }

  const user = db.prepare("SELECT password FROM users WHERE id = ?").get(req.user!.userId) as
    | { password: string }
    | undefined;
  if (!user || !bcrypt.compareSync(currentPassword, user.password)) {
    res.status(401).json({ error: "Current password is incorrect" });
    return;
  }

  db.prepare("UPDATE users SET password = ? WHERE id = ?").run(
    bcrypt.hashSync(newPassword, 12),
    req.user!.userId,
  );
  res.json({ success: true, message: "Password changed successfully" });
});

// POST /api/users/me/avatar — upload avatar image
router.post("/me/avatar", requireAuth, upload.single("avatar"), (req, res) => {
  if (!req.file) { res.status(400).json({ error: "No file uploaded" }); return; }
  const avatarUrl = `/api/uploads/${req.file.filename}`;
  db.prepare("UPDATE users SET avatar = ? WHERE id = ?").run(avatarUrl, req.user!.userId);
  res.json({ url: avatarUrl });
});

// POST /api/users/me/cover — upload cover banner
router.post("/me/cover", requireAuth, upload.single("cover"), (req, res) => {
  if (!req.file) { res.status(400).json({ error: "No file uploaded" }); return; }
  const coverUrl = `/api/uploads/${req.file.filename}`;
  db.prepare("UPDATE users SET coverBanner = ? WHERE id = ?").run(coverUrl, req.user!.userId);
  res.json({ url: coverUrl });
});

// POST /api/users/upload/media — upload chat media
const messageUpload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

router.post("/upload/media", requireAuth, messageUpload.single("media"), (req, res) => {
  if (!req.file) { res.status(400).json({ error: "No file uploaded" }); return; }
  const ext = path.extname(req.file.filename).toLowerCase();
  const isVideo = [".mp4", ".mov", ".webm"].includes(ext);
  const mediaUrl = `/api/uploads/${req.file.filename}`;
  res.json({ url: mediaUrl, type: isVideo ? "video" : "image" });
});

export default router;
