/**
 * Central router — mounts all sub-routers.
 */
import { Router, type IRouter } from "express";
import path from "node:path";
import fs from "node:fs";
import express from "express";
import healthRouter from "./health.js";
import authRouter from "./auth.js";
import usersRouter from "./users.js";
import messagesRouter from "./messages.js";
import friendsRouter from "./friends.js";
import coupleRouter from "./couple.js";
import postsRouter from "./posts.js";
import followsRouter from "./follows.js";
import developerRouter from "./developer.js";
import reportsRouter from "./reports.js";

const router: IRouter = Router();

// Serve uploaded files as static assets
const workspaceRoot = process.cwd().endsWith(
  path.join("artifacts", "api-server"),
)
  ? path.resolve(process.cwd(), "../..")
  : process.cwd();

const uploadsDir = path.resolve(workspaceRoot, "artifacts/api-server/uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
router.use("/uploads", express.static(uploadsDir));

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/users", usersRouter);
router.use("/messages", messagesRouter);
router.use("/friends", friendsRouter);
router.use("/couple", coupleRouter);
router.use("/posts", postsRouter);
router.use("/follows", followsRouter);
router.use("/developer", developerRouter);
router.use("/reports", reportsRouter);

export default router;
