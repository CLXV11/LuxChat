/**
 * VIP shop routes: list items, purchase perks.
 */
import { Router } from "express";
import { db } from "../db/index.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

// All available VIP shop items
const SHOP_ITEMS = [
  {
    id: "verified",
    name: "Verified Badge",
    nameAr: "شارة التحقق",
    description: "Blue verification checkmark next to your name",
    price: 500,
    type: "badge",
    icon: "checkmark-circle",
  },
  {
    id: "legendary_theme",
    name: "Legendary Theme",
    nameAr: "ثيم أسطوري",
    description: "Exclusive golden chat theme with particle effects",
    price: 1000,
    type: "theme",
    icon: "sparkles",
  },
  {
    id: "profile_border_gold",
    name: "Gold Border",
    nameAr: "حدود ذهبية",
    description: "Glowing gold profile border and shield",
    price: 800,
    type: "border",
    icon: "shield",
  },
  {
    id: "profile_border_diamond",
    name: "Diamond Border",
    nameAr: "حدود الماسية",
    description: "Shimmering diamond profile border",
    price: 1500,
    type: "border",
    icon: "diamond",
  },
  {
    id: "profile_border_dragon_gold",
    name: "Dragon Frame",
    nameAr: "إطار التنين الذهبي",
    description: "Legendary golden dragon frame — exclusive VIP item",
    price: 5000,
    type: "border",
    icon: "flame",
  },
  {
    id: "profile_border_shield",
    name: "Shield Frame",
    nameAr: "درع البروفايل",
    description: "Elite golden shield surrounding your profile picture",
    price: 2000,
    type: "border",
    icon: "shield-checkmark",
  },
  {
    id: "title_moderator",
    name: "مشرف",
    nameAr: "مشرف",
    description: "Moderator title with premium golden font",
    price: 300,
    type: "title",
    icon: "star",
  },
  {
    id: "title_leader",
    name: "قائد",
    nameAr: "قائد",
    description: "Leader title with premium golden font",
    price: 500,
    type: "title",
    icon: "crown",
  },
  {
    id: "title_emperor",
    name: "إمبراطور",
    nameAr: "إمبراطور",
    description: "Emperor title — the highest honor",
    price: 1000,
    type: "title",
    icon: "flame",
  },
];

// GET /api/shop/items — list all items
router.get("/items", requireAuth, (req, res) => {
  const user = db
    .prepare("SELECT coins, isVerified, title, theme, profileBorder FROM users WHERE id = ?")
    .get(req.user!.userId) as Record<string, unknown> | undefined;

  const owned: string[] = [];
  if (user?.["isVerified"]) owned.push("verified");
  if (user?.["title"]) owned.push(`title_${String(user["title"]).toLowerCase().replace(/\s+/g, "_")}`);
  if (user?.["theme"] !== "default") owned.push(user?.["theme"] as string);
  if (user?.["profileBorder"]) owned.push(user["profileBorder"] as string);

  res.json({
    items: SHOP_ITEMS.map((item) => ({
      ...item,
      owned: owned.includes(item.id),
    })),
    coins: user?.["coins"] ?? 0,
  });
});

// POST /api/shop/purchase — purchase an item
router.post("/purchase", requireAuth, (req, res) => {
  const { itemId } = req.body as { itemId: string };
  const item = SHOP_ITEMS.find((i) => i.id === itemId);

  if (!item) {
    res.status(404).json({ error: "Item not found" });
    return;
  }

  const user = db
    .prepare("SELECT coins, isVerified, title, theme, profileBorder FROM users WHERE id = ?")
    .get(req.user!.userId) as Record<string, unknown> | undefined;

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  if ((user["coins"] as number) < item.price) {
    res.status(402).json({ error: "Insufficient coins" });
    return;
  }

  // Apply the purchased item
  const updates: { sql: string; value: unknown }[] = [];
  updates.push({ sql: "coins = coins - ?", value: item.price });

  if (item.type === "badge") {
    updates.push({ sql: "isVerified = 1", value: null });
  } else if (item.type === "title") {
    updates.push({ sql: "title = ?", value: item.name });
  } else if (item.type === "theme") {
    updates.push({ sql: "theme = ?", value: item.id });
  } else if (item.type === "border") {
    updates.push({ sql: "profileBorder = ?", value: item.id });
  }

  const setClauses = updates.map((u) => u.sql).join(", ");
  const values: (string | number | null)[] = updates
    .filter((u) => u.value !== null)
    .map((u) => u.value as string | number | null);
  values.push(req.user!.userId);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  db.prepare(`UPDATE users SET ${setClauses} WHERE id = ?`).run(...(values as any[]));

  const updated = db
    .prepare("SELECT coins, isVerified, title, theme, profileBorder FROM users WHERE id = ?")
    .get(req.user!.userId) as Record<string, unknown>;

  res.json({
    success: true,
    newBalance: updated["coins"],
    isVerified: !!updated["isVerified"],
    title: updated["title"],
    theme: updated["theme"],
    profileBorder: updated["profileBorder"],
  });
});

export default router;
