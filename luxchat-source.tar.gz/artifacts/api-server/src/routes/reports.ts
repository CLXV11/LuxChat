import { Router } from "express";
import { db, genId } from "../db/index.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

// Reports are routed to the single developer account, without exposing its id.
router.post("/", requireAuth, (req, res) => {
  const message = String((req.body as { message?: string }).message ?? "").trim();
  if (message.length < 3) {
    res.status(400).json({ error: "Report is too short / البلاغ قصير جداً" });
    return;
  }
  if (message.length > 2000) {
    res.status(400).json({ error: "Report is too long / البلاغ طويل جداً" });
    return;
  }

  const developer = db.prepare("SELECT id FROM users WHERE LOWER(username) = 'fadi' LIMIT 1").get() as { id: string } | undefined;
  db.prepare(
    "INSERT INTO reports (id, reporterId, recipientId, message, createdAt) VALUES (?, ?, ?, ?, ?)",
  ).run(genId(), req.user!.userId, developer?.id ?? null, message, new Date().toISOString());

  res.status(201).json({
    success: true,
    message: "Report sent to the developers / تم إرسال البلاغ إلى المطورين",
  });
});

export default router;