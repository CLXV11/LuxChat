/**
 * Socket.io setup for real-time chat.
 * Handles rooms, messaging, reactions, delete, edit, replies, and online status.
 */
import type { Server as HttpServer } from "node:http";
import { Server } from "socket.io";
import { db, genId } from "../db/index.js";
import { verifyToken } from "../middleware/auth.js";
import { logger } from "../lib/logger.js";

// Track online users: userId → socketId
const onlineUsers = new Map<string, string>();

// Exported io reference so routes can emit events
export let io: Server | null = null;

export function setupSocket(httpServer: HttpServer): Server {
  io = new Server(httpServer, {
    path: "/api/socket.io",
    cors: { origin: "*", methods: ["GET", "POST"] },
  });

  // Auth middleware: verify JWT from handshake
  io.use((socket, next) => {
    const token =
      (socket.handshake.auth["token"] as string | undefined) ??
      (socket.handshake.headers["authorization"] as string | undefined)?.replace("Bearer ", "");

    if (!token) { next(new Error("Unauthorized")); return; }
    const payload = verifyToken(token);
    if (!payload) { next(new Error("Invalid token")); return; }

    socket.data["userId"] = payload.userId;
    socket.data["username"] = payload.username;
    next();
  });

  io.on("connection", (socket) => {
    const userId = socket.data["userId"] as string;
    const username = socket.data["username"] as string;

    logger.info({ userId, username }, "Socket connected");
    onlineUsers.set(userId, socket.id);
    io!.emit("online_users", Array.from(onlineUsers.keys()));
    void socket.join("global");

    socket.on("join_room", (roomId: string) => void socket.join(roomId));
    socket.on("leave_room", (roomId: string) => void socket.leave(roomId));

    // ── Send Message ──────────────────────────────────────────────────────────
    socket.on(
      "send_message",
      (data: {
        roomId: string;
        content?: string;
        type?: string;
        mediaUrl?: string;
        replyToId?: string;
      }) => {
        const { roomId, content, type = "text", mediaUrl, replyToId } = data;
        if (!content && !mediaUrl) return;

        const sender = db
          .prepare("SELECT id, username, displayName, avatar, isVerified, title, profileBorder, isAdmin FROM users WHERE id = ?")
          .get(userId) as Record<string, unknown> | undefined;

        const messageId = genId();
        const createdAt = new Date().toISOString();

        db.prepare(
          `INSERT INTO messages (id, roomId, senderId, content, type, mediaUrl, reactions, replyToId, createdAt)
           VALUES (?, ?, ?, ?, ?, ?, '{}', ?, ?)`,
        ).run(messageId, roomId, userId, content ?? null, type, mediaUrl ?? null, replyToId ?? null, createdAt);

        // Fetch reply-to preview if needed
        let replyTo: Record<string, unknown> | null = null;
        if (replyToId) {
          const replyMsg = db
            .prepare("SELECT id, content, type, senderId FROM messages WHERE id = ?")
            .get(replyToId) as Record<string, unknown> | undefined;
          if (replyMsg) {
            const replySender = db
              .prepare("SELECT displayName FROM users WHERE id = ?")
              .get(replyMsg["senderId"] as string) as { displayName: string } | undefined;
            replyTo = {
              id: replyMsg["id"],
              content: replyMsg["content"],
              type: replyMsg["type"],
              senderName: replySender?.displayName ?? "Unknown",
            };
          }
        }

        const message = {
          id: messageId,
          roomId,
          content,
          type,
          mediaUrl,
          reactions: {},
          createdAt,
          replyToId: replyToId ?? null,
          replyTo,
          editedAt: null,
          deletedForAll: false,
          sender: sender
            ? {
                id: sender["id"],
                username: sender["username"],
                displayName: sender["displayName"],
                avatar: sender["avatar"],
                isVerified: !!sender["isVerified"],
                isAdmin: !!sender["isAdmin"],
                title: sender["title"],
                profileBorder: sender["profileBorder"],
              }
            : { id: userId, username, displayName: username, isVerified: false, isAdmin: false },
        };

        io!.to(roomId).emit("new_message", message);
      },
    );

    // ── Delete Message ─────────────────────────────────────────────────────────
    socket.on(
      "delete_message",
      (data: { messageId: string; roomId: string }) => {
        const { messageId, roomId } = data;

        const msg = db
          .prepare("SELECT senderId, roomId FROM messages WHERE id = ?")
          .get(messageId) as { senderId: string; roomId: string } | undefined;

        if (!msg) return;

        // Only sender or admin can delete
        const userRow = db
          .prepare("SELECT isAdmin FROM users WHERE id = ?")
          .get(userId) as { isAdmin: number } | undefined;
        const isAdmin = !!userRow?.isAdmin;

        if (msg.senderId !== userId && !isAdmin) return;

        db.prepare(
          "UPDATE messages SET deletedForAll = 1, content = NULL, mediaUrl = NULL WHERE id = ?",
        ).run(messageId);

        io!.to(roomId).emit("message_deleted", { messageId, roomId });
      },
    );

    // ── Edit Message ───────────────────────────────────────────────────────────
    socket.on(
      "edit_message",
      (data: { messageId: string; content: string; roomId: string }) => {
        const { messageId, content, roomId } = data;

        const msg = db
          .prepare("SELECT senderId FROM messages WHERE id = ? AND deletedForAll = 0")
          .get(messageId) as { senderId: string } | undefined;

        if (!msg || msg.senderId !== userId) return;
        if (!content.trim()) return;

        const editedAt = new Date().toISOString();
        db.prepare(
          "UPDATE messages SET content = ?, editedAt = ? WHERE id = ?",
        ).run(content.trim(), editedAt, messageId);

        io!.to(roomId).emit("message_edited", { messageId, content: content.trim(), editedAt, roomId });
      },
    );

    // ── Typing Indicator ────────────────────────────────────────────────────────
    socket.on("typing", (data: { roomId: string; isTyping: boolean }) => {
      socket.to(data.roomId).emit("typing", { userId, username, isTyping: data.isTyping });
    });

    // ── Reactions ──────────────────────────────────────────────────────────────
    socket.on(
      "add_reaction",
      (data: { messageId: string; emoji: string; roomId: string }) => {
        const { messageId, emoji, roomId } = data;
        const msg = db
          .prepare("SELECT reactions FROM messages WHERE id = ? AND deletedForAll = 0")
          .get(messageId) as { reactions: string } | undefined;
        if (!msg) return;

        const reactions = JSON.parse(msg.reactions || "{}") as Record<string, string[]>;
        const users: string[] = reactions[emoji] ?? [];

        if (users.includes(userId)) {
          reactions[emoji] = users.filter((u) => u !== userId);
          if (reactions[emoji]!.length === 0) delete reactions[emoji];
        } else {
          reactions[emoji] = [...users, userId];
        }

        db.prepare("UPDATE messages SET reactions = ? WHERE id = ?").run(
          JSON.stringify(reactions), messageId,
        );

        io!.to(roomId).emit("reaction_updated", { messageId, reactions });
      },
    );

    // ── Disconnect ────────────────────────────────────────────────────────────
    socket.on("disconnect", () => {
      logger.info({ userId }, "Socket disconnected");
      onlineUsers.delete(userId);
      io!.emit("online_users", Array.from(onlineUsers.keys()));
    });
  });

  return io;
}
