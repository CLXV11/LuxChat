/**
 * Emoji detection utilities for LuxChat message rendering.
 */

// Matches emoji presentation characters
const EMOJI_RE = /\p{Emoji_Presentation}|\p{Extended_Pictographic}/gu;

/** Strip emoji and emoji modifiers from a string */
function stripEmoji(text: string): string {
  return text
    .replace(EMOJI_RE, "")
    .replace(/[\u200d\ufe0f\u20e3]/gu, "") // ZWJ, variation selector, combining enclosing keycap
    .replace(/[\u{1F3FB}-\u{1F3FF}]/gu, "") // skin tone modifiers
    .replace(/[\u{1F1E0}-\u{1F1FF}]/gu, "") // regional indicator letters (flags)
    .trim();
}

/**
 * Returns true if the text contains ONLY emoji characters (1–3 visual emoji).
 * Handles compound emoji (ZWJ sequences, skin tones, flags).
 */
export function isEmojiOnly(text: string): boolean {
  if (!text?.trim()) return false;
  const t = text.trim();
  // Max ~12 chars covers up to 3 compound emoji sequences
  if (t.length > 16) return false;
  try {
    return stripEmoji(t).length === 0;
  } catch {
    return false;
  }
}

/** Extract raw emoji strings from a text (for Twemoji rendering) */
export function extractEmojis(text: string): string[] {
  try {
    return text.match(EMOJI_RE) ?? [];
  } catch {
    return [];
  }
}
