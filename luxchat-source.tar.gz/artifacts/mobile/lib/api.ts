/**
 * Typed API client for LuxChat REST endpoints.
 */

const BASE = `https://${process.env["EXPO_PUBLIC_DOMAIN"]}/api`;

export function resolveMediaUrl(url: string | null | undefined): string | undefined {
  if (!url) return undefined;
  if (url.startsWith("http")) return url;
  const domain = process.env["EXPO_PUBLIC_DOMAIN"];
  if (!domain) return undefined;
  return `https://${domain}${url}`;
}

async function request<T>(path: string, options: RequestInit & { token?: string } = {}): Promise<T> {
  const { token, ...rest } = options;
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(rest.headers as Record<string, string>),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${BASE}${path}`, { ...rest, headers });
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(body.error ?? `HTTP ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  users: {
    list: (token: string, q?: string) =>
      request<unknown[]>(`/users${q ? `?q=${encodeURIComponent(q)}` : ""}`, { token }),
    me: (token: string) => request<unknown>("/users/me", { token }),
    get: (token: string, id: string) => request<unknown>(`/users/${id}`, { token }),
    update: (token: string, data: Record<string, unknown>) =>
      request<unknown>("/users/me", { method: "PUT", token, body: JSON.stringify(data) }),
    changePassword: (token: string, currentPassword: string, newPassword: string) =>
      request<{ success: boolean; message: string }>("/users/me/password", {
        method: "POST",
        token,
        body: JSON.stringify({ currentPassword, newPassword }),
      }),
    uploadAvatar: async (token: string, uri: string): Promise<{ url: string }> => {
      const form = new FormData();
      const filename = uri.split("/").pop() ?? "avatar.jpg";
      const ext = filename.split(".").pop() ?? "jpg";
      form.append("avatar", { uri, name: filename, type: `image/${ext}` } as unknown as Blob);
      const res = await fetch(`${BASE}/users/me/avatar`, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: form });
      if (!res.ok) throw new Error("Upload failed");
      return res.json() as Promise<{ url: string }>;
    },
    uploadCover: async (token: string, uri: string): Promise<{ url: string }> => {
      const form = new FormData();
      const filename = uri.split("/").pop() ?? "cover.jpg";
      const ext = filename.split(".").pop() ?? "jpg";
      form.append("cover", { uri, name: filename, type: `image/${ext}` } as unknown as Blob);
      const res = await fetch(`${BASE}/users/me/cover`, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: form });
      if (!res.ok) throw new Error("Upload failed");
      return res.json() as Promise<{ url: string }>;
    },
    uploadMedia: (
      token: string,
      uri: string,
      onProgress?: (pct: number) => void,
    ): Promise<{ url: string; type: string }> =>
      new Promise((resolve, reject) => {
        // Strip query-string from URI before extracting filename
        const cleanUri = uri.split("?")[0] ?? uri;
        const filename = cleanUri.split("/").pop() ?? "media.jpg";
        const ext = filename.split(".").pop()?.toLowerCase() ?? "jpg";
        const isVideo = ["mp4", "mov", "webm", "m4v", "avi"].includes(ext);
        const mimeType = isVideo ? `video/${ext}` : `image/${ext}`;

        const form = new FormData();
        // React Native expects plain object {uri, name, type} — NOT a Blob
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        form.append("media", { uri, name: filename, type: mimeType } as any);

        // Use XHR — fetch+FormData in React Native sometimes drops the Content-Type
        // boundary causing multer to return "No file uploaded".
        const xhr = new XMLHttpRequest();
        xhr.open("POST", `${BASE}/users/upload/media`);
        xhr.setRequestHeader("Authorization", `Bearer ${token}`);

        if (onProgress) {
          xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
          };
        }

        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              resolve(JSON.parse(xhr.responseText) as { url: string; type: string });
            } catch {
              reject(new Error("Invalid server response"));
            }
          } else {
            reject(new Error(`Upload failed (${xhr.status})`));
          }
        };
        xhr.onerror = () => reject(new Error("Network error during upload"));
        xhr.send(form);
      }),
  },

  messages: {
    global: (token: string) => request<unknown[]>("/messages/global", { token }),
    room: (token: string, roomId: string) => request<unknown[]>(`/messages/room/${roomId}`, { token }),
    react: (token: string, messageId: string, emoji: string) =>
      request<{ reactions: Record<string, string[]> }>(`/messages/${messageId}/reaction`, { method: "POST", token, body: JSON.stringify({ emoji }) }),
    delete: (token: string, messageId: string) =>
      request<{ success: boolean; roomId: string }>(`/messages/${messageId}`, { method: "DELETE", token }),
    edit: (token: string, messageId: string, content: string) =>
      request<{ success: boolean; editedAt: string }>(`/messages/${messageId}`, { method: "PUT", token, body: JSON.stringify({ content }) }),
    roomMedia: (token: string, roomId: string) =>
      request<unknown[]>(`/messages/room/${roomId}/media`, { token }),
    deleteRoom: (token: string, roomId: string) =>
      request<{ success: boolean }>(`/messages/room/${roomId}`, { method: "DELETE", token }),
  },

  coins: {
    balance: (token: string) => request<{ coins: number }>("/coins", { token }),
    redeem: (token: string, code: string) =>
      request<{ reward: number; newBalance: number; type: string; message?: string }>("/coins/redeem", { method: "POST", token, body: JSON.stringify({ code }) }),
  },

  shop: {
    items: (token: string) => request<{ items: unknown[]; coins: number }>("/shop/items", { token }),
    purchase: (token: string, itemId: string) =>
      request<unknown>("/shop/purchase", { method: "POST", token, body: JSON.stringify({ itemId }) }),
  },

  developer: {
    users: (token: string) => request<unknown[]>("/developer/users", { token }),
    setVerification: (token: string, userId: string, enabled: boolean) =>
      request<{ success: boolean }>(`/developer/users/${userId}/verification`, {
        method: "POST", token, body: JSON.stringify({ enabled }),
      }),
    resetPassword: (token: string, userId: string, code: string, newPassword: string) =>
      request<{ success: boolean; message: string }>(`/developer/users/${userId}/reset-password`, {
        method: "POST", token, body: JSON.stringify({ code, newPassword }),
      }),
    deleteUser: (token: string, userId: string) =>
      request<{ success: boolean }>(`/developer/users/${userId}`, { method: "DELETE", token }),
    deletePost: (token: string, postId: string) =>
      request<{ success: boolean }>(`/developer/posts/${postId}`, { method: "DELETE", token }),
  },

  reports: {
    create: (token: string, message: string) =>
      request<{ success: boolean; message: string }>("/reports", {
        method: "POST", token, body: JSON.stringify({ message }),
      }),
  },

  friends: {
    list: (token: string) =>
      request<{ friends: unknown[]; incoming: unknown[]; outgoing: unknown[] }>("/friends", { token }),
    request: (token: string, toUserId: string) =>
      request<{ requestId: string }>("/friends/request", { method: "POST", token, body: JSON.stringify({ toUserId }) }),
    accept: (token: string, requestId: string) =>
      request<{ success: boolean }>(`/friends/${requestId}/accept`, { method: "PUT", token }),
    remove: (token: string, requestId: string) =>
      request<{ success: boolean }>(`/friends/${requestId}`, { method: "DELETE", token }),
  },

  follows: {
    follow: (token: string, userId: string) =>
      request<{ success: boolean; following: boolean; followersCount: number }>(`/follows/${userId}`, { method: "POST", token }),
    unfollow: (token: string, userId: string) =>
      request<{ success: boolean; following: boolean; followersCount: number }>(`/follows/${userId}`, { method: "DELETE", token }),
    stats: (token: string, userId: string) =>
      request<{ followers: number; following: number; isFollowing: boolean }>(`/follows/${userId}/stats`, { token }),
    myStats: (token: string) =>
      request<{ followers: number; following: number }>("/follows/me/stats", { token }),
    followers: (token: string, userId: string) =>
      request<unknown[]>(`/follows/${userId}/followers`, { token }),
    following: (token: string, userId: string) =>
      request<unknown[]>(`/follows/${userId}/following`, { token }),
    myFollowing: (token: string) =>
      request<unknown[]>("/follows/me/following", { token }),
    myFollowers: (token: string) =>
      request<unknown[]>("/follows/me/followers", { token }),
  },

  posts: {
    feed: (token: string) => request<unknown[]>("/posts/feed", { token }),
    userPosts: (token: string, userId: string) => request<unknown[]>(`/posts/user/${userId}`, { token }),
    like: (token: string, postId: string) =>
      request<{ liked: boolean; likesCount: number }>(`/posts/${postId}/like`, { method: "POST", token }),
    delete: (token: string, postId: string) =>
      request<{ success: boolean }>(`/posts/${postId}`, { method: "DELETE", token }),
    create: async (token: string, imageUri: string | null, caption: string): Promise<unknown> => {
      const form = new FormData();
      if (imageUri) {
        const filename = imageUri.split("/").pop() ?? "post.jpg";
        const ext = filename.split(".").pop() ?? "jpg";
        form.append("image", { uri: imageUri, name: filename, type: `image/${ext}` } as unknown as Blob);
      }
      form.append("caption", caption);
      const res = await fetch(`https://${process.env["EXPO_PUBLIC_DOMAIN"]}/api/posts`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: form,
      });
      if (!res.ok) throw new Error("Failed to create post");
      return res.json();
    },
    getComments: (token: string, postId: string) =>
      request<unknown[]>(`/posts/${postId}/comments`, { token }),
    addComment: (token: string, postId: string, content: string) =>
      request<unknown>(`/posts/${postId}/comments`, { method: "POST", token, body: JSON.stringify({ content }) }),
    deleteComment: (token: string, postId: string, commentId: string) =>
      request<{ success: boolean }>(`/posts/${postId}/comments/${commentId}`, { method: "DELETE", token }),
  },

  couple: {
    status: (token: string) => request<unknown>("/couple", { token }),
    request: (token: string, toUserId: string) =>
      request<{ requestId: string }>("/couple/request", { method: "POST", token, body: JSON.stringify({ toUserId }) }),
    accept: (token: string, requestId: string) =>
      request<{ success: boolean }>(`/couple/${requestId}/accept`, { method: "PUT", token }),
    breakup: (token: string) =>
      request<{ success: boolean }>("/couple", { method: "DELETE", token }),
  },
};
