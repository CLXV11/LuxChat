/**
 * Inline video player for chat messages using expo-av.
 */
import React, { useRef, useState, useCallback } from "react";
import {
  View,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Modal,
  Dimensions,
} from "react-native";
import { Video, ResizeMode, type AVPlaybackStatus } from "expo-av";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";

interface VideoPlayerProps {
  uri: string;
  thumbnail?: boolean; // if true, show thumbnail with play button, tap to fullscreen
}

export function VideoPlayer({ uri, thumbnail = false }: VideoPlayerProps) {
  const colors = useColors();
  const videoRef = useRef<Video>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [showFullscreen, setShowFullscreen] = useState(false);

  const handlePlaybackStatus = useCallback((status: AVPlaybackStatus) => {
    if (status.isLoaded) {
      setIsLoaded(true);
      setIsPlaying(status.isPlaying);
    }
  }, []);

  const togglePlay = async () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      await videoRef.current.pauseAsync();
    } else {
      await videoRef.current.playAsync();
    }
  };

  if (thumbnail) {
    return (
      <>
        <TouchableOpacity
          style={styles.thumbnailContainer}
          onPress={() => setShowFullscreen(true)}
          activeOpacity={0.85}
        >
          <View style={styles.playOverlay}>
            <View style={[styles.playBtnLarge, { backgroundColor: "rgba(0,0,0,0.7)" }]}>
              <Ionicons name="play" size={32} color="#fff" />
            </View>
          </View>
          <Ionicons name="videocam" size={18} color="rgba(255,255,255,0.7)" style={styles.videoIcon} />
        </TouchableOpacity>

        <Modal visible={showFullscreen} transparent animationType="fade" onRequestClose={() => setShowFullscreen(false)}>
          <View style={styles.fullscreenOverlay}>
            <TouchableOpacity style={styles.closeBtn} onPress={() => setShowFullscreen(false)}>
              <Ionicons name="close-circle" size={32} color="#fff" />
            </TouchableOpacity>
            <Video
              source={{ uri }}
              style={styles.fullscreenVideo}
              resizeMode={ResizeMode.CONTAIN}
              useNativeControls
              shouldPlay
              onPlaybackStatusUpdate={handlePlaybackStatus}
            />
          </View>
        </Modal>
      </>
    );
  }

  return (
    <View style={styles.inlineContainer}>
      <Video
        ref={videoRef}
        source={{ uri }}
        style={styles.inlineVideo}
        resizeMode={ResizeMode.COVER}
        onPlaybackStatusUpdate={handlePlaybackStatus}
        isLooping={false}
      />
      {!isLoaded && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator color={colors.gold} size="small" />
        </View>
      )}
      {isLoaded && (
        <TouchableOpacity style={styles.inlinePlayOverlay} onPress={togglePlay} activeOpacity={0.8}>
          {!isPlaying && (
            <View style={[styles.playBtnSmall, { backgroundColor: "rgba(0,0,0,0.65)" }]}>
              <Ionicons name="play" size={22} color="#fff" />
            </View>
          )}
        </TouchableOpacity>
      )}
    </View>
  );
}

const { width: SW } = Dimensions.get("window");

const styles = StyleSheet.create({
  thumbnailContainer: {
    width: 210,
    height: 150,
    borderRadius: 10,
    backgroundColor: "#111",
    overflow: "hidden",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 4,
  },
  playOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.3)",
  },
  playBtnLarge: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: "center",
    alignItems: "center",
  },
  videoIcon: { position: "absolute", bottom: 8, right: 8 },
  fullscreenOverlay: {
    flex: 1,
    backgroundColor: "#000",
    justifyContent: "center",
    alignItems: "center",
  },
  closeBtn: { position: "absolute", top: 50, right: 16, zIndex: 10 },
  fullscreenVideo: { width: SW, height: SW * 0.75 },
  inlineContainer: {
    width: 210,
    height: 150,
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#111",
    marginBottom: 4,
  },
  inlineVideo: { width: "100%", height: "100%" },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  inlinePlayOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
  },
  playBtnSmall: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: "center",
    alignItems: "center",
  },
});
