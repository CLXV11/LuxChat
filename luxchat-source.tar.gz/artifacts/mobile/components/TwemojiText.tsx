/**
 * TwemojiText — renders text with iOS-style Twemoji images instead of system emojis.
 * Uses Cloudflare's Twemoji CDN for consistent high-quality emoji across all platforms.
 */
import React from "react";
import { Text, Image, type TextStyle } from "react-native";

const TWEMOJI_CDN = "https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/72x72/";

// Matches surrogate pairs (all modern emoji 😀🔥💎 etc.) and some BMP emoji (❤ ✅ ⭐)
const EMOJI_REGEX = /[\uD800-\uDBFF][\uDC00-\uDFFF]|[\u2600-\u27FF\u2300-\u23FF\u2100-\u214F]/g;

function getCodePoint(char: string): string {
  if (char.length === 2) {
    const hi = char.charCodeAt(0);
    const lo = char.charCodeAt(1);
    if (hi >= 0xD800 && hi <= 0xDBFF && lo >= 0xDC00 && lo <= 0xDFFF) {
      return ((hi - 0xD800) * 0x400 + lo - 0xDC00 + 0x10000).toString(16);
    }
  }
  return char.charCodeAt(0).toString(16);
}

export function twemojiUrl(emoji: string): string {
  return `${TWEMOJI_CDN}${getCodePoint(emoji)}.png`;
}

interface TwemojiImageProps {
  emoji: string;
  size?: number;
}

/** Renders a single emoji as a Twemoji image */
export function TwemojiImage({ emoji, size = 28 }: TwemojiImageProps) {
  return (
    <Image
      source={{ uri: twemojiUrl(emoji) }}
      style={{ width: size, height: size }}
      resizeMode="contain"
    />
  );
}

interface TwemojiTextProps {
  children: string;
  style?: TextStyle;
  emojiSize?: number;
}

type Segment = { type: "text"; value: string } | { type: "emoji"; value: string };

/**
 * Renders a string with emojis replaced by Twemoji images inline.
 * Falls back to system rendering for strings with no detectable emoji.
 */
export function TwemojiText({ children, style, emojiSize }: TwemojiTextProps) {
  const fontSize = (style?.fontSize as number) ?? 15;
  const eSize = emojiSize ?? Math.round(fontSize * 1.25);

  const segments: Segment[] = [];
  let lastIndex = 0;

  const regex = new RegExp(EMOJI_REGEX.source, "g");
  let match: RegExpExecArray | null;
  while ((match = regex.exec(children)) !== null) {
    if (match.index > lastIndex) {
      segments.push({ type: "text", value: children.slice(lastIndex, match.index) });
    }
    segments.push({ type: "emoji", value: match[0] });
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < children.length) {
    segments.push({ type: "text", value: children.slice(lastIndex) });
  }

  if (segments.every((s) => s.type === "text")) {
    return <Text style={style}>{children}</Text>;
  }

  return (
    <Text style={style}>
      {segments.map((seg, i) =>
        seg.type === "emoji" ? (
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          <Image key={i} source={{ uri: twemojiUrl(seg.value) }} style={{ width: eSize, height: eSize } as any} resizeMode="contain" />
        ) : (
          <Text key={i} style={style}>{seg.value}</Text>
        ),
      )}
    </Text>
  );
}
