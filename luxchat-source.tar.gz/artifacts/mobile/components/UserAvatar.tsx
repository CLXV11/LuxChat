/**
 * UserAvatar — displays a user's profile picture.
 * Shows only the official verification mark and online indicator.
 */
import React from "react";
import { View, StyleSheet, Image } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { resolveMediaUrl } from "@/lib/api";

interface UserAvatarProps {
  uri?: string | null;
  size?: number;
  isVerified?: boolean;
  isOnline?: boolean;
  profileBorder?: string | null;
  showOnline?: boolean;
}

export function UserAvatar({
  uri,
  size = 44,
  isVerified = false,
  isOnline = false,
  profileBorder,
  showOnline = false,
}: UserAvatarProps) {
  const colors = useColors();

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      {/* Avatar image or placeholder */}
      {uri ? (
        <Image
          source={{ uri: resolveMediaUrl(uri) }}
          style={[
            styles.image,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
              borderColor: colors.border,
              borderWidth: 1.5,
            },
          ]}
        />
      ) : (
        <View
          style={[
            styles.placeholder,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
              backgroundColor: colors.secondary,
              borderColor: colors.border,
              borderWidth: 1.5,
            },
          ]}
        >
          <Ionicons
            name="person"
            size={size * 0.5}
            color={colors.mutedForeground}
          />
        </View>
      )}

      {/* Verified blue checkmark */}
      {isVerified && (
        <View
          style={[
            styles.badge,
            {
              backgroundColor: colors.verifiedBlue,
              width: size * 0.32,
              height: size * 0.32,
              borderRadius: size * 0.16,
              right: -2,
              bottom: -2,
            },
          ]}
        >
          <Ionicons
            name="checkmark"
            size={size * 0.2}
            color="#FFFFFF"
          />
        </View>
      )}

      {/* Online indicator */}
      {showOnline && (
        <View
          style={[
            styles.online,
            {
              backgroundColor: isOnline ? colors.onlineGreen : colors.mutedForeground,
              width: size * 0.28,
              height: size * 0.28,
              borderRadius: size * 0.14,
              right: isVerified ? size * 0.32 - 2 : -2,
              bottom: -2,
              borderColor: colors.background,
            },
          ]}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: "relative",
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    resizeMode: "cover",
  },
  placeholder: {
    alignItems: "center",
    justifyContent: "center",
  },
  badge: {
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#0A0A0A",
  },
  online: {
    position: "absolute",
    borderWidth: 2,
  },
  borderGlow: {
    position: "absolute",
    opacity: 0.6,
  },
});
