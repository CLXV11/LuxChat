/**
 * Global accessible hamburger menu.
 * The drawer is intentionally implemented with a Modal/Animated view so it
 * behaves consistently in Expo Go, Android, iOS and web.
 */
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  AccessibilityInfo,
  Alert,
  Animated,
  BackHandler,
  Dimensions,
  Easing,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { usePathname } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { usePreferences } from "@/contexts/PreferencesContext";
import { api } from "@/lib/api";

const DRAWER_WIDTH = Math.min(340, Math.round(Dimensions.get("window").width * 0.84));
const DRAWER_ID = "luxchat-navigation-drawer";
type Panel = "appearance" | "language" | "settings" | null;

export function DrawerMenu() {
  const colors = useColors();
  const pathname = usePathname();
  const { user, token } = useAuth();
  const {
    language,
    theme,
    notifications,
    soundEnabled,
    setLanguage,
    setTheme,
    setNotifications,
    setSoundEnabled,
  } = usePreferences();
  const buttonRef = useRef<View>(null);
  const translateX = useRef(new Animated.Value(-DRAWER_WIDTH)).current;
  const [open, setOpen] = useState(false);
  const [panel, setPanel] = useState<Panel>(null);
  const [passwordOpen, setPasswordOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [changingPassword, setChangingPassword] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportText, setReportText] = useState("");
  const [sending, setSending] = useState(false);

  const close = useCallback(() => {
    Animated.timing(translateX, {
      toValue: -DRAWER_WIDTH,
      duration: 220,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start(() => {
      setOpen(false);
      setPanel(null);
      setPasswordOpen(false);
      if (Platform.OS === "web") {
        const element = buttonRef.current as unknown as { focus?: () => void } | null;
        element?.focus?.();
      } else {
        void AccessibilityInfo.setAccessibilityFocus?.(0);
      }
    });
  }, [translateX]);

  const openDrawer = useCallback(() => {
    setPanel(null);
    setOpen(true);
    Animated.timing(translateX, {
      toValue: 0,
      duration: 250,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [translateX]);

  useEffect(() => {
    if (Platform.OS === "web") {
      const body = document.body;
      const previousOverflow = body.style.overflow;
      const onKeyDown = (event: KeyboardEvent) => {
        if (event.key === "Escape" && open) close();
      };
      if (open) {
        body.style.overflow = "hidden";
        window.addEventListener("keydown", onKeyDown);
      }
      return () => {
        body.style.overflow = previousOverflow;
        window.removeEventListener("keydown", onKeyDown);
      };
    }
    if (!open) return undefined;
    const subscription = BackHandler.addEventListener("hardwareBackPress", () => {
      if (reportOpen) {
        setReportOpen(false);
        return true;
      }
      if (panel) {
        setPanel(null);
        setPasswordOpen(false);
        return true;
      }
      close();
      return true;
    });
    return () => subscription.remove();
  }, [open, close, panel, reportOpen]);

  // Keep the hamburger out of authentication screens.
  if (!user || pathname === "/login" || pathname === "/register" || pathname === "/") return null;

  const submitReport = async () => {
    if (!token || reportText.trim().length < 3) return;
    setSending(true);
    try {
      await api.reports.create(token, reportText.trim());
      setReportText("");
      setReportOpen(false);
      Alert.alert("تم الإرسال", "تم إرسال البلاغ إلى المطورين.");
    } catch (error) {
      Alert.alert("خطأ", error instanceof Error ? error.message : "تعذر إرسال البلاغ");
    } finally {
      setSending(false);
    }
  };

  const changePassword = async () => {
    if (!token) return;
    if (currentPassword.length === 0 || newPassword.length < 6) {
      Alert.alert("بيانات غير مكتملة", "أدخل كلمة المرور الحالية وكلمة مرور جديدة من 6 أحرف على الأقل.");
      return;
    }
    if (newPassword !== confirmPassword) {
      Alert.alert("كلمتا المرور غير متطابقتين", "تأكد من تطابق كلمة المرور الجديدة.");
      return;
    }
    setChangingPassword(true);
    try {
      await api.users.changePassword(token, currentPassword, newPassword);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setPasswordOpen(false);
      Alert.alert("تم التغيير", "تم تغيير كلمة المرور بنجاح.");
    } catch (error) {
      Alert.alert("تعذر تغيير كلمة المرور", error instanceof Error ? error.message : "حاول مرة أخرى.");
    } finally {
      setChangingPassword(false);
    }
  };

  const openReport = () => {
    close();
    setTimeout(() => setReportOpen(true), 230);
  };

  return (
    <>
      <Pressable
        ref={buttonRef}
        accessibilityRole="button"
        accessibilityLabel="فتح قائمة التنقل"
        accessibilityHint="يفتح الإعدادات والبلاغات"
        accessibilityState={{ expanded: open }}
        accessibilityValue={{ text: open ? "مفتوحة" : "مغلقة" }}
        accessible
        aria-expanded={open}
        aria-controls={DRAWER_ID}
        onPress={open ? close : openDrawer}
        style={[styles.hamburger, { backgroundColor: colors.card, borderColor: colors.border }]}
      >
        <View style={styles.lines}>
          <View style={[styles.line, { backgroundColor: colors.foreground }]} />
          <View style={[styles.line, { backgroundColor: colors.foreground }]} />
          <View style={[styles.line, { backgroundColor: colors.foreground }]} />
        </View>
      </Pressable>

      <Modal visible={open} transparent animationType="none" onRequestClose={close} accessibilityViewIsModal>
        <View style={styles.modalRoot}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="إغلاق القائمة"
            onPress={close}
            style={styles.scrim}
          />
           <Animated.View
            nativeID={DRAWER_ID}
            accessibilityRole="menu"
            style={[
              styles.drawer,
              { width: DRAWER_WIDTH, backgroundColor: colors.background, borderRightColor: colors.border },
              { transform: [{ translateX }] },
            ]}
           >
             <ScrollView
               contentContainerStyle={styles.drawerContent}
               showsVerticalScrollIndicator={false}
               keyboardShouldPersistTaps="handled"
             >
               <View style={styles.drawerHeader}>
                 <View>
                   <Text style={[styles.drawerTitle, { color: colors.foreground }]}>LuxChat</Text>
                   <Text style={[styles.drawerSubtitle, { color: colors.mutedForeground }]}>
                     {panel ? "الإعدادات" : "القائمة الرئيسية"}
                   </Text>
                 </View>
                 <Pressable accessibilityRole="button" accessibilityLabel="إغلاق القائمة" onPress={close} hitSlop={10}>
                   <Ionicons name="close" size={24} color={colors.mutedForeground} />
                 </Pressable>
               </View>

               <View style={[styles.userStrip, { backgroundColor: colors.card, borderColor: colors.border }]}>
                 <Ionicons name="person-circle-outline" size={30} color={colors.primary} />
                 <View style={{ flex: 1 }}>
                   <Text style={[styles.userName, { color: colors.foreground }]}>{user.displayName}</Text>
                   <Text style={[styles.userHandle, { color: colors.mutedForeground }]}>@{user.username}</Text>
                 </View>
               </View>

               {panel ? (
                 <>
                   <Pressable
                     accessibilityRole="button"
                     accessibilityLabel="العودة إلى القائمة الرئيسية"
                     onPress={() => {
                       setPanel(null);
                       setPasswordOpen(false);
                     }}
                     style={({ pressed }) => [styles.backRow, pressed && { backgroundColor: colors.surface }]}
                   >
                     <Ionicons name="arrow-back" size={20} color={colors.primary} />
                     <Text style={[styles.backLabel, { color: colors.foreground }]}>العودة</Text>
                   </Pressable>

                   {panel === "appearance" && (
                     <PanelBlock title="المظهر" icon="color-palette-outline" colors={colors}>
                       <ChoiceRow
                         icon="moon-outline"
                         label="الوضع الداكن"
                         selected={theme === "dark"}
                         onPress={() => setTheme("dark")}
                         colors={colors}
                       />
                       <ChoiceRow
                         icon="sunny-outline"
                         label="الوضع الفاتح"
                         selected={theme === "light"}
                         onPress={() => setTheme("light")}
                         colors={colors}
                       />
                     </PanelBlock>
                   )}

                   {panel === "language" && (
                     <PanelBlock title="اللغة" icon="language-outline" colors={colors}>
                       <ChoiceRow
                         label="العربية"
                         selected={language === "ar"}
                         onPress={() => setLanguage("ar")}
                         colors={colors}
                       />
                       <ChoiceRow
                         label="English"
                         selected={language === "en"}
                         onPress={() => setLanguage("en")}
                         colors={colors}
                       />
                     </PanelBlock>
                   )}

                   {panel === "settings" && (
                     <PanelBlock title="الإعدادات" icon="settings-outline" colors={colors}>
                       <ToggleRow
                         icon="notifications-outline"
                         label="الإشعارات"
                         value={notifications}
                         onValueChange={setNotifications}
                         colors={colors}
                       />
                       <ToggleRow
                         icon="volume-high-outline"
                         label="صوت النقر"
                         value={soundEnabled}
                         onValueChange={setSoundEnabled}
                         colors={colors}
                       />
                       <Pressable
                         onPress={() => setPasswordOpen((value) => !value)}
                         style={({ pressed }) => [styles.passwordButton, { borderColor: colors.border }, pressed && { backgroundColor: colors.surface }]}
                       >
                         <Ionicons name="key-outline" size={20} color={colors.primary} />
                         <Text style={[styles.passwordButtonLabel, { color: colors.foreground }]}>تغيير كلمة المرور</Text>
                         <Ionicons name={passwordOpen ? "chevron-up" : "chevron-down"} size={17} color={colors.mutedForeground} />
                       </Pressable>
                       {passwordOpen && (
                         <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined}>
                           <TextInput
                             value={currentPassword}
                             onChangeText={setCurrentPassword}
                             placeholder="كلمة المرور الحالية"
                             placeholderTextColor={colors.mutedForeground}
                             secureTextEntry
                             style={[styles.passwordInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.input }]}
                           />
                           <TextInput
                             value={newPassword}
                             onChangeText={setNewPassword}
                             placeholder="كلمة المرور الجديدة"
                             placeholderTextColor={colors.mutedForeground}
                             secureTextEntry
                             style={[styles.passwordInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.input }]}
                           />
                           <TextInput
                             value={confirmPassword}
                             onChangeText={setConfirmPassword}
                             placeholder="تأكيد كلمة المرور الجديدة"
                             placeholderTextColor={colors.mutedForeground}
                             secureTextEntry
                             style={[styles.passwordInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.input }]}
                           />
                           <Pressable
                             disabled={changingPassword}
                             onPress={() => void changePassword()}
                             style={[styles.saveButton, { backgroundColor: colors.primary, opacity: changingPassword ? 0.6 : 1 }]}
                           >
                             <Text style={[styles.saveButtonLabel, { color: colors.primaryForeground }]}>
                               {changingPassword ? "جارٍ الحفظ..." : "حفظ كلمة المرور"}
                             </Text>
                           </Pressable>
                         </KeyboardAvoidingView>
                       )}
                     </PanelBlock>
                   )}
                 </>
               ) : (
                 <>
                   <View style={styles.menuList}>
                     <MenuItem icon="color-palette-outline" label="المظهر" onPress={() => setPanel("appearance")} colors={colors} />
                     <MenuItem icon="language-outline" label="اللغة" onPress={() => setPanel("language")} colors={colors} />
                     <MenuItem icon="settings-outline" label="الإعدادات" onPress={() => setPanel("settings")} colors={colors} />
                     <MenuItem icon="flag-outline" label="إرسال بلاغ" onPress={openReport} colors={colors} />
                   </View>

                   <View style={[styles.divider, { backgroundColor: colors.border }]} />
                   <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>حول التطبيق</Text>
                   <MenuItem icon="information-circle-outline" label="حول التطبيق" onPress={() => Alert.alert("LuxChat", "تطبيق مراسلة فورية آمن وسريع.")} colors={colors} />
                   <MenuItem icon="logo-github" label="GitHub المطوّر" onPress={() => void Linking.openURL("https://github.com/CLXV11")} colors={colors} />
                   <MenuItem icon="paper-plane-outline" label="Telegram المطوّر" onPress={() => void Linking.openURL("https://t.me/EPCD11")} colors={colors} />
                 </>
               )}
             </ScrollView>
           </Animated.View>
        </View>
      </Modal>

      <Modal visible={reportOpen} transparent animationType="fade" onRequestClose={() => setReportOpen(false)}>
        <View style={styles.reportOverlay}>
          <View style={[styles.reportCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.reportHeader}>
              <Text style={[styles.reportTitle, { color: colors.foreground }]}>إرسال بلاغ</Text>
              <Pressable onPress={() => setReportOpen(false)}><Ionicons name="close" size={22} color={colors.mutedForeground} /></Pressable>
            </View>
            <Text style={[styles.reportHint, { color: colors.mutedForeground }]}>سيصل البلاغ إلى حساب المطوّر.</Text>
            <TextInput
              autoFocus
              multiline
              maxLength={2000}
              value={reportText}
              onChangeText={setReportText}
              placeholder="اكتب تفاصيل البلاغ..."
              placeholderTextColor={colors.mutedForeground}
              style={[styles.reportInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface }]}
            />
            <Pressable
              disabled={sending || reportText.trim().length < 3}
              onPress={() => void submitReport()}
              style={[styles.reportButton, { backgroundColor: reportText.trim().length >= 3 ? colors.primary : colors.border }]}
            >
              <Text style={{ color: colors.primaryForeground }}>{sending ? "جارٍ الإرسال..." : "إرسال البلاغ"}</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </>
  );
}

function MenuItem({
  icon, label, onPress, colors,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  onPress: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <Pressable
      accessibilityRole="menuitem"
      onPress={onPress}
      style={({ pressed }) => [styles.menuItem, pressed && { backgroundColor: colors.surface }]}
    >
      <Ionicons name={icon} size={21} color={colors.primary} />
      <Text style={[styles.menuLabel, { color: colors.foreground }]}>{label}</Text>
      <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  hamburger: {
    position: "absolute", top: 54, left: 14, zIndex: 1000,
    width: 44, height: 44, borderRadius: 13, borderWidth: 1,
    alignItems: "center", justifyContent: "center",
    shadowColor: "#000", shadowOpacity: 0.22, shadowRadius: 8, elevation: 8,
  },
  lines: { gap: 5 },
  line: { width: 22, height: 2.5, borderRadius: 2 },
  modalRoot: { flex: 1 },
  scrim: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(0,0,0,0.58)" },
  drawer: {
    flex: 1,
    borderRightWidth: 1, shadowColor: "#000", shadowOpacity: 0.35,
    shadowRadius: 16, elevation: 16,
  },
  drawerContent: { paddingTop: 58, paddingHorizontal: 16, paddingBottom: 28 },
  drawerHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 20 },
  drawerTitle: { fontSize: 23, fontWeight: "700", fontFamily: "Inter_700Bold" },
  drawerSubtitle: { fontSize: 12, marginTop: 2 },
  userStrip: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderRadius: 14, padding: 12, marginBottom: 16 },
  userName: { fontSize: 14, fontWeight: "600" },
  userHandle: { fontSize: 12, marginTop: 2 },
  menuList: { gap: 3 },
  menuItem: { flexDirection: "row", alignItems: "center", gap: 13, minHeight: 48, paddingHorizontal: 10, borderRadius: 10 },
  menuLabel: { flex: 1, fontSize: 15, fontFamily: "Inter_400Regular" },
  backRow: { flexDirection: "row", alignItems: "center", gap: 10, minHeight: 44, paddingHorizontal: 10, borderRadius: 10, marginBottom: 12 },
  backLabel: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  panelBlock: { gap: 5 },
  panelTitleRow: { flexDirection: "row", alignItems: "center", gap: 9, paddingHorizontal: 10, marginBottom: 8 },
  panelTitle: { fontSize: 18, fontWeight: "700", fontFamily: "Inter_700Bold" },
  choiceRow: { flexDirection: "row", alignItems: "center", minHeight: 50, paddingHorizontal: 10, borderRadius: 10, gap: 12 },
  choiceLabel: { flex: 1, fontSize: 15, fontFamily: "Inter_400Regular" },
  toggleRow: { flexDirection: "row", alignItems: "center", minHeight: 54, paddingHorizontal: 10, gap: 12 },
  toggleLabel: { flex: 1, fontSize: 15, fontFamily: "Inter_400Regular" },
  passwordButton: { flexDirection: "row", alignItems: "center", minHeight: 50, borderTopWidth: 1, marginTop: 5, paddingHorizontal: 10, gap: 12 },
  passwordButtonLabel: { flex: 1, fontSize: 15, fontFamily: "Inter_400Regular" },
  passwordInput: { minHeight: 46, borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, marginTop: 8, fontSize: 14, textAlign: "right" },
  saveButton: { alignItems: "center", borderRadius: 10, paddingVertical: 12, marginTop: 10 },
  saveButtonLabel: { fontSize: 14, fontWeight: "700", fontFamily: "Inter_700Bold" },
  divider: { height: StyleSheet.hairlineWidth, marginVertical: 18 },
  sectionLabel: { fontSize: 12, marginBottom: 7, paddingHorizontal: 10 },
  reportOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", alignItems: "center", justifyContent: "center", padding: 18 },
  reportCard: { width: "100%", maxWidth: 430, borderRadius: 18, borderWidth: 1, padding: 18, gap: 12 },
  reportHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  reportTitle: { fontSize: 18, fontWeight: "700" },
  reportHint: { fontSize: 13 },
  reportInput: { minHeight: 120, borderWidth: 1, borderRadius: 12, padding: 12, textAlignVertical: "top", fontSize: 15 },
  reportButton: { alignItems: "center", borderRadius: 11, paddingVertical: 12 },
});

function PanelBlock({
  title,
  icon,
  colors,
  children,
}: {
  title: string;
  icon: keyof typeof Ionicons.glyphMap;
  colors: ReturnType<typeof useColors>;
  children: React.ReactNode;
}) {
  return (
    <View style={styles.panelBlock}>
      <View style={styles.panelTitleRow}>
        <Ionicons name={icon} size={21} color={colors.primary} />
        <Text style={[styles.panelTitle, { color: colors.foreground }]}>{title}</Text>
      </View>
      {children}
    </View>
  );
}

function ChoiceRow({
  icon,
  label,
  selected,
  onPress,
  colors,
}: {
  icon?: keyof typeof Ionicons.glyphMap;
  label: string;
  selected: boolean;
  onPress: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <Pressable
      accessibilityRole="radio"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={({ pressed }) => [styles.choiceRow, pressed && { backgroundColor: colors.surface }]}
    >
      {icon && <Ionicons name={icon} size={20} color={selected ? colors.primary : colors.mutedForeground} />}
      <Text style={[styles.choiceLabel, { color: colors.foreground }]}>{label}</Text>
      {selected && <Ionicons name="checkmark-circle" size={21} color={colors.primary} />}
    </Pressable>
  );
}

function ToggleRow({
  icon,
  label,
  value,
  onValueChange,
  colors,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={styles.toggleRow}>
      <Ionicons name={icon} size={20} color={colors.primary} />
      <Text style={[styles.toggleLabel, { color: colors.foreground }]}>{label}</Text>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: colors.border, true: colors.primary }}
        thumbColor="#FFFFFF"
      />
    </View>
  );
}