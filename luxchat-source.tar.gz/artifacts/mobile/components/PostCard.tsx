/**
 * PostCard — displays a single post with image, caption, like, and comments.
 */
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
  Modal,
  TextInput,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { UserAvatar } from "./UserAvatar";
import { resolveMediaUrl, api } from "@/lib/api";

export interface CommentData {
  id: string;
  content: string;
  createdAt: string;
  author: {
    id: string;
    username: string;
    displayName: string;
    avatar?: string | null;
    isVerified?: boolean;
    isAdmin?: boolean;
    title?: string | null;
  } | null;
}

export interface PostData {
  id: string;
  imageUrl?: string | null;
  caption?: string;
  createdAt: string;
  likesCount: number;
  isLiked: boolean;
  commentsCount?: number;
  author: {
    id: string;
    username: string;
    displayName: string;
    avatar?: string | null;
    isVerified?: boolean;
    isAdmin?: boolean;
    title?: string | null;
    profileBorder?: string | null;
  } | null;
}

interface PostCardProps {
  post: PostData;
  token?: string;
  onLike: (postId: string) => void;
  onDelete?: (postId: string) => void;
  isMine?: boolean;
  isAdminUser?: boolean;
  onPressUser?: (userId: string) => void;
}

export function PostCard({ post, token, onLike, onDelete, isMine, isAdminUser, onPressUser }: PostCardProps) {
  const colors = useColors();
  const [liked, setLiked] = useState(post.isLiked);
  const [likes, setLikes] = useState(post.likesCount);
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<CommentData[]>([]);
  const [commentsCount, setCommentsCount] = useState(post.commentsCount ?? 0);
  const [loadingComments, setLoadingComments] = useState(false);
  const [newComment, setNewComment] = useState("");
  const [sendingComment, setSendingComment] = useState(false);

  const timeAgo = (() => {
    const diff = Date.now() - new Date(post.createdAt).getTime();
    const m = Math.floor(diff / 60000);
    if (m < 1) return "الآن";
    if (m < 60) return `${m}د`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}س`;
    return `${Math.floor(h / 24)}ي`;
  })();

  const handleLike = () => {
    const next = !liked;
    setLiked(next);
    setLikes((l) => l + (next ? 1 : -1));
    onLike(post.id);
  };

  const handleDelete = () => {
    Alert.alert("حذف المنشور", "هل أنت متأكد؟", [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => onDelete?.(post.id) },
    ]);
  };

  const openComments = async () => {
    setShowComments(true);
    if (!token || loadingComments || comments.length > 0) return;
    setLoadingComments(true);
    try {
      const data = await api.posts.getComments(token, post.id);
      setComments(data as CommentData[]);
    } catch {}
    finally { setLoadingComments(false); }
  };

  const sendComment = async () => {
    if (!token || !newComment.trim()) return;
    setSendingComment(true);
    try {
      const comment = await api.posts.addComment(token, post.id, newComment.trim());
      setComments((prev) => [...prev, comment as CommentData]);
      setCommentsCount((c) => c + 1);
      setNewComment("");
    } catch (e) {
      Alert.alert("خطأ", e instanceof Error ? e.message : "فشل إرسال التعليق");
    } finally {
      setSendingComment(false);
    }
  };

  const canDelete = isMine || isAdminUser;

  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.authorRow} onPress={() => post.author && onPressUser?.(post.author.id)} activeOpacity={0.7}>
          <UserAvatar uri={post.author?.avatar} size={40} isVerified={post.author?.isVerified} profileBorder={post.author?.profileBorder} />
          <View style={styles.authorInfo}>
            <View style={styles.nameRow}>
              <Text style={[styles.displayName, { color: colors.foreground }]}>{post.author?.displayName ?? "Unknown"}</Text>
              {post.author?.isVerified && <Ionicons name="checkmark-circle" size={14} color={colors.verifiedBlue} />}
            </View>
            <Text style={[styles.time, { color: colors.mutedForeground }]}>{timeAgo}</Text>
          </View>
        </TouchableOpacity>
        {canDelete && (
          <TouchableOpacity onPress={handleDelete} style={styles.deleteBtn}>
            <Ionicons name="trash-outline" size={18} color={colors.destructive} />
          </TouchableOpacity>
        )}
      </View>

      {/* Image */}
      {post.imageUrl && (
        <Image source={{ uri: resolveMediaUrl(post.imageUrl) }} style={styles.image} resizeMode="cover" />
      )}

      {/* Caption */}
      {post.caption ? (
        <Text style={[styles.caption, { color: colors.foreground }]}>{post.caption}</Text>
      ) : null}

      {/* Actions */}
      <View style={[styles.actions, { borderTopColor: colors.border }]}>
        <TouchableOpacity style={styles.actionBtn} onPress={handleLike} activeOpacity={0.7}>
          <Ionicons name={liked ? "heart" : "heart-outline"} size={22} color={liked ? colors.neonPink : colors.mutedForeground} />
          <Text style={[styles.actionCount, { color: liked ? colors.neonPink : colors.mutedForeground }]}>
            {likes.toLocaleString()}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionBtn} onPress={openComments} activeOpacity={0.7}>
          <Ionicons name="chatbubble-outline" size={20} color={colors.mutedForeground} />
          <Text style={[styles.actionCount, { color: colors.mutedForeground }]}>
            {commentsCount.toLocaleString()}
          </Text>
        </TouchableOpacity>
      </View>

      {/* ── Comments Modal ──────────────────────────────────────────────── */}
      <Modal visible={showComments} animationType="slide" transparent onRequestClose={() => setShowComments(false)}>
        <View style={styles.commentsOverlay}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.commentsSheet}>
            <View style={[styles.commentsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              {/* Header */}
              <View style={styles.commentsHeader}>
                <Text style={[styles.commentsTitle, { color: colors.foreground }]}>التعليقات ({commentsCount})</Text>
                <TouchableOpacity onPress={() => setShowComments(false)}>
                  <Ionicons name="close" size={22} color={colors.mutedForeground} />
                </TouchableOpacity>
              </View>

              {/* List */}
              {loadingComments ? (
                <View style={styles.commentsLoading}>
                  <ActivityIndicator color={colors.gold} />
                </View>
              ) : (
                <FlatList
                  data={comments}
                  keyExtractor={(c) => c.id}
                  style={styles.commentsList}
                  ListEmptyComponent={
                    <Text style={[styles.noComments, { color: colors.mutedForeground }]}>
                      لا توجد تعليقات بعد. كن أول من يعلّق!
                    </Text>
                  }
                  renderItem={({ item }) => (
                    <View style={styles.commentItem}>
                      <UserAvatar uri={item.author?.avatar} size={30} isVerified={item.author?.isVerified} />
                      <View style={[styles.commentBubble, { backgroundColor: colors.surface }]}>
                        <View style={styles.commentNameRow}>
                          <Text style={[styles.commentAuthor, { color: colors.gold }]}>
                            {item.author?.displayName ?? "Unknown"}
                          </Text>
                          {item.author?.isVerified && (
                            <Ionicons name="checkmark-circle" size={11} color={colors.verifiedBlue} />
                          )}
                        </View>
                        <Text style={[styles.commentContent, { color: colors.foreground }]}>{item.content}</Text>
                      </View>
                    </View>
                  )}
                />
              )}

              {/* Input */}
              {token ? (
                <View style={[styles.commentInput, { borderTopColor: colors.border }]}>
                  <TextInput
                    style={[styles.commentTextInput, { color: colors.foreground, backgroundColor: colors.surface, borderColor: colors.border }]}
                    placeholder="اكتب تعليقًا..."
                    placeholderTextColor={colors.mutedForeground}
                    value={newComment}
                    onChangeText={setNewComment}
                    maxLength={300}
                    multiline
                  />
                  <TouchableOpacity
                    style={[styles.sendCommentBtn, { backgroundColor: newComment.trim() ? colors.gold : colors.surface }]}
                    onPress={sendComment}
                    disabled={sendingComment || !newComment.trim()}
                  >
                    {sendingComment ? (
                      <ActivityIndicator color="#000" size="small" />
                    ) : (
                      <Ionicons name="send" size={16} color={newComment.trim() ? "#000" : colors.mutedForeground} />
                    )}
                  </TouchableOpacity>
                </View>
              ) : null}
            </View>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderWidth: StyleSheet.hairlineWidth, borderRadius: 18, marginHorizontal: 14, marginVertical: 8, overflow: "hidden" },
  header: { flexDirection: "row", alignItems: "center", padding: 13, justifyContent: "space-between" },
  authorRow: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
  authorInfo: { gap: 2 },
  nameRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  displayName: { fontSize: 14, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  adminBadge: { borderRadius: 5, padding: 3 },
  titleBadge: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  time: { fontSize: 11, fontFamily: "Inter_400Regular" },
  deleteBtn: { padding: 8 },
  image: { width: "100%", aspectRatio: 1 },
  caption: { fontSize: 14, lineHeight: 21, paddingHorizontal: 14, paddingVertical: 10, fontFamily: "Inter_400Regular" },
  actions: { flexDirection: "row", paddingHorizontal: 14, paddingVertical: 10, borderTopWidth: StyleSheet.hairlineWidth, gap: 20 },
  actionBtn: { flexDirection: "row", alignItems: "center", gap: 6 },
  actionCount: { fontSize: 14, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  commentsOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  commentsSheet: { maxHeight: "80%" },
  commentsCard: { borderTopLeftRadius: 24, borderTopRightRadius: 24, borderWidth: 1, maxHeight: 600 },
  commentsHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 16, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "#252525" },
  commentsTitle: { fontSize: 16, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  commentsLoading: { padding: 40, alignItems: "center" },
  commentsList: { maxHeight: 350, paddingHorizontal: 14 },
  noComments: { textAlign: "center", padding: 30, fontFamily: "Inter_400Regular" },
  commentItem: { flexDirection: "row", gap: 10, paddingVertical: 8, alignItems: "flex-start" },
  commentBubble: { flex: 1, borderRadius: 12, padding: 10, gap: 3 },
  commentNameRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  commentAuthor: { fontSize: 12, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  commentContent: { fontSize: 14, lineHeight: 19, fontFamily: "Inter_400Regular" },
  commentInput: { flexDirection: "row", padding: 12, gap: 10, borderTopWidth: StyleSheet.hairlineWidth, alignItems: "flex-end" },
  commentTextInput: { flex: 1, borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 8, fontSize: 14, fontFamily: "Inter_400Regular", maxHeight: 80 },
  sendCommentBtn: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" },
});
