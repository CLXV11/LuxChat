/**
 * MessageBubble — rich chat bubble with:
 * - Emoji-only large display (no bubble, floating emoji like Messenger)
 * - Double-tap → ❤️ heart reaction
 * - Video player support
 * - Twemoji reactions
 * - Reply preview, edit indicator, long-press context menu
 * - Improved verification & admin badges
 */
import React, { useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Modal,
  Platform,
  Clipboard,
  Alert,
  Animated,
} from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { UserAvatar } from "./UserAvatar";
import { TwemojiImage } from "./TwemojiText";
import { VideoPlayer } from "./VideoPlayer";
import { resolveMediaUrl } from "@/lib/api";

const REACTION_EMOJIS = ["❤️", "😂", "😮", "😢", "🔥", "👏", "💎", "🥇"];

// Matches emoji surrogate pairs and common BMP emoji
const EMOJI_RE = /[\uD800-\uDBFF][\uDC00-\uDFFF]|[\u2600-\u27FF\u2300-\u23FF\u2100-\u214F]/g;

function isEmojiOnlyMsg(text: string): boolean {
  if (!text?.trim() || text.trim().length > 16) return false;
  const t = text.trim();
  const noEmoji = t.replace(EMOJI_RE, "").replace(/\s/g, "");
  const emojiMatches = t.match(EMOJI_RE);
  return noEmoji.length === 0 && !!emojiMatches;
}

function getEmojiList(text: string): string[] {
  return text.match(EMOJI_RE) ?? [];
}

export interface MessageData {
  id: string;
  roomId: string;
  content?: string;
  type: string;
  mediaUrl?: string;
  reactions: Record<string, string[]>;
  createdAt: string;
  editedAt?: string | null;
  deletedForAll?: boolean;
  replyToId?: string | null;
  replyTo?: {
    id: string;
    content?: string;
    type: string;
    senderName: string;
  } | null;
  sender: {
    id: string;
    username: string;
    displayName: string;
    avatar?: string | null;
    isVerified?: boolean;
    isAdmin?: boolean;
    title?: string | null;
    profileBorder?: string | null;
  };
}

interface MessageBubbleProps {
  message: MessageData;
  isSelf: boolean;
  isAdmin?: boolean;
  currentUserId?: string;
  onReact: (messageId: string, emoji: string) => void;
  onDelete?: (messageId: string) => void;
  onEdit?: (message: MessageData) => void;
  onReply?: (message: MessageData) => void;
  showAvatar?: boolean;
}

export function MessageBubble({
  message,
  isSelf,
  isAdmin = false,
  onReact,
  onDelete,
  onEdit,
  onReply,
  showAvatar = true,
}: MessageBubbleProps) {
  const colors = useColors();
  const [showMenu, setShowMenu] = useState(false);
  const [showFullImage, setShowFullImage] = useState(false);
  const [heartAnim] = useState(() => new Animated.Value(0));

  const lastTapRef = useRef<number>(0);

  const time = new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const totalReactions = Object.values(message.reactions).reduce((sum, users) => sum + users.length, 0);
  const isDeleted = !!message.deletedForAll;

  const emojiOnly = !isDeleted && !!message.content && isEmojiOnlyMsg(message.content);
  const emojiList = emojiOnly && message.content ? getEmojiList(message.content) : [];

  const handleDoubleTapHeart = useCallback(() => {
    onReact(message.id, "❤️");
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    // Animate a floating heart
    heartAnim.setValue(0);
    Animated.sequence([
      Animated.spring(heartAnim, { toValue: 1, useNativeDriver: true, tension: 60, friction: 8 }),
      Animated.delay(600),
      Animated.timing(heartAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start();
  }, [onReact, message.id, heartAnim]);

  const handleTap = useCallback(() => {
    const now = Date.now();
    if (now - lastTapRef.current < 320) {
      handleDoubleTapHeart();
      lastTapRef.current = 0;
    } else {
      lastTapRef.current = now;
    }
  }, [handleDoubleTapHeart]);

  const handleCopy = () => {
    if (message.content) {
      Clipboard.setString(message.content);
      Alert.alert("✓", "تم نسخ الرسالة");
    }
    setShowMenu(false);
  };

  const handleDelete = () => {
    setShowMenu(false);
    Alert.alert("حذف الرسالة", "سيتم حذفها للجميع.", [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => onDelete?.(message.id) },
    ]);
  };

  const handleEdit = () => { setShowMenu(false); onEdit?.(message); };
  const handleReply = () => { setShowMenu(false); onReply?.(message); };

  const canDelete = isSelf || isAdmin;
  const canEdit = isSelf && !isDeleted && message.type === "text";

  const selfBg = colors.messageBubbleSelf;
  const selfBorder = colors.messageBubbleSelfBorder ?? "#4A2FBF";

  const heartScale = heartAnim.interpolate({ inputRange: [0, 1], outputRange: [0, 1.6] });
  const heartOpacity = heartAnim;

  // ── Emoji-only message: large floating emoji, no bubble ──────────────
  if (emojiOnly && emojiList.length > 0) {
    return (
      <View style={[styles.row, isSelf ? styles.rowSelf : styles.rowOther]}>
        {!isSelf && showAvatar && (
          <UserAvatar uri={message.sender.avatar} size={28} isVerified={message.sender.isVerified} profileBorder={message.sender.profileBorder} />
        )}
        {!isSelf && !showAvatar && <View style={{ width: 28 }} />}

        <TouchableOpacity onPress={handleTap} onLongPress={() => setShowMenu(true)} activeOpacity={0.8} style={styles.emojiBubble}>
          <View style={[styles.emojiRow, isSelf && styles.emojiRowSelf]}>
            {emojiList.map((e, i) => (
              <TwemojiImage key={i} emoji={e} size={emojiList.length === 1 ? 72 : emojiList.length === 2 ? 58 : 48} />
            ))}
          </View>
          <Text style={[styles.emojiTime, { color: colors.mutedForeground }]}>{time}</Text>
          {/* Floating heart animation */}
          <Animated.View style={[styles.floatingHeart, { opacity: heartOpacity, transform: [{ scale: heartScale }] }]}>
            <Text style={{ fontSize: 40 }}>❤️</Text>
          </Animated.View>
        </TouchableOpacity>

        {/* Reactions */}
        {totalReactions > 0 && (
          <View style={[styles.reactions, isSelf && styles.reactionsSelf]}>
            {Object.entries(message.reactions).map(([emoji, users]) =>
              users.length > 0 ? (
                <TouchableOpacity key={emoji} style={[styles.reactionBadge, { backgroundColor: colors.surface, borderColor: colors.border }]} onPress={() => onReact(message.id, emoji)}>
                  <TwemojiImage emoji={emoji} size={14} />
                  <Text style={[styles.reactionCount, { color: colors.mutedForeground }]}>{users.length}</Text>
                </TouchableOpacity>
              ) : null,
            )}
          </View>
        )}

        {/* Context menu for emoji messages */}
        <ContextMenu
          visible={showMenu}
          onClose={() => setShowMenu(false)}
          onReply={handleReply}
          onCopy={undefined}
          onEdit={undefined}
          onDelete={canDelete ? handleDelete : undefined}
          onReact={(emoji) => { onReact(message.id, emoji); setShowMenu(false); }}
          colors={colors}
        />
      </View>
    );
  }

  // ── Regular message ────────────────────────────────────────────────────
  return (
    <View style={[styles.row, isSelf ? styles.rowSelf : styles.rowOther]}>
      {/* Avatar */}
      {!isSelf && showAvatar && (
        <UserAvatar uri={message.sender.avatar} size={30} isVerified={message.sender.isVerified} profileBorder={message.sender.profileBorder} />
      )}
      {!isSelf && !showAvatar && <View style={{ width: 30 }} />}

      <View style={[styles.bubbleContainer, isSelf && styles.bubbleContainerSelf]}>
        {/* Sender name + badges */}
        {!isSelf && (
          <View style={styles.senderRow}>
            <Text style={[styles.senderName, { color: colors.gold }]} numberOfLines={1}>
              {message.sender.displayName}
            </Text>
            {message.sender.isVerified && <VerifiedBadge />}
          </View>
        )}

        {/* Reply preview */}
        {message.replyTo && !isDeleted && (
          <View style={[styles.replyPreview, { backgroundColor: isSelf ? "rgba(255,255,255,0.08)" : colors.surfaceHigh, borderLeftColor: colors.gold }]}>
            <Text style={[styles.replyPreviewName, { color: colors.gold }]} numberOfLines={1}>{message.replyTo.senderName}</Text>
            <Text style={[styles.replyPreviewContent, { color: colors.mutedForeground }]} numberOfLines={2}>
              {message.replyTo.type === "image" ? "📷 صورة" : message.replyTo.type === "video" ? "🎥 فيديو" : message.replyTo.content ?? "رسالة"}
            </Text>
          </View>
        )}

        {/* Bubble */}
        <View style={{ position: "relative" }}>
          <TouchableOpacity
            onPress={handleTap}
            onLongPress={() => !isDeleted && setShowMenu(true)}
            activeOpacity={isDeleted ? 1 : 0.88}
            style={[
              styles.bubble,
              {
                backgroundColor: isDeleted ? colors.surface : (isSelf ? selfBg : colors.card),
                borderColor: isDeleted ? colors.border : (isSelf ? selfBorder : colors.border),
                borderBottomLeftRadius: isSelf ? 14 : 4,
                borderBottomRightRadius: isSelf ? 4 : 14,
                opacity: isDeleted ? 0.55 : 1,
              },
            ]}
          >
            {isDeleted ? (
              <Text style={[styles.deletedText, { color: colors.mutedForeground }]}>🚫 تم حذف الرسالة</Text>
            ) : (
              <>
                {/* Image */}
                {message.mediaUrl && message.type === "image" && (
                  <TouchableOpacity onPress={() => setShowFullImage(true)}>
                    <Image source={{ uri: resolveMediaUrl(message.mediaUrl) }} style={styles.mediaImage} resizeMode="cover" />
                  </TouchableOpacity>
                )}

                {/* Video */}
                {message.mediaUrl && message.type === "video" && (
                  <VideoPlayer uri={resolveMediaUrl(message.mediaUrl) ?? message.mediaUrl} thumbnail />
                )}

                {/* Text */}
                {message.content ? (
                  <Text style={[styles.content, { color: isSelf ? "#FFFFFF" : colors.foreground }]}>
                    {message.content}
                  </Text>
                ) : null}

                {/* Time row */}
                <View style={styles.timeRow}>
                  {message.editedAt && (
                    <Text style={[styles.editedTag, { color: isSelf ? "rgba(255,255,255,0.5)" : colors.mutedForeground }]}>edited</Text>
                  )}
                  <Text style={[styles.time, { color: isSelf ? "rgba(255,255,255,0.55)" : colors.mutedForeground }]}>{time}</Text>
                  {isSelf && <Ionicons name="checkmark-done" size={12} color={colors.gold} />}
                </View>
              </>
            )}
          </TouchableOpacity>

          {/* Floating heart animation */}
          <Animated.View style={[styles.floatingHeart, { opacity: heartOpacity, transform: [{ scale: heartScale }] }]}>
            <Text style={{ fontSize: 36 }}>❤️</Text>
          </Animated.View>
        </View>

        {/* Reactions */}
        {totalReactions > 0 && !isDeleted && (
          <View style={[styles.reactions, isSelf && styles.reactionsSelf]}>
            {Object.entries(message.reactions).map(([emoji, users]) =>
              users.length > 0 ? (
                <TouchableOpacity key={emoji} style={[styles.reactionBadge, { backgroundColor: colors.surface, borderColor: colors.border }]} onPress={() => onReact(message.id, emoji)}>
                  <TwemojiImage emoji={emoji} size={14} />
                  <Text style={[styles.reactionCount, { color: colors.mutedForeground }]}>{users.length}</Text>
                </TouchableOpacity>
              ) : null,
            )}
          </View>
        )}
      </View>

      {/* Context Menu */}
      <ContextMenu
        visible={showMenu}
        onClose={() => setShowMenu(false)}
        onReply={handleReply}
        onCopy={message.content ? handleCopy : undefined}
        onEdit={canEdit ? handleEdit : undefined}
        onDelete={canDelete ? handleDelete : undefined}
        onReact={(emoji) => { onReact(message.id, emoji); setShowMenu(false); }}
        colors={colors}
      />

      {/* Full image viewer */}
      {message.mediaUrl && message.type === "image" && (
        <Modal visible={showFullImage} transparent animationType="fade" onRequestClose={() => setShowFullImage(false)}>
          <TouchableOpacity style={styles.fullImageOverlay} activeOpacity={1} onPress={() => setShowFullImage(false)}>
            <Image source={{ uri: resolveMediaUrl(message.mediaUrl) }} style={styles.fullImage} resizeMode="contain" />
          </TouchableOpacity>
        </Modal>
      )}
    </View>
  );
}

// ── Sub-components ────────────────────────────────────────────────────────────

function VerifiedBadge() {
  return (
    <View style={styles.verifiedBadge}>
      <MaterialIcons name="verified" size={15} color="#1DA1F2" />
    </View>
  );
}

function AdminBadge({ colors }: { colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[styles.adminBadge, { backgroundColor: colors.adminBg ?? "#1A0000", borderColor: (colors.adminColor ?? "#FF4444") + "44" }]}>
      <Ionicons name="shield" size={10} color={colors.adminColor ?? "#FF4444"} />
      <Text style={[styles.adminText, { color: colors.adminColor ?? "#FF4444" }]}>ADMIN</Text>
    </View>
  );
}

interface ContextMenuProps {
  visible: boolean;
  onClose: () => void;
  onReply?: () => void;
  onCopy?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  onReact: (emoji: string) => void;
  colors: ReturnType<typeof useColors>;
}

function ContextMenu({ visible, onClose, onReply, onCopy, onEdit, onDelete, onReact, colors }: ContextMenuProps) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={onClose}>
        <View style={[styles.menuCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {/* Reaction row */}
          <View style={styles.emojiReactRow}>
            {REACTION_EMOJIS.map((emoji) => (
              <TouchableOpacity key={emoji} style={styles.emojiBtn} onPress={() => onReact(emoji)}>
                <TwemojiImage emoji={emoji} size={28} />
              </TouchableOpacity>
            ))}
          </View>
          <View style={[styles.menuDivider, { backgroundColor: colors.border }]} />

          {onReply && (
            <TouchableOpacity style={styles.menuAction} onPress={onReply}>
              <Ionicons name="arrow-undo-outline" size={19} color={colors.gold} />
              <Text style={[styles.menuActionText, { color: colors.foreground }]}>رد</Text>
            </TouchableOpacity>
          )}
          {onCopy && (
            <TouchableOpacity style={styles.menuAction} onPress={onCopy}>
              <Ionicons name="copy-outline" size={19} color={colors.gold} />
              <Text style={[styles.menuActionText, { color: colors.foreground }]}>نسخ</Text>
            </TouchableOpacity>
          )}
          {onEdit && (
            <TouchableOpacity style={styles.menuAction} onPress={onEdit}>
              <Ionicons name="pencil-outline" size={19} color={colors.indigoBright ?? "#3D5AFE"} />
              <Text style={[styles.menuActionText, { color: colors.foreground }]}>تعديل</Text>
            </TouchableOpacity>
          )}
          {onDelete && (
            <TouchableOpacity style={styles.menuAction} onPress={onDelete}>
              <Ionicons name="trash-outline" size={19} color={colors.destructive} />
              <Text style={[styles.menuActionText, { color: colors.destructive }]}>حذف</Text>
            </TouchableOpacity>
          )}
        </View>
      </TouchableOpacity>
    </Modal>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  row: { flexDirection: "row", marginHorizontal: 10, marginVertical: 2, alignItems: "flex-end", gap: 7 },
  rowSelf: { flexDirection: "row-reverse" },
  rowOther: {},

  // Emoji-only
  emojiBubble: { position: "relative" },
  emojiRow: { flexDirection: "row", gap: 6, alignItems: "center", paddingHorizontal: 4, paddingVertical: 4 },
  emojiRowSelf: { justifyContent: "flex-end" },
  emojiTime: { fontSize: 10, textAlign: "right", marginTop: 2, paddingHorizontal: 4 },

  floatingHeart: {
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -20,
    marginLeft: -20,
    pointerEvents: "none",
  },

  // Regular bubble
  bubbleContainer: { maxWidth: "78%" },
  bubbleContainerSelf: { alignItems: "flex-end" },
  senderRow: { flexDirection: "row", alignItems: "center", marginBottom: 3, gap: 4, flexWrap: "wrap" },
  senderName: { fontSize: 12, fontWeight: "700" as const, fontFamily: "Inter_700Bold", maxWidth: 120 },

  verifiedBadge: { borderRadius: 8 },
  adminBadge: {
    flexDirection: "row", alignItems: "center", gap: 2,
    borderRadius: 6, paddingHorizontal: 5, paddingVertical: 2,
    borderWidth: StyleSheet.hairlineWidth,
  },
  adminText: { fontSize: 9, fontWeight: "700" as const, letterSpacing: 0.5 },
  titleTag: {
    fontSize: 10, fontWeight: "600" as const,
    borderWidth: 1, borderRadius: 4, paddingHorizontal: 4, paddingVertical: 1,
  },

  replyPreview: { borderLeftWidth: 3, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 5, marginBottom: 4, gap: 2 },
  replyPreviewName: { fontSize: 11, fontWeight: "700" as const },
  replyPreviewContent: { fontSize: 12, fontFamily: "Inter_400Regular" },

  bubble: { borderRadius: 16, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 8, gap: 3 },
  deletedText: { fontSize: 13, fontStyle: "italic", fontFamily: "Inter_400Regular" },
  mediaImage: { width: 210, height: 155, borderRadius: 10, marginBottom: 4 },
  content: { fontSize: 15, lineHeight: 22, fontFamily: "Inter_400Regular" },
  timeRow: { flexDirection: "row", alignItems: "center", gap: 4, alignSelf: "flex-end", marginTop: 2 },
  editedTag: { fontSize: 10, fontStyle: "italic" },
  time: { fontSize: 10 },

  reactions: { flexDirection: "row", flexWrap: "wrap", gap: 5, marginTop: 4 },
  reactionsSelf: { justifyContent: "flex-end" },
  reactionBadge: {
    flexDirection: "row", alignItems: "center",
    borderWidth: 1, borderRadius: 14,
    paddingHorizontal: 7, paddingVertical: 3, gap: 4,
  },
  reactionCount: { fontSize: 11, fontWeight: "600" as const },

  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.78)", justifyContent: "center", alignItems: "center" },
  menuCard: { width: 280, borderRadius: 20, borderWidth: 1, overflow: "hidden", paddingVertical: 6 },
  emojiReactRow: { flexDirection: "row", justifyContent: "space-around", paddingHorizontal: 10, paddingVertical: 10 },
  emojiBtn: { padding: 5 },
  menuDivider: { height: StyleSheet.hairlineWidth, marginHorizontal: 12, marginBottom: 4 },
  menuAction: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 20, paddingVertical: 13 },
  menuActionText: { fontSize: 15, fontFamily: "Inter_400Regular" },

  fullImageOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.97)", justifyContent: "center", alignItems: "center" },
  fullImage: { width: "100%", height: "82%" },
});
