/**
 * LuxChat design tokens — dark luxury theme.
 * Deep black backgrounds with vibrant, saturated accent colors.
 */

const colors = {
  dark: {
    // Legacy aliases
    text: "#FFFFFF",
    tint: "#FFD700",

    // Core surfaces
    background: "#080808",
    foreground: "#F8F8F8",

    // Elevated surfaces
    card: "#111111",
    cardForeground: "#F8F8F8",

    // Primary action — vivid gold
    primary: "#FFD700",
    primaryForeground: "#060606",

    // Secondary surfaces
    secondary: "#181818",
    secondaryForeground: "#F0F0F0",

    // Muted
    muted: "#161616",
    mutedForeground: "#888888",

    // Accent = gold
    accent: "#FFD700",
    accentForeground: "#060606",

    // Destructive
    destructive: "#FF3B3B",
    destructiveForeground: "#FFFFFF",

    // Borders and inputs
    border: "#252525",
    input: "#181818",

    // ── Core LuxChat tokens ──
    gold: "#FFD700",
    goldDim: "#B8860B",
    goldLight: "#FFF59D",
    surface: "#161616",
    surfaceHigh: "#1E1E1E",
    onlineGreen: "#00E676",
    verifiedBlue: "#2196F3",
    couplePink: "#FF4081",
    messageBubbleSelf: "#1A0D5E",       // deep indigo-purple for self messages
    messageBubbleSelfBorder: "#4A2FBF",
    messageBubbleOther: "#141414",
    tabBar: "#0A0A0A",
    chatInput: "#1A1A1A",
    gradientStart: "#080808",
    gradientEnd: "#141414",

    // Admin color
    adminColor: "#FF4444",
    adminBg: "#1A0000",

    // ── VIP accent colors ──
    vipVerifiedBlue: "#2196F3",
    vipPurple: "#9C27B0",
    vipPurpleLight: "#CE93D8",
    vipGold: "#FFD700",
    vipDiamond: "#00E5FF",
    vipDiamondLight: "#B3F5FF",
    vipOrange: "#FF6D00",
    vipGreen: "#00E676",
    vipCrimson: "#D32F2F",

    // ── Vivid extra accents (saturated) ──
    neonPink: "#FF1744",
    neonCyan: "#00E5FF",
    electricViolet: "#651FFF",
    limeGreen: "#76FF03",
    deepPurple: "#4A148C",
    indigoBright: "#3D5AFE",
    amberGlow: "#FFB300",
    tealBright: "#1DE9B6",

    // TITLE_COLORS map
    moderatorColor: "#FF6D00",
    leaderColor: "#00E676",
    emperorColor: "#D32F2F",
  },
  light: {
    text: "#111111",
    tint: "#B8860B",
    background: "#F7F7F5",
    foreground: "#171717",
    card: "#FFFFFF",
    cardForeground: "#171717",
    primary: "#B8860B",
    primaryForeground: "#FFFFFF",
    secondary: "#ECECE8",
    secondaryForeground: "#222222",
    muted: "#E9E9E5",
    mutedForeground: "#6B6B6B",
    accent: "#B8860B",
    accentForeground: "#FFFFFF",
    destructive: "#D92D20",
    destructiveForeground: "#FFFFFF",
    border: "#D9D9D3",
    input: "#FFFFFF",
    gold: "#B8860B",
    goldDim: "#8A6508",
    goldLight: "#D8B84C",
    surface: "#EEEEEA",
    surfaceHigh: "#E4E4DF",
    onlineGreen: "#0A9F55",
    verifiedBlue: "#1976D2",
    couplePink: "#D81B60",
    messageBubbleSelf: "#E8E0FF",
    messageBubbleSelfBorder: "#9A83DB",
    messageBubbleOther: "#FFFFFF",
    tabBar: "#FFFFFF",
    chatInput: "#FFFFFF",
    gradientStart: "#F7F7F5",
    gradientEnd: "#EEEEEA",
    adminColor: "#C62828",
    adminBg: "#FFEBEE",
    vipVerifiedBlue: "#1976D2",
    vipPurple: "#7B1FA2",
    vipPurpleLight: "#AB47BC",
    vipGold: "#B8860B",
    vipDiamond: "#0097A7",
    vipDiamondLight: "#80DEEA",
    vipOrange: "#E65100",
    vipGreen: "#0A9F55",
    vipCrimson: "#B71C1C",
    neonPink: "#D81B60",
    neonCyan: "#008FA3",
    electricViolet: "#512DA8",
    limeGreen: "#558B2F",
    deepPurple: "#4527A0",
    indigoBright: "#304FFE",
    amberGlow: "#C77800",
    tealBright: "#00897B",
    moderatorColor: "#E65100",
    leaderColor: "#0A9F55",
    emperorColor: "#B71C1C",
  },

  radius: 14,
};

export default colors;
