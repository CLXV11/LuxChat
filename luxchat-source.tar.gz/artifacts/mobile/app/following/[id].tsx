/**
 * Following list screen for any user.
 */
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { useSocket } from "@/contexts/SocketContext";
import { UserAvatar } from "@/components/UserAvatar";
import { api } from "@/lib/api";

interface UserBasic {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  isVerified: boolean;
  isAdmin?: boolean;
  title: string | null;
  profileBorder: string | null;
}

export default function FollowingScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { token, user: me } = useAuth();
  const { onlineUsers } = useSocket();

  const [users, setUsers] = useState<UserBasic[]>([]);
  const [loading, setLoading] = useState(true);

  const isMine = id === me?.id;

  useEffect(() => {
    if (!token || !id) return;
    (isMine ? api.follows.myFollowing(token) : api.follows.following(token, id))
      .then((res) => setUsers(res as UserBasic[]))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token, id, isMine]);

  const topPad = insets.top + (Platform.OS === "web" ? 67 : 0);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 8, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={26} color={colors.gold} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>يتابعهم</Text>
        <View style={{ width: 26 }} />
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator color={colors.gold} size="large" />
        </View>
      ) : (
        <FlatList
          data={users}
          keyExtractor={(u) => u.id}
          contentContainerStyle={{ paddingTop: 8, paddingBottom: insets.bottom + 40 }}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="person-outline" size={50} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>لا يتابع أحداً بعد</Text>
            </View>
          }
          renderItem={({ item }) => {
            const isOnline = onlineUsers.includes(item.id);
            return (
              <TouchableOpacity
                style={[styles.userRow, { borderBottomColor: colors.border }]}
                onPress={() => router.push(`/user/${item.id}`)}
                activeOpacity={0.7}
              >
                <UserAvatar uri={item.avatar} size={48} isVerified={item.isVerified} isOnline={isOnline} profileBorder={item.profileBorder} showOnline />
                <View style={{ flex: 1 }}>
                  <View style={styles.nameRow}>
                    <Text style={[styles.displayName, { color: colors.foreground }]}>{item.displayName}</Text>
                    {item.isVerified && <Ionicons name="checkmark-circle" size={14} color={colors.verifiedBlue} />}
                  </View>
                  <View style={styles.subRow}>
                    <Text style={[styles.username, { color: colors.mutedForeground }]}>@{item.username}</Text>
                    {isOnline && <View style={[styles.onlineDot, { backgroundColor: colors.onlineGreen }]} />}
                  </View>
                </View>
                <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
              </TouchableOpacity>
            );
          }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  title: { fontSize: 18, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  loadingContainer: { flex: 1, alignItems: "center", justifyContent: "center" },
  emptyContainer: { alignItems: "center", justifyContent: "center", paddingTop: 80, gap: 14 },
  emptyText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  userRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 18, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  nameRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  displayName: { fontSize: 15, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  adminBadge: { borderRadius: 5, padding: 2 },
  subRow: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 2 },
  username: { fontSize: 13, fontFamily: "Inter_400Regular" },
  titleTag: { fontSize: 11, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  onlineDot: { width: 7, height: 7, borderRadius: 3.5 },
});
