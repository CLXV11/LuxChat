/**
 * Login screen — vibrant multi-color luxury design.
 */
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { useAuth } from "@/contexts/AuthContext";
import { useColors } from "@/hooks/useColors";

export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { login } = useAuth();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!username.trim() || !password.trim()) {
      Alert.alert("خطأ", "يرجى ملء جميع الحقول");
      return;
    }
    setLoading(true);
    try {
      await login(username.trim(), password);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace("/(tabs)/chats");
    } catch (err) {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert("فشل تسجيل الدخول", err instanceof Error ? err.message : "بيانات غير صحيحة");
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient
      colors={["#0D0021", "#0A0A2E", "#0A0A0A"]}
      locations={[0, 0.45, 1]}
      style={styles.gradient}
    >
      {/* Decorative colored orbs */}
      <View style={[styles.orb, styles.orbPurple]} />
      <View style={[styles.orb, styles.orbBlue]} />
      <View style={[styles.orb, styles.orbGold]} />

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.keyboardView}
      >
        <View
          style={[
            styles.container,
            {
              paddingTop: insets.top + (Platform.OS === "web" ? 67 : 20),
              paddingBottom: insets.bottom + 20,
            },
          ]}
        >
          {/* Logo */}
          <View style={styles.logoSection}>
            <LinearGradient
              colors={["#9B59B6", "#1D9BF0", "#FFD700"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.logoRing}
            >
              <View style={styles.logoInner}>
                <Ionicons name="chatbubbles" size={44} color="#FFFFFF" />
              </View>
            </LinearGradient>
            <Text style={styles.appName}>LuxChat</Text>
            <Text style={[styles.tagline, { color: colors.mutedForeground }]}>
              ✨ المراسلة الفاخرة في الوقت الفعلي
            </Text>
          </View>

          {/* Form card */}
          <View style={[styles.formCard, { backgroundColor: "rgba(255,255,255,0.05)", borderColor: "rgba(255,255,255,0.08)" }]}>
            {/* Username */}
            <View style={[styles.inputWrapper, { borderColor: "#2A2A4A", backgroundColor: "#0D0D1F" }]}>
              <Ionicons name="person-outline" size={20} color="#9B59B6" />
              <TextInput
                style={[styles.input, { color: colors.foreground }]}
                placeholder="اسم المستخدم"
                placeholderTextColor={colors.mutedForeground}
                value={username}
                onChangeText={setUsername}
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>

            {/* Password */}
            <View style={[styles.inputWrapper, { borderColor: "#2A2A4A", backgroundColor: "#0D0D1F" }]}>
              <Ionicons name="lock-closed-outline" size={20} color="#1D9BF0" />
              <TextInput
                style={[styles.input, { color: colors.foreground }]}
                placeholder="كلمة المرور"
                placeholderTextColor={colors.mutedForeground}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
              />
              <TouchableOpacity onPress={() => setShowPassword((p) => !p)}>
                <Ionicons
                  name={showPassword ? "eye-off-outline" : "eye-outline"}
                  size={20}
                  color={colors.mutedForeground}
                />
              </TouchableOpacity>
            </View>

            {/* Sign in button */}
            <LinearGradient
              colors={["#9B59B6", "#1D9BF0"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={[styles.buttonGradient, { opacity: loading ? 0.7 : 1 }]}
            >
              <TouchableOpacity
                style={styles.button}
                onPress={handleLogin}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text style={styles.buttonText}>تسجيل الدخول</Text>
                )}
              </TouchableOpacity>
            </LinearGradient>

            <TouchableOpacity
              style={styles.registerLink}
              onPress={() => router.push("/register")}
            >
              <Text style={[styles.registerText, { color: colors.mutedForeground }]}>
                جديد على LuxChat؟{" "}
                <Text style={{ color: "#FFD700", fontWeight: "700" }}>
                  إنشاء حساب
                </Text>
              </Text>
            </TouchableOpacity>
          </View>

        </View>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: { flex: 1 },
  keyboardView: { flex: 1 },
  orb: {
    position: "absolute",
    borderRadius: 999,
    opacity: 0.18,
  },
  orbPurple: {
    width: 260,
    height: 260,
    backgroundColor: "#9B59B6",
    top: -80,
    left: -80,
  },
  orbBlue: {
    width: 200,
    height: 200,
    backgroundColor: "#1D9BF0",
    top: 60,
    right: -60,
  },
  orbGold: {
    width: 180,
    height: 180,
    backgroundColor: "#FFD700",
    bottom: 80,
    right: 40,
    opacity: 0.10,
  },
  container: {
    flex: 1,
    paddingHorizontal: 24,
    justifyContent: "center",
    gap: 28,
  },
  logoSection: {
    alignItems: "center",
    gap: 12,
  },
  logoRing: {
    width: 96,
    height: 96,
    borderRadius: 48,
    alignItems: "center",
    justifyContent: "center",
    padding: 3,
  },
  logoInner: {
    width: "100%",
    height: "100%",
    borderRadius: 45,
    backgroundColor: "#0A0A1A",
    alignItems: "center",
    justifyContent: "center",
  },
  appName: {
    fontSize: 38,
    fontWeight: "700",
    fontFamily: "Inter_700Bold",
    color: "#FFFFFF",
    letterSpacing: 2,
  },
  tagline: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  formCard: {
    borderWidth: 1,
    borderRadius: 24,
    padding: 20,
    gap: 14,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    gap: 12,
  },
  input: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  buttonGradient: {
    borderRadius: 14,
    marginTop: 4,
  },
  button: {
    paddingVertical: 16,
    alignItems: "center",
  },
  buttonText: {
    fontSize: 16,
    fontWeight: "700",
    fontFamily: "Inter_700Bold",
    color: "#FFFFFF",
    letterSpacing: 0.5,
  },
  registerLink: {
    alignItems: "center",
    paddingVertical: 4,
  },
  registerText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
  pills: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    justifyContent: "center",
  },
  pill: {
    backgroundColor: "rgba(255,255,255,0.06)",
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },
  pillText: {
    fontSize: 11,
    color: "rgba(255,255,255,0.7)",
    fontFamily: "Inter_400Regular",
  },
});
