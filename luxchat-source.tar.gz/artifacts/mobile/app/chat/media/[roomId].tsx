/**
 * Media Gallery — shows all images and videos shared in a conversation.
 */
import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  Modal,
  ActivityIndicator,
  Dimensions,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { VideoPlayer } from "@/components/VideoPlayer";
import { api, resolveMediaUrl } from "@/lib/api";

interface MediaItem {
  id: string;
  type: "image" | "video";
  mediaUrl: string;
  createdAt: string;
  sender?: { displayName: string };
}

const { width: SW } = Dimensions.get("window");
const COL = 3;
const CELL = (SW - 4) / COL;

export default function MediaGalleryScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { roomId } = useLocalSearchParams<{ roomId: string }>();
  const { token } = useAuth();

  const [media, setMedia] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<MediaItem | null>(null);

  const topPad = insets.top + (Platform.OS === "web" ? 67 : 0);

  const load = useCallback(async () => {
    if (!token || !roomId) return;
    try {
      const data = await api.messages.roomMedia(token, roomId);
      setMedia(data as MediaItem[]);
    } catch {}
    finally { setLoading(false); }
  }, [token, roomId]);

  useEffect(() => { void load(); }, [load]);

  const renderItem = ({ item }: { item: MediaItem }) => {
    const uri = resolveMediaUrl(item.mediaUrl) ?? item.mediaUrl;
    return (
      <TouchableOpacity
        style={styles.cell}
        onPress={() => setSelected(item)}
        activeOpacity={0.8}
      >
        {item.type === "video" ? (
          <View style={[styles.cellInner, { backgroundColor: "#111" }]}>
            <Ionicons name="play-circle" size={36} color="rgba(255,255,255,0.8)" />
          </View>
        ) : (
          <Image source={{ uri }} style={styles.cellInner} resizeMode="cover" />
        )}
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={["#0D0021", "#0A0A1E", colors.background]}
        style={[styles.header, { paddingTop: topPad + 8, borderBottomColor: colors.border }]}
      >
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={26} color={colors.gold} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>الوسائط المشتركة</Text>
        <View style={{ width: 26 }} />
      </LinearGradient>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.gold} size="large" />
        </View>
      ) : media.length === 0 ? (
        <View style={styles.center}>
          <Ionicons name="images-outline" size={52} color={colors.mutedForeground} />
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>لا توجد وسائط مشتركة</Text>
        </View>
      ) : (
        <FlatList
          data={media}
          keyExtractor={(m) => m.id}
          renderItem={renderItem}
          numColumns={COL}
          contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* Full viewer */}
      <Modal visible={!!selected} transparent animationType="fade" onRequestClose={() => setSelected(null)}>
        <View style={styles.viewerOverlay}>
          <TouchableOpacity style={styles.viewerClose} onPress={() => setSelected(null)}>
            <Ionicons name="close-circle" size={34} color="#fff" />
          </TouchableOpacity>
          {selected?.type === "video" ? (
            <VideoPlayer uri={resolveMediaUrl(selected.mediaUrl) ?? selected.mediaUrl} />
          ) : selected ? (
            <Image
              source={{ uri: resolveMediaUrl(selected.mediaUrl) ?? selected.mediaUrl }}
              style={styles.viewerImage}
              resizeMode="contain"
            />
          ) : null}
          {selected?.sender && (
            <Text style={styles.viewerSender}>{selected.sender.displayName}</Text>
          )}
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: StyleSheet.hairlineWidth,
  },
  headerTitle: { fontSize: 17, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  emptyText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  cell: { width: CELL, height: CELL, padding: 1 },
  cellInner: { flex: 1, borderRadius: 4, alignItems: "center", justifyContent: "center" },
  viewerOverlay: {
    flex: 1, backgroundColor: "#000",
    alignItems: "center", justifyContent: "center",
  },
  viewerClose: { position: "absolute", top: 55, right: 18, zIndex: 10 },
  viewerImage: { width: SW, height: SW * 1.2 },
  viewerSender: { position: "absolute", bottom: 60, color: "rgba(255,255,255,0.7)", fontSize: 13 },
});
