/**
 * Global chat room — real-time messages via Socket.io.
 * Supports text, image, video sending, delete (removes from list), edit, reply.
 */
import React, { useEffect, useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  Platform,
  ActivityIndicator,
  Alert,
} from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { useSocket } from "@/contexts/SocketContext";
import { MessageBubble, type MessageData } from "@/components/MessageBubble";
import { api } from "@/lib/api";

const ROOM_ID = "global";

export default function GlobalChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { token, user } = useAuth();
  const { socket } = useSocket();

  const [messages, setMessages] = useState<MessageData[]>([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [replyTo, setReplyTo] = useState<MessageData | null>(null);
  const [editingMessage, setEditingMessage] = useState<MessageData | null>(null);

  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const flatListRef = useRef<import("react-native").FlatList>(null);

  useEffect(() => {
    if (!token) return;
    api.messages.global(token)
      .then((msgs) => setMessages(msgs as MessageData[]))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token]);

  useEffect(() => {
    if (!socket) return;
    socket.emit("join_room", ROOM_ID);

    const onMessage = (msg: MessageData) => {
      setMessages((prev) => [...prev, msg]);
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 50);
    };
    const onReaction = (data: { messageId: string; reactions: Record<string, string[]> }) => {
      setMessages((prev) => prev.map((m) => m.id === data.messageId ? { ...m, reactions: data.reactions } : m));
    };
    const onTyping = (data: { userId: string; username: string; isTyping: boolean }) => {
      if (data.userId === user?.id) return;
      setTypingUsers((prev) =>
        data.isTyping ? (prev.includes(data.username) ? prev : [...prev, data.username]) : prev.filter((u) => u !== data.username),
      );
    };
    // Delete: remove message entirely
    const onMessageDeleted = (data: { messageId: string }) => {
      setMessages((prev) => prev.filter((m) => m.id !== data.messageId));
    };
    const onMessageEdited = (data: { messageId: string; content: string; editedAt: string }) => {
      setMessages((prev) => prev.map((m) => m.id === data.messageId ? { ...m, content: data.content, editedAt: data.editedAt } : m));
    };

    socket.on("new_message", onMessage);
    socket.on("reaction_updated", onReaction);
    socket.on("typing", onTyping);
    socket.on("message_deleted", onMessageDeleted);
    socket.on("message_edited", onMessageEdited);

    return () => {
      socket.off("new_message", onMessage);
      socket.off("reaction_updated", onReaction);
      socket.off("typing", onTyping);
      socket.off("message_deleted", onMessageDeleted);
      socket.off("message_edited", onMessageEdited);
      socket.emit("leave_room", ROOM_ID);
    };
  }, [socket, user?.id]);

  const handleTyping = (val: string) => {
    setText(val);
    if (!socket) return;
    socket.emit("typing", { roomId: ROOM_ID, isTyping: true });
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      socket.emit("typing", { roomId: ROOM_ID, isTyping: false });
    }, 1500);
  };

  const sendMessage = useCallback(() => {
    if (!socket || !text.trim()) return;
    if (editingMessage) {
      socket.emit("edit_message", { messageId: editingMessage.id, content: text.trim(), roomId: ROOM_ID });
      setEditingMessage(null);
    } else {
      socket.emit("send_message", { roomId: ROOM_ID, content: text.trim(), type: "text", replyToId: replyTo?.id });
      setReplyTo(null);
    }
    setText("");
    socket.emit("typing", { roomId: ROOM_ID, isTyping: false });
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
  }, [socket, text, editingMessage, replyTo]);

  const sendMedia = async (mediaType: "image" | "video") => {
    if (!token || !socket) return;
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: mediaType === "video" ? ImagePicker.MediaTypeOptions.Videos : ImagePicker.MediaTypeOptions.Images,
      quality: 0.85,
      videoMaxDuration: 60,
    });
    if (result.canceled || !result.assets[0]) return;

    setUploading(true);
    setUploadProgress(0);

    try {
      const { url, type } = await api.users.uploadMedia(
        token,
        result.assets[0].uri,
        (pct) => setUploadProgress(pct),
      );
      setUploadProgress(100);
      socket.emit("send_message", { roomId: ROOM_ID, type, mediaUrl: url, replyToId: replyTo?.id });
      setReplyTo(null);
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setTimeout(() => { setUploading(false); setUploadProgress(0); }, 500);
    } catch {
      Alert.alert("خطأ", "فشل رفع الوسائط");
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const handleReact = useCallback((messageId: string, emoji: string) => {
    if (!socket) return;
    socket.emit("add_reaction", { messageId, emoji, roomId: ROOM_ID });
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }, [socket]);

  const handleDelete = useCallback((messageId: string) => {
    if (!socket) return;
    socket.emit("delete_message", { messageId, roomId: ROOM_ID });
  }, [socket]);

  const handleEdit = useCallback((message: MessageData) => {
    setEditingMessage(message);
    setText(message.content ?? "");
  }, []);

  const handleReply = useCallback((message: MessageData) => {
    setReplyTo(message);
  }, []);

  const cancelEditOrReply = () => {
    setEditingMessage(null);
    setReplyTo(null);
    setText("");
  };

  const topPad = insets.top + (Platform.OS === "web" ? 67 : 0);
  const botPad = insets.bottom + (Platform.OS === "web" ? 34 : 0);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 10, borderBottomColor: colors.border, backgroundColor: colors.card }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={24} color={colors.gold} />
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <View style={[styles.headerIcon, { backgroundColor: colors.gold + "20" }]}>
            <Ionicons name="earth" size={20} color={colors.gold} />
          </View>
          <View>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>الدردشة العامة</Text>
            <Text style={[styles.headerSub, { color: colors.mutedForeground }]}>الجميع</Text>
          </View>
        </View>
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding" keyboardVerticalOffset={0}>
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator color={colors.gold} size="large" />
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={(m) => m.id}
            renderItem={({ item, index }) => (
              <MessageBubble
                message={item}
                isSelf={item.sender.id === user?.id}
                isAdmin={!!user?.isAdmin}
                onReact={handleReact}
                onDelete={handleDelete}
                onEdit={handleEdit}
                onReply={handleReply}
                showAvatar={index === 0 || messages[index - 1]?.sender.id !== item.sender.id}
              />
            )}
            contentContainerStyle={[styles.messageList, { paddingBottom: 16 }]}
            ListFooterComponent={
              typingUsers.length > 0 ? (
                <View style={[styles.typingIndicator, { backgroundColor: colors.card }]}>
                  <Text style={[styles.typingText, { color: colors.mutedForeground }]}>
                    {typingUsers.join(", ")} {typingUsers.length === 1 ? "يكتب..." : "يكتبون..."}
                  </Text>
                </View>
              ) : null
            }
            onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
          />
        )}

        {/* Upload progress */}
        {uploading && (
          <View style={[styles.uploadBar, { backgroundColor: colors.surface }]}>
            <View style={[styles.uploadBarFill, { backgroundColor: colors.gold, width: `${uploadProgress}%` as unknown as number }]} />
            <Text style={[styles.uploadText, { color: colors.foreground }]}>
              {uploadProgress < 100 ? `جاري الرفع... ${uploadProgress}%` : "تم الرفع ✓"}
            </Text>
          </View>
        )}

        {/* Reply / Edit bar */}
        {(replyTo || editingMessage) && (
          <View style={[styles.replyBar, { backgroundColor: colors.surface, borderTopColor: colors.border, borderLeftColor: colors.gold }]}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.replyBarLabel, { color: colors.gold }]}>
                {editingMessage ? "تعديل الرسالة" : `الرد على ${replyTo?.sender.displayName}`}
              </Text>
              <Text style={[styles.replyBarContent, { color: colors.mutedForeground }]} numberOfLines={1}>
                {editingMessage?.content ?? replyTo?.content ?? (replyTo?.type === "video" ? "🎥 فيديو" : "📷 صورة")}
              </Text>
            </View>
            <TouchableOpacity onPress={cancelEditOrReply}>
              <Ionicons name="close-circle" size={22} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>
        )}

        {/* Input bar */}
        <View style={[styles.inputBar, { backgroundColor: colors.card, borderTopColor: colors.border, paddingBottom: botPad + 8 }]}>
          <TouchableOpacity onPress={() => sendMedia("image")} disabled={uploading}>
            <Ionicons name="image-outline" size={24} color={uploading ? colors.mutedForeground : colors.gold} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => sendMedia("video")} disabled={uploading}>
            <Ionicons name="videocam-outline" size={24} color={uploading ? colors.mutedForeground : colors.gold} />
          </TouchableOpacity>

          <TextInput
            style={[styles.textInput, { backgroundColor: colors.chatInput, color: colors.foreground, borderColor: colors.border }]}
            placeholder={editingMessage ? "عدّل رسالتك..." : "رسالة..."}
            placeholderTextColor={colors.mutedForeground}
            value={text}
            onChangeText={handleTyping}
            multiline
            maxLength={2000}
          />
          <TouchableOpacity
            onPress={sendMessage}
            disabled={!text.trim()}
            style={[styles.sendBtn, { backgroundColor: text.trim() ? colors.gold : colors.surface }]}
          >
            <Ionicons name={editingMessage ? "checkmark" : "send"} size={17} color={text.trim() ? colors.primaryForeground : colors.mutedForeground} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 14, paddingBottom: 12, borderBottomWidth: StyleSheet.hairlineWidth, gap: 10 },
  headerInfo: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
  headerIcon: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 16, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  headerSub: { fontSize: 12, fontFamily: "Inter_400Regular" },
  loadingContainer: { flex: 1, alignItems: "center", justifyContent: "center" },
  messageList: { paddingTop: 16 },
  uploadBar: { marginHorizontal: 14, marginBottom: 6, borderRadius: 8, overflow: "hidden", height: 28, justifyContent: "center" },
  uploadBarFill: { position: "absolute", left: 0, top: 0, bottom: 0 },
  uploadText: { fontSize: 12, fontFamily: "Inter_400Regular", paddingHorizontal: 10, zIndex: 1 },
  replyBar: { flexDirection: "row", alignItems: "center", paddingHorizontal: 14, paddingVertical: 10, gap: 12, borderTopWidth: StyleSheet.hairlineWidth, borderLeftWidth: 3 },
  replyBarLabel: { fontSize: 12, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  replyBarContent: { fontSize: 12, fontFamily: "Inter_400Regular" },
  typingIndicator: { marginHorizontal: 16, marginBottom: 8, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, alignSelf: "flex-start" },
  typingText: { fontSize: 12, fontStyle: "italic" },
  inputBar: { flexDirection: "row", alignItems: "flex-end", paddingHorizontal: 12, paddingTop: 10, borderTopWidth: StyleSheet.hairlineWidth, gap: 8 },
  textInput: { flex: 1, borderRadius: 20, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 10, maxHeight: 120, fontSize: 15, fontFamily: "Inter_400Regular" },
  sendBtn: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
});
