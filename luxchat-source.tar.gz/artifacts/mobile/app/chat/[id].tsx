/**
 * Private chat room — reply, delete, edit, video, delete conversation, media gallery.
 */
import React, { useEffect, useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  Platform,
  ActivityIndicator,
  Alert,
  Modal,
} from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { useSocket } from "@/contexts/SocketContext";
import { MessageBubble, type MessageData } from "@/components/MessageBubble";
import { UserAvatar } from "@/components/UserAvatar";
import { api } from "@/lib/api";

interface OtherUser {
  id: string;
  displayName: string;
  username: string;
  avatar: string | null;
  isVerified: boolean;
  isAdmin?: boolean;
  title: string | null;
  profileBorder: string | null;
}

export default function PrivateChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id: otherId } = useLocalSearchParams<{ id: string }>();
  const { token, user } = useAuth();
  const { socket, onlineUsers } = useSocket();

  const [messages, setMessages] = useState<MessageData[]>([]);
  const [otherUser, setOtherUser] = useState<OtherUser | null>(null);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isTyping, setIsTyping] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  const [replyTo, setReplyTo] = useState<MessageData | null>(null);
  const [editingMessage, setEditingMessage] = useState<MessageData | null>(null);

  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const flatListRef = useRef<FlatList>(null);

  const roomId = [user?.id ?? "", otherId ?? ""].sort().join("_");

  useEffect(() => {
    if (!token || !otherId) return;
    Promise.all([api.users.get(token, otherId), api.messages.room(token, roomId)])
      .then(([u, msgs]) => {
        setOtherUser(u as OtherUser);
        setMessages(msgs as MessageData[]);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token, otherId, roomId]);

  useEffect(() => {
    if (!socket || !roomId) return;
    socket.emit("join_room", roomId);

    const onMessage = (msg: MessageData) => {
      if (msg.roomId !== roomId) return;
      setMessages((prev) => [...prev, msg]);
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 50);
    };

    const onReaction = (data: { messageId: string; reactions: Record<string, string[]> }) => {
      setMessages((prev) => prev.map((m) => m.id === data.messageId ? { ...m, reactions: data.reactions } : m));
    };

    const onTyping = (data: { userId: string; isTyping: boolean }) => {
      if (data.userId === otherId) setIsTyping(data.isTyping);
    };

    // Delete: remove message entirely from list
    const onMessageDeleted = (data: { messageId: string }) => {
      setMessages((prev) => prev.filter((m) => m.id !== data.messageId));
    };

    const onMessageEdited = (data: { messageId: string; content: string; editedAt: string }) => {
      setMessages((prev) => prev.map((m) => m.id === data.messageId ? { ...m, content: data.content, editedAt: data.editedAt } : m));
    };

    socket.on("new_message", onMessage);
    socket.on("reaction_updated", onReaction);
    socket.on("typing", onTyping);
    socket.on("message_deleted", onMessageDeleted);
    socket.on("message_edited", onMessageEdited);

    return () => {
      socket.off("new_message", onMessage);
      socket.off("reaction_updated", onReaction);
      socket.off("typing", onTyping);
      socket.off("message_deleted", onMessageDeleted);
      socket.off("message_edited", onMessageEdited);
      socket.emit("leave_room", roomId);
    };
  }, [socket, roomId, otherId]);

  const handleTyping = (val: string) => {
    setText(val);
    if (!socket) return;
    socket.emit("typing", { roomId, isTyping: true });
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      socket.emit("typing", { roomId, isTyping: false });
    }, 1500);
  };

  const sendMessage = useCallback(() => {
    if (!socket || !text.trim()) return;
    if (editingMessage) {
      socket.emit("edit_message", { messageId: editingMessage.id, content: text.trim(), roomId });
      setEditingMessage(null);
    } else {
      socket.emit("send_message", { roomId, content: text.trim(), type: "text", replyToId: replyTo?.id ?? undefined });
      setReplyTo(null);
    }
    setText("");
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
  }, [socket, text, roomId, replyTo, editingMessage]);

  const sendMedia = async (mediaType: "image" | "video") => {
    if (!token || !socket) return;
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: mediaType === "video" ? ImagePicker.MediaTypeOptions.Videos : ImagePicker.MediaTypeOptions.Images,
      quality: 0.85,
      videoMaxDuration: 60,
    });
    if (result.canceled || !result.assets[0]) return;

    setUploading(true);
    setUploadProgress(0);

    try {
      const { url, type } = await api.users.uploadMedia(
        token,
        result.assets[0].uri,
        (pct) => setUploadProgress(pct),
      );
      setUploadProgress(100);
      socket.emit("send_message", { roomId, type, mediaUrl: url, replyToId: replyTo?.id });
      setReplyTo(null);
      setTimeout(() => { setUploading(false); setUploadProgress(0); }, 500);
    } catch {
      Alert.alert("خطأ", "فشل رفع الوسائط");
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const handleReact = useCallback((messageId: string, emoji: string) => {
    if (!socket) return;
    socket.emit("add_reaction", { messageId, emoji, roomId });
  }, [socket, roomId]);

  const handleDelete = useCallback((messageId: string) => {
    if (!socket) return;
    socket.emit("delete_message", { messageId, roomId });
  }, [socket, roomId]);

  const handleEdit = useCallback((message: MessageData) => {
    setEditingMessage(message);
    setText(message.content ?? "");
  }, []);

  const handleReply = useCallback((message: MessageData) => {
    setReplyTo(message);
  }, []);

  const cancelEditOrReply = () => {
    setEditingMessage(null);
    setReplyTo(null);
    setText("");
  };

  const deleteConversation = () => {
    setShowMenu(false);
    Alert.alert("حذف المحادثة", "سيتم حذف جميع الرسائل نهائياً.", [
      { text: "إلغاء", style: "cancel" },
      {
        text: "حذف الكل",
        style: "destructive",
        onPress: async () => {
          if (!token) return;
          try {
            await api.messages.deleteRoom(token, roomId);
            setMessages([]);
          } catch {
            Alert.alert("خطأ", "فشل حذف المحادثة");
          }
        },
      },
    ]);
  };

  const openMediaGallery = () => {
    setShowMenu(false);
    router.push(`/chat/media/${roomId}` as never);
  };

  const isOnline = onlineUsers.includes(otherId ?? "");
  const topPad = insets.top + (Platform.OS === "web" ? 67 : 0);
  const botPad = insets.bottom + (Platform.OS === "web" ? 34 : 0);
  const isAdmin = !!user?.isAdmin;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <LinearGradient
        colors={["#0D0021", "#0A0A1E", colors.background]}
        style={[styles.header, { paddingTop: topPad + 8, borderBottomColor: colors.border }]}
      >
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={26} color={colors.gold} />
        </TouchableOpacity>

        {otherUser && (
          <TouchableOpacity style={styles.headerInfo} onPress={() => router.push(`/user/${otherId}`)}>
            <UserAvatar uri={otherUser.avatar} size={36} isVerified={otherUser.isVerified} isOnline={isOnline} profileBorder={otherUser.profileBorder} showOnline />
            <View>
              <Text style={[styles.headerTitle, { color: colors.foreground }]} numberOfLines={1}>{otherUser.displayName}</Text>
              <Text style={[styles.headerSub, { color: isOnline ? colors.onlineGreen : colors.mutedForeground }]}>
                {isOnline ? "● متصل الآن" : "غير متصل"}
              </Text>
            </View>
          </TouchableOpacity>
        )}

        {/* Options menu */}
        <TouchableOpacity onPress={() => setShowMenu(true)}>
          <Ionicons name="ellipsis-vertical" size={22} color={colors.gold} />
        </TouchableOpacity>
      </LinearGradient>

      {/* Options menu modal */}
      <Modal visible={showMenu} transparent animationType="fade" onRequestClose={() => setShowMenu(false)}>
        <TouchableOpacity style={styles.menuOverlay} activeOpacity={1} onPress={() => setShowMenu(false)}>
          <View style={[styles.menuCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <TouchableOpacity style={styles.menuItem} onPress={openMediaGallery}>
              <Ionicons name="images-outline" size={20} color={colors.gold} />
              <Text style={[styles.menuItemText, { color: colors.foreground }]}>الوسائط المشتركة</Text>
            </TouchableOpacity>
            <View style={[styles.menuDivider, { backgroundColor: colors.border }]} />
            <TouchableOpacity style={styles.menuItem} onPress={deleteConversation}>
              <Ionicons name="trash-outline" size={20} color={colors.destructive} />
              <Text style={[styles.menuItemText, { color: colors.destructive }]}>حذف المحادثة</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding" keyboardVerticalOffset={0}>
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator color={colors.gold} size="large" />
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={(m) => m.id}
            renderItem={({ item, index }) => (
              <MessageBubble
                message={item}
                isSelf={item.sender.id === user?.id}
                isAdmin={isAdmin}
                onReact={handleReact}
                onDelete={handleDelete}
                onEdit={handleEdit}
                onReply={handleReply}
                showAvatar={index === 0 || messages[index - 1]?.sender.id !== item.sender.id}
              />
            )}
            contentContainerStyle={{ paddingTop: 12, paddingBottom: 12 }}
            onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
            ListEmptyComponent={
              <View style={styles.emptyChat}>
                <Text style={[styles.emptyChatText, { color: colors.mutedForeground }]}>
                  ابدأ المحادثة مع {otherUser?.displayName}
                </Text>
              </View>
            }
            ListFooterComponent={
              isTyping ? (
                <View style={[styles.typingIndicator, { backgroundColor: colors.card }]}>
                  <Text style={[styles.typingText, { color: colors.mutedForeground }]}>
                    {otherUser?.displayName} يكتب...
                  </Text>
                </View>
              ) : null
            }
          />
        )}

        {/* Upload progress */}
        {uploading && (
          <View style={[styles.uploadBar, { backgroundColor: colors.surface }]}>
            <View style={[styles.uploadBarFill, { backgroundColor: colors.gold, width: `${uploadProgress}%` as unknown as number }]} />
            <Text style={[styles.uploadText, { color: colors.foreground }]}>
              {uploadProgress < 100 ? `جاري الرفع... ${uploadProgress}%` : "تم الرفع ✓"}
            </Text>
          </View>
        )}

        {/* Reply / Edit bar */}
        {(replyTo || editingMessage) && (
          <View style={[styles.replyBar, { backgroundColor: colors.surface, borderTopColor: colors.border, borderLeftColor: colors.gold }]}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.replyBarLabel, { color: colors.gold }]}>
                {editingMessage ? "تعديل الرسالة" : `الرد على ${replyTo?.sender.displayName}`}
              </Text>
              <Text style={[styles.replyBarContent, { color: colors.mutedForeground }]} numberOfLines={1}>
                {editingMessage?.content ?? replyTo?.content ?? (replyTo?.type === "video" ? "🎥 فيديو" : "📷 صورة")}
              </Text>
            </View>
            <TouchableOpacity onPress={cancelEditOrReply}>
              <Ionicons name="close-circle" size={22} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>
        )}

        {/* Input bar */}
        <View style={[styles.inputBar, { backgroundColor: colors.card, borderTopColor: colors.border, paddingBottom: botPad + 8 }]}>
          {/* Image picker */}
          <TouchableOpacity onPress={() => sendMedia("image")} disabled={uploading}>
            <Ionicons name="image-outline" size={24} color={uploading ? colors.mutedForeground : colors.gold} />
          </TouchableOpacity>
          {/* Video picker */}
          <TouchableOpacity onPress={() => sendMedia("video")} disabled={uploading}>
            <Ionicons name="videocam-outline" size={24} color={uploading ? colors.mutedForeground : colors.gold} />
          </TouchableOpacity>

          <TextInput
            style={[styles.textInput, { backgroundColor: colors.chatInput, color: colors.foreground, borderColor: colors.border }]}
            placeholder={editingMessage ? "عدّل رسالتك..." : "رسالة..."}
            placeholderTextColor={colors.mutedForeground}
            value={text}
            onChangeText={handleTyping}
            multiline
            maxLength={2000}
          />
          <TouchableOpacity
            onPress={sendMessage}
            disabled={!text.trim()}
            style={[styles.sendBtn, { backgroundColor: text.trim() ? colors.gold : colors.surface }]}
          >
            <Ionicons name={editingMessage ? "checkmark" : "send"} size={17} color={text.trim() ? colors.primaryForeground : colors.mutedForeground} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 14, paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth, gap: 10,
  },
  headerInfo: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
  headerTitle: { fontSize: 15, fontWeight: "700" as const, fontFamily: "Inter_700Bold", maxWidth: 150 },
  headerSub: { fontSize: 11, fontFamily: "Inter_400Regular" },
  loadingContainer: { flex: 1, alignItems: "center", justifyContent: "center" },
  emptyChat: { flex: 1, alignItems: "center", justifyContent: "center", paddingTop: 80 },
  emptyChatText: { fontSize: 14, fontFamily: "Inter_400Regular" },
  typingIndicator: { marginHorizontal: 16, marginBottom: 8, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, alignSelf: "flex-start" },
  typingText: { fontSize: 12, fontStyle: "italic" },
  uploadBar: { marginHorizontal: 14, marginBottom: 6, borderRadius: 8, overflow: "hidden", height: 28, justifyContent: "center" },
  uploadBarFill: { position: "absolute", left: 0, top: 0, bottom: 0 },
  uploadText: { fontSize: 12, fontFamily: "Inter_400Regular", paddingHorizontal: 10, zIndex: 1 },
  replyBar: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 14, paddingVertical: 10, gap: 12,
    borderTopWidth: StyleSheet.hairlineWidth, borderLeftWidth: 3,
  },
  replyBarLabel: { fontSize: 12, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  replyBarContent: { fontSize: 12, fontFamily: "Inter_400Regular" },
  inputBar: {
    flexDirection: "row", alignItems: "flex-end",
    paddingHorizontal: 12, paddingTop: 10,
    borderTopWidth: StyleSheet.hairlineWidth, gap: 8,
  },
  textInput: {
    flex: 1, borderRadius: 22, borderWidth: 1,
    paddingHorizontal: 16, paddingVertical: 10,
    maxHeight: 120, fontSize: 15, fontFamily: "Inter_400Regular",
  },
  sendBtn: { width: 42, height: 42, borderRadius: 21, alignItems: "center", justifyContent: "center" },
  menuOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-start", alignItems: "flex-end", paddingTop: 100, paddingRight: 16 },
  menuCard: { borderRadius: 16, borderWidth: 1, minWidth: 200, overflow: "hidden" },
  menuItem: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 18, paddingVertical: 14 },
  menuItemText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  menuDivider: { height: StyleSheet.hairlineWidth },
});
