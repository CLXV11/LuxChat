/**
 * Hidden developer console. It is reachable only by @fadi and the server
 * independently enforces the same restriction for every request.
 */
import React, { useCallback, useEffect, useState } from "react";
import { Alert, FlatList, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { api } from "@/lib/api";

interface ManagedUser {
  id: string;
  username: string;
  displayName: string;
  isVerified: boolean;
  isDeveloper: boolean;
}

export default function DeveloperScreen() {
  const colors = useColors();
  const router = useRouter();
  const { token, user } = useAuth();
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [resetTarget, setResetTarget] = useState<ManagedUser | null>(null);
  const [code, setCode] = useState("");
  const [newPassword, setNewPassword] = useState("");

  const load = useCallback(async () => {
    if (!token) return;
    try { setUsers((await api.developer.users(token)) as ManagedUser[]); }
    catch { Alert.alert("خطأ", "لا تملك صلاحية المطوّر"); router.back(); }
  }, [token, router]);

  useEffect(() => {
    if (user?.username.toLowerCase() !== "fadi" || !user.isDeveloper) {
      router.replace("/(tabs)/profile");
      return;
    }
    void load();
  }, [user, router, load]);

  const toggleVerification = async (target: ManagedUser) => {
    if (!token) return;
    try {
      await api.developer.setVerification(token, target.id, !target.isVerified);
      setUsers((prev) => prev.map((u) => u.id === target.id ? { ...u, isVerified: !u.isVerified } : u));
    } catch (e) { Alert.alert("خطأ", e instanceof Error ? e.message : "فشل التعديل"); }
  };

  const deleteUser = (target: ManagedUser) => {
    if (!token || target.isDeveloper) return;
    Alert.alert("حذف الحساب", `حذف @${target.username} نهائياً؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: async () => {
        try { await api.developer.deleteUser(token, target.id); setUsers((prev) => prev.filter((u) => u.id !== target.id)); }
        catch (e) { Alert.alert("خطأ", e instanceof Error ? e.message : "فشل الحذف"); }
      }},
    ]);
  };

  const submitReset = async () => {
    if (!token || !resetTarget || !code || !newPassword) return;
    try {
      await api.developer.resetPassword(token, resetTarget.id, code, newPassword);
      Alert.alert("تم", "تم تغيير كلمة المرور بنجاح");
      setResetTarget(null); setCode(""); setNewPassword("");
    } catch (e) { Alert.alert("خطأ", e instanceof Error ? e.message : "رمز الاحتياط غير صحيح"); }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}><Ionicons name="chevron-back" size={27} color={colors.gold} /></TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>لوحة المطوّر</Text>
        <Ionicons name="lock-closed" size={18} color={colors.gold} />
      </View>
      <Text style={[styles.note, { color: colors.mutedForeground }]}>إدارة الحسابات والشارة الزرقاء</Text>
      {resetTarget && (
        <View style={[styles.resetCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.resetTitle, { color: colors.foreground }]}>تغيير كلمة مرور @{resetTarget.username}</Text>
          <TextInput style={[styles.input, { color: colors.foreground, borderColor: colors.border }]} placeholder="رمز الاحتياط" placeholderTextColor={colors.mutedForeground} value={code} onChangeText={setCode} secureTextEntry />
          <TextInput style={[styles.input, { color: colors.foreground, borderColor: colors.border }]} placeholder="كلمة المرور الجديدة" placeholderTextColor={colors.mutedForeground} value={newPassword} onChangeText={setNewPassword} secureTextEntry />
          <View style={styles.actions}>
            <TouchableOpacity onPress={() => setResetTarget(null)}><Text style={{ color: colors.mutedForeground }}>إلغاء</Text></TouchableOpacity>
            <TouchableOpacity style={[styles.primary, { backgroundColor: colors.gold }]} onPress={() => void submitReset()}><Text style={{ color: colors.primaryForeground }}>حفظ</Text></TouchableOpacity>
          </View>
        </View>
      )}
      <FlatList
        data={users}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={[styles.row, { borderBottomColor: colors.border }]}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.name, { color: colors.foreground }]}>{item.displayName}</Text>
              <Text style={{ color: colors.mutedForeground }}>@{item.username}</Text>
            </View>
            <TouchableOpacity onPress={() => void toggleVerification(item)} style={styles.iconButton}>
              <Ionicons name={item.isVerified ? "checkmark-circle" : "checkmark-circle-outline"} size={23} color={item.isVerified ? colors.verifiedBlue : colors.mutedForeground} />
            </TouchableOpacity>
            {!item.isDeveloper && (
              <>
                <TouchableOpacity onPress={() => setResetTarget(item)} style={styles.iconButton}><Ionicons name="key-outline" size={21} color={colors.gold} /></TouchableOpacity>
                <TouchableOpacity onPress={() => deleteUser(item)} style={styles.iconButton}><Ionicons name="trash-outline" size={21} color={colors.destructive} /></TouchableOpacity>
              </>
            )}
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 16, paddingTop: 55 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingBottom: 12 },
  title: { fontSize: 20, fontWeight: "700", fontFamily: "Inter_700Bold" },
  note: { textAlign: "center", marginBottom: 14 },
  row: { flexDirection: "row", alignItems: "center", paddingVertical: 13, borderBottomWidth: StyleSheet.hairlineWidth, gap: 8 },
  name: { fontSize: 15, fontWeight: "600" },
  iconButton: { padding: 7 },
  resetCard: { borderWidth: 1, borderRadius: 14, padding: 13, marginBottom: 12, gap: 9 },
  resetTitle: { fontSize: 14, fontWeight: "700" },
  input: { borderWidth: 1, borderRadius: 9, paddingHorizontal: 12, paddingVertical: 9 },
  actions: { flexDirection: "row", justifyContent: "flex-end", alignItems: "center", gap: 18 },
  primary: { borderRadius: 9, paddingHorizontal: 17, paddingVertical: 9 },
});