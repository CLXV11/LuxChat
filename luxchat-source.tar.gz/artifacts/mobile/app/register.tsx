/**
 * Register screen — create a new LuxChat account.
 */
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { useAuth } from "@/contexts/AuthContext";
import { useColors } from "@/hooks/useColors";

export default function RegisterScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { register } = useAuth();

  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    if (!displayName.trim() || !username.trim() || !password.trim()) {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert("Error", "Passwords do not match");
      return;
    }
    if (password.length < 6) {
      Alert.alert("Error", "Password must be at least 6 characters");
      return;
    }
    setLoading(true);
    try {
      await register(username.trim(), password, displayName.trim());
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace("/(tabs)/chats");
    } catch (err) {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert("Registration Failed", err instanceof Error ? err.message : "Could not create account");
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient colors={["#0A0A0A", "#141414", "#0A0A0A"]} style={{ flex: 1 }}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
        <ScrollView
          contentContainerStyle={[
            styles.container,
            {
              paddingTop: insets.top + (Platform.OS === "web" ? 67 : 20),
              paddingBottom: insets.bottom + 20,
            },
          ]}
          keyboardShouldPersistTaps="handled"
        >
          {/* Back button */}
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => router.back()}
          >
            <Ionicons name="chevron-back" size={24} color={colors.gold} />
          </TouchableOpacity>

          {/* Header */}
          <View style={styles.header}>
            <View style={[styles.logoCircle, { borderColor: colors.gold }]}>
              <Ionicons name="person-add" size={40} color={colors.gold} />
            </View>
            <Text style={[styles.title, { color: colors.foreground }]}>
              Create Account
            </Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Join the LuxChat community
            </Text>
          </View>

          {/* Form */}
          <View style={styles.form}>
            {[
              {
                label: "Display Name",
                icon: "sparkles-outline",
                value: displayName,
                onChange: setDisplayName,
                placeholder: "Your name",
                secure: false,
                autoCapitalize: "words" as const,
              },
              {
                label: "Username",
                icon: "at-outline",
                value: username,
                onChange: setUsername,
                placeholder: "unique_username",
                secure: false,
                autoCapitalize: "none" as const,
              },
              {
                label: "Password",
                icon: "lock-closed-outline",
                value: password,
                onChange: setPassword,
                placeholder: "Min 6 characters",
                secure: !showPassword,
                autoCapitalize: "none" as const,
              },
              {
                label: "Confirm Password",
                icon: "lock-closed-outline",
                value: confirmPassword,
                onChange: setConfirmPassword,
                placeholder: "Repeat password",
                secure: !showPassword,
                autoCapitalize: "none" as const,
              },
            ].map((field) => (
              <View key={field.label}>
                <Text style={[styles.label, { color: colors.mutedForeground }]}>
                  {field.label}
                </Text>
                <View
                  style={[
                    styles.inputWrapper,
                    { borderColor: colors.border, backgroundColor: colors.card },
                  ]}
                >
                  <Ionicons
                    name={field.icon as keyof typeof Ionicons.glyphMap}
                    size={20}
                    color={colors.mutedForeground}
                  />
                  <TextInput
                    style={[styles.input, { color: colors.foreground }]}
                    placeholder={field.placeholder}
                    placeholderTextColor={colors.mutedForeground}
                    value={field.value}
                    onChangeText={field.onChange}
                    secureTextEntry={field.secure}
                    autoCapitalize={field.autoCapitalize}
                    autoCorrect={false}
                  />
                  {(field.label === "Password" || field.label === "Confirm Password") && (
                    <TouchableOpacity onPress={() => setShowPassword((p) => !p)}>
                      <Ionicons
                        name={showPassword ? "eye-off-outline" : "eye-outline"}
                        size={20}
                        color={colors.mutedForeground}
                      />
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            ))}

            <TouchableOpacity
              style={[styles.button, { backgroundColor: colors.gold, opacity: loading ? 0.7 : 1 }]}
              onPress={handleRegister}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color={colors.primaryForeground} />
              ) : (
                <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>
                  Create Account
                </Text>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.loginLink}
              onPress={() => router.back()}
            >
              <Text style={[styles.loginText, { color: colors.mutedForeground }]}>
                Already have an account?{" "}
                <Text style={{ color: colors.gold, fontWeight: "700" as const }}>
                  Sign In
                </Text>
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 28,
    flexGrow: 1,
  },
  backBtn: {
    width: 44,
    height: 44,
    justifyContent: "center",
    marginBottom: 8,
  },
  header: {
    alignItems: "center",
    marginBottom: 32,
  },
  logoCircle: {
    width: 88,
    height: 88,
    borderRadius: 44,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
    backgroundColor: "rgba(255,215,0,0.08)",
  },
  title: {
    fontSize: 28,
    fontWeight: "700" as const,
    fontFamily: "Inter_700Bold",
  },
  subtitle: {
    fontSize: 14,
    marginTop: 6,
    fontFamily: "Inter_400Regular",
  },
  form: {
    gap: 16,
  },
  label: {
    fontSize: 12,
    fontWeight: "600" as const,
    marginBottom: 6,
    textTransform: "uppercase",
    letterSpacing: 0.8,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    gap: 12,
  },
  input: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  button: {
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: "center",
    marginTop: 8,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: "700" as const,
    fontFamily: "Inter_700Bold",
  },
  loginLink: {
    alignItems: "center",
    paddingVertical: 8,
  },
  loginText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
});
