/**
 * View another user's profile — follow, message, view posts and follower stats.
 */
import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  ActivityIndicator,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { useSocket } from "@/contexts/SocketContext";
import { UserAvatar } from "@/components/UserAvatar";
import { PostCard, type PostData } from "@/components/PostCard";
import { api, resolveMediaUrl } from "@/lib/api";

interface OtherUser {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  coverBanner: string | null;
  bio: string;
  coins: number;
  joinedAt: string;
  isVerified: boolean;
  isAdmin: boolean;
  title: string | null;
  profileBorder: string | null;
  couplePartnerId: string | null;
}

export default function UserProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { token, user: me } = useAuth();
  const { onlineUsers } = useSocket();

  const [profile, setProfile] = useState<OtherUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [friendSent, setFriendSent] = useState(false);
  const [coupleSent, setCoupleSent] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followersCount, setFollowersCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [userPosts, setUserPosts] = useState<PostData[]>([]);
  const [followLoading, setFollowLoading] = useState(false);

  const loadData = useCallback(async () => {
    if (!token || !id) return;
    try {
      const [u, stats, posts] = await Promise.all([
        api.users.get(token, id),
        api.follows.stats(token, id),
        api.posts.userPosts(token, id),
      ]);
      setProfile(u as OtherUser);
      const s = stats as { followers: number; following: number; isFollowing: boolean };
      setFollowersCount(s.followers);
      setFollowingCount(s.following);
      setIsFollowing(s.isFollowing);
      setUserPosts(posts as PostData[]);
    } catch {
      Alert.alert("خطأ", "تعذّر تحميل الملف الشخصي");
    } finally {
      setLoading(false);
    }
  }, [token, id]);

  useEffect(() => { void loadData(); }, [loadData]);

  const toggleFollow = async () => {
    if (!token || !id || followLoading) return;
    setFollowLoading(true);
    try {
      if (isFollowing) {
        const res = await api.follows.unfollow(token, id);
        setIsFollowing(false);
        setFollowersCount(res.followersCount);
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      } else {
        const res = await api.follows.follow(token, id);
        setIsFollowing(true);
        setFollowersCount(res.followersCount);
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (e) {
      Alert.alert("خطأ", e instanceof Error ? e.message : "فشل");
    } finally {
      setFollowLoading(false);
    }
  };

  const sendFriendRequest = async () => {
    if (!token || !id) return;
    try {
      await api.friends.request(token, id);
      setFriendSent(true);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      Alert.alert("خطأ", err instanceof Error ? err.message : "فشل");
    }
  };

  const sendCoupleRequest = async () => {
    if (!token || !id) return;
    try {
      await api.couple.request(token, id);
      setCoupleSent(true);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      Alert.alert("خطأ", err instanceof Error ? err.message : "فشل");
    }
  };

  const handleLike = async (postId: string) => {
    if (!token) return;
    try { await api.posts.like(token, postId); } catch {}
  };

  const isOnline = onlineUsers.includes(id ?? "");
  const topPad = insets.top + (Platform.OS === "web" ? 67 : 0);

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.gold} size="large" />
      </View>
    );
  }

  if (!profile) return null;

  const joinedDate = new Date(profile.joinedAt).toLocaleDateString("ar-SA", { year: "numeric", month: "long" });

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
    >
      {/* Cover */}
      {profile.coverBanner ? (
        <Image source={{ uri: resolveMediaUrl(profile.coverBanner) }} style={[styles.cover, { paddingTop: topPad }]} resizeMode="cover" />
      ) : (
        <LinearGradient colors={["#0D0021", "#1A0D5E", "#0A0A0A"]} style={[styles.cover, { paddingTop: topPad }]} />
      )}

      {/* Back button */}
      <TouchableOpacity style={[styles.backBtn, { top: topPad + 12, backgroundColor: "rgba(0,0,0,0.65)" }]} onPress={() => router.back()}>
        <Ionicons name="chevron-back" size={24} color={colors.gold} />
      </TouchableOpacity>

      {/* Avatar + actions */}
      <View style={styles.avatarSection}>
        <View style={styles.avatarWrap}>
          <UserAvatar uri={profile.avatar} size={92} isVerified={profile.isVerified} isOnline={isOnline} profileBorder={profile.profileBorder} showOnline />
          {isOnline && (
            <View style={[styles.onlinePill, { backgroundColor: colors.onlineGreen }]}>
              <Text style={styles.onlinePillText}>متصل</Text>
            </View>
          )}
        </View>
        <View style={styles.quickActions}>
          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: colors.gold }]}
            onPress={() => router.push(`/chat/${profile.id}`)}
          >
            <Ionicons name="chatbubble" size={17} color={colors.primaryForeground} />
            <Text style={[styles.actionText, { color: colors.primaryForeground }]}>رسالة</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.actionBtn,
              { backgroundColor: isFollowing ? colors.surface : "transparent", borderWidth: 1.5, borderColor: isFollowing ? colors.border : colors.gold },
            ]}
            onPress={toggleFollow}
            disabled={followLoading}
          >
            {followLoading ? (
              <ActivityIndicator size="small" color={colors.gold} />
            ) : (
              <>
                <Ionicons name={isFollowing ? "person-remove-outline" : "person-add-outline"} size={17} color={isFollowing ? colors.mutedForeground : colors.gold} />
                <Text style={[styles.actionText, { color: isFollowing ? colors.mutedForeground : colors.gold }]}>
                  {isFollowing ? "إلغاء المتابعة" : "متابعة"}
                </Text>
              </>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionBtnSmall, { backgroundColor: friendSent ? colors.surface : colors.card, borderWidth: 1, borderColor: friendSent ? colors.border : colors.gold }]}
            onPress={!friendSent ? sendFriendRequest : undefined}
            disabled={friendSent}
          >
            <Ionicons name={friendSent ? "checkmark" : "people-outline"} size={17} color={friendSent ? colors.mutedForeground : colors.gold} />
          </TouchableOpacity>

          {!me?.couplePartnerId && !profile.couplePartnerId && me?.id !== profile.id && (
            <TouchableOpacity
              style={[styles.actionBtnSmall, { backgroundColor: coupleSent ? colors.surface : colors.card, borderWidth: 1, borderColor: coupleSent ? colors.border : colors.couplePink }]}
              onPress={!coupleSent ? sendCoupleRequest : undefined}
              disabled={coupleSent}
            >
              <Ionicons name={coupleSent ? "heart" : "heart-outline"} size={17} color={coupleSent ? colors.mutedForeground : colors.couplePink} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Info */}
      <View style={styles.infoSection}>
        <View style={styles.nameRow}>
          <Text style={[styles.displayName, { color: colors.foreground }]}>{profile.displayName}</Text>
          {profile.isVerified && <Ionicons name="checkmark-circle" size={22} color={colors.verifiedBlue} />}
          {profile.couplePartnerId && <Ionicons name="heart" size={18} color={colors.couplePink} />}
        </View>


        <Text style={[styles.username, { color: colors.mutedForeground }]}>@{profile.username}</Text>

        {profile.bio ? (
          <Text style={[styles.bio, { color: colors.foreground }]}>{profile.bio}</Text>
        ) : null}

        {/* Stats row — Followers / Following / Joined */}
        <View style={[styles.statsRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <TouchableOpacity style={styles.statItem} onPress={() => router.push(`/followers/${profile.id}`)}>
            <Text style={[styles.statValue, { color: colors.foreground }]}>{followersCount.toLocaleString()}</Text>
            <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>متابع</Text>
          </TouchableOpacity>
          <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
          <TouchableOpacity style={styles.statItem} onPress={() => router.push(`/following/${profile.id}`)}>
            <Text style={[styles.statValue, { color: colors.foreground }]}>{followingCount.toLocaleString()}</Text>
            <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>يتابع</Text>
          </TouchableOpacity>
          <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
          <View style={styles.statItem}>
            <Ionicons name="calendar-outline" size={16} color={colors.mutedForeground} />
            <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{joinedDate}</Text>
          </View>
        </View>
      </View>

      {/* Posts */}
      {userPosts.length > 0 && (
        <View style={[styles.postsSection, { borderTopColor: colors.border }]}>
          <Text style={[styles.postsSectionTitle, { color: colors.foreground }]}>المنشورات</Text>
          {userPosts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              token={token ?? undefined}
              onLike={handleLike}
              onPressUser={(uid) => uid !== id && router.push(`/user/${uid}`)}
            />
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, alignItems: "center", justifyContent: "center" },
  cover: { height: 210, justifyContent: "flex-end" },
  backBtn: { position: "absolute", left: 16, width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  avatarSection: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", paddingHorizontal: 18, marginTop: -46, marginBottom: 14 },
  avatarWrap: { position: "relative" },
  onlinePill: { position: "absolute", bottom: -2, alignSelf: "center", borderRadius: 8, paddingHorizontal: 6, paddingVertical: 2 },
  onlinePillText: { fontSize: 9, fontWeight: "700" as const, color: "#000" },
  quickActions: { flexDirection: "row", gap: 8, alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end", flex: 1 },
  actionBtn: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20 },
  actionBtnSmall: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" },
  actionText: { fontSize: 13, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  infoSection: { paddingHorizontal: 18, gap: 8 },
  nameRow: { flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" },
  displayName: { fontSize: 24, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  adminBadge: { flexDirection: "row", alignItems: "center", gap: 4, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  adminText: { fontSize: 10, fontWeight: "700" as const, letterSpacing: 0.5 },
  titleBadge: { alignSelf: "flex-start", borderWidth: 1, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  titleText: { fontSize: 13, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  username: { fontSize: 15, fontFamily: "Inter_400Regular" },
  bio: { fontSize: 14, lineHeight: 21, fontFamily: "Inter_400Regular" },
  statsRow: { flexDirection: "row", borderWidth: StyleSheet.hairlineWidth, borderRadius: 16, overflow: "hidden", marginTop: 6 },
  statItem: { flex: 1, alignItems: "center", paddingVertical: 14, gap: 4 },
  statDivider: { width: StyleSheet.hairlineWidth },
  statValue: { fontSize: 16, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  statLabel: { fontSize: 11, fontFamily: "Inter_400Regular" },
  postsSection: { marginTop: 12, borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 16 },
  postsSectionTitle: { fontSize: 17, fontWeight: "700" as const, fontFamily: "Inter_700Bold", paddingHorizontal: 18, marginBottom: 8 },
});
