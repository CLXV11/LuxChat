/**
 * Feed — global posts feed with photo sharing and reactions.
 */
import React, { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Modal,
  TextInput,
  TouchableOpacity,
  Platform,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { api } from "@/lib/api";
import { PostCard, type PostData } from "@/components/PostCard";
import { useRouter } from "expo-router";

export default function FeedScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { token, user } = useAuth();
  const router = useRouter();

  const [posts, setPosts] = useState<PostData[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [caption, setCaption] = useState("");
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const topPad = insets.top + (Platform.OS === "web" ? 67 : 0);

  const loadPosts = useCallback(async () => {
    if (!token) return;
    try {
      const data = await api.posts.feed(token);
      setPosts(data as PostData[]);
    } catch {}
    finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [token]);

  useEffect(() => { void loadPosts(); }, [loadPosts]);

  const handleLike = async (postId: string) => {
    if (!token) return;
    try {
      await api.posts.like(token, postId);
    } catch {}
  };

  const handleDelete = async (postId: string) => {
    if (!token) return;
    try {
      await api.posts.delete(token, postId);
      setPosts((prev) => prev.filter((p) => p.id !== postId));
    } catch (e) {
      Alert.alert("Error", e instanceof Error ? e.message : "Failed to delete");
    }
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.85,
    });
    if (!result.canceled && result.assets[0]) {
      setImageUri(result.assets[0].uri);
    }
  };

  const handleCreate = async () => {
    if (!token || (!imageUri && !caption.trim())) return;
    setCreating(true);
    try {
      const post = await api.posts.create(token, imageUri, caption.trim());
      setPosts((prev) => [post as PostData, ...prev]);
      setShowCreate(false);
      setCaption("");
      setImageUri(null);
    } catch (e) {
      Alert.alert("Error", e instanceof Error ? e.message : "Failed to create post");
    } finally {
      setCreating(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          { paddingTop: topPad + 16, backgroundColor: colors.card, borderBottomColor: colors.border },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>المنشورات</Text>
        <TouchableOpacity
          style={[styles.createBtn, { backgroundColor: colors.gold }]}
          onPress={() => setShowCreate(true)}
        >
          <Ionicons name="add" size={20} color="#000" />
          <Text style={styles.createBtnText}>نشر</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.gold} size="large" />
        </View>
      ) : (
        <FlatList
          data={posts}
          keyExtractor={(p) => p.id}
          renderItem={({ item }) => (
            <PostCard
              post={item}
              token={token ?? undefined}
              onLike={handleLike}
              onDelete={handleDelete}
              isMine={item.author?.id === user?.id}
              isAdminUser={user?.isAdmin}
              onPressUser={(userId) => router.push(`/user/${userId}`)}
            />
          )}
          contentContainerStyle={{ paddingTop: 8, paddingBottom: insets.bottom + 90 }}
          onRefresh={() => { setRefreshing(true); void loadPosts(); }}
          refreshing={refreshing}
          ListEmptyComponent={
            <View style={styles.center}>
              <Ionicons name="images-outline" size={56} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                لا توجد منشورات بعد
              </Text>
              <Text style={[styles.emptyHint, { color: colors.mutedForeground }]}>
                اضغط "نشر" لمشاركة أول صورة
              </Text>
            </View>
          }
        />
      )}

      {/* Create Post Modal */}
      <Modal visible={showCreate} animationType="slide" transparent onRequestClose={() => setShowCreate(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.modalOverlay}>
          <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>منشور جديد</Text>
              <TouchableOpacity onPress={() => { setShowCreate(false); setCaption(""); setImageUri(null); }}>
                <Ionicons name="close" size={24} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={[styles.imagePicker, { borderColor: imageUri ? colors.gold : colors.border, backgroundColor: colors.secondary }]}
              onPress={pickImage}
              activeOpacity={0.8}
            >
              {imageUri ? (
                <View style={styles.imagePreviewWrapper}>
                  <PostCard
                    post={{ id: "preview", imageUrl: imageUri, caption, createdAt: new Date().toISOString(), likesCount: 0, isLiked: false, author: { id: user?.id ?? "", username: user?.username ?? "", displayName: user?.displayName ?? "", avatar: user?.avatar, isVerified: user?.isVerified, profileBorder: user?.profileBorder } }}
                    onLike={() => {}}
                    isMine={false}
                  />
                </View>
              ) : (
                <View style={styles.imagePickerEmpty}>
                  <Ionicons name="image-outline" size={40} color={colors.mutedForeground} />
                  <Text style={[styles.imagePickerText, { color: colors.mutedForeground }]}>
                    اضغط لاختيار صورة
                  </Text>
                </View>
              )}
            </TouchableOpacity>

            <TextInput
              style={[styles.captionInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.secondary }]}
              placeholder="اكتب تعليقاً..."
              placeholderTextColor={colors.mutedForeground}
              value={caption}
              onChangeText={setCaption}
              multiline
              maxLength={500}
            />

            <TouchableOpacity
              style={[styles.publishBtn, { backgroundColor: (!imageUri && !caption.trim()) ? colors.border : colors.gold }]}
              onPress={handleCreate}
              disabled={creating || (!imageUri && !caption.trim())}
            >
              {creating ? (
                <ActivityIndicator color="#000" />
              ) : (
                <Text style={styles.publishBtnText}>نشر الآن</Text>
              )}
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 16,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  headerTitle: { fontSize: 28, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  createBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  createBtnText: { fontSize: 14, fontWeight: "700" as const, color: "#000", fontFamily: "Inter_700Bold" },
  center: { flex: 1, alignItems: "center", justifyContent: "center", paddingTop: 80, gap: 12 },
  emptyText: { fontSize: 18, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  emptyHint: { fontSize: 14, fontFamily: "Inter_400Regular" },
  modalOverlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.6)" },
  modalCard: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    padding: 20,
    gap: 16,
    maxHeight: "90%",
  },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  modalTitle: { fontSize: 20, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  imagePicker: {
    borderWidth: 1.5,
    borderRadius: 16,
    borderStyle: "dashed",
    overflow: "hidden",
    minHeight: 140,
  },
  imagePreviewWrapper: { borderRadius: 16, overflow: "hidden" },
  imagePickerEmpty: { alignItems: "center", justifyContent: "center", gap: 8, padding: 32 },
  imagePickerText: { fontSize: 14, fontFamily: "Inter_400Regular" },
  captionInput: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 14,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    minHeight: 80,
    textAlignVertical: "top",
  },
  publishBtn: {
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: "center",
  },
  publishBtnText: { fontSize: 16, fontWeight: "700" as const, color: "#000", fontFamily: "Inter_700Bold" },
});
