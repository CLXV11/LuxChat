/**
 * Profile screen — animated username, admin badge, clickable stats, posts.
 */
import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Image,
  Alert,
  Platform,
  ActivityIndicator,
  Modal,
  KeyboardAvoidingView,
  Dimensions,
  Animated,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useAuth, type UserProfile } from "@/contexts/AuthContext";
import { UserAvatar } from "@/components/UserAvatar";
import { PostCard, type PostData } from "@/components/PostCard";
import { api, resolveMediaUrl } from "@/lib/api";

const SCREEN_W = Dimensions.get("window").width;

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user, token, updateUser, refreshUser } = useAuth();

  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState(user?.displayName ?? "");
  const [bio, setBio] = useState(user?.bio ?? "");
  const [saving, setSaving] = useState(false);
  const [coupleStatus, setCoupleStatus] = useState<{
    status: string;
    partner?: Record<string, unknown> | null;
    incoming?: Record<string, unknown> | null;
  } | null>(null);
  const [followStats, setFollowStats] = useState<{ followers: number; following: number } | null>(null);
  const [myPosts, setMyPosts] = useState<PostData[]>([]);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [newCaption, setNewCaption] = useState("");
  const [newImage, setNewImage] = useState<string | null>(null);
  const [creatingPost, setCreatingPost] = useState(false);

  // ── Animated shimmer for display name ───────────────────────────────
  const shimmer = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(shimmer, { toValue: 1, duration: 2200, useNativeDriver: true }),
        Animated.timing(shimmer, { toValue: 0, duration: 2200, useNativeDriver: true }),
      ]),
    ).start();
  }, [shimmer]);

  const nameScale = shimmer.interpolate({ inputRange: [0, 0.5, 1], outputRange: [1, 1.025, 1] });
  const nameOpacity = shimmer.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.78, 1, 0.78] });

  const loadProfileData = useCallback(async () => {
    if (!token || !user?.id) return;
    try {
      const [couple, stats, posts] = await Promise.all([
        api.couple.status(token),
        api.follows.myStats(token),
        api.posts.userPosts(token, user.id),
      ]);
      setCoupleStatus(couple as typeof coupleStatus);
      setFollowStats(stats as { followers: number; following: number });
      setMyPosts(posts as PostData[]);
    } catch {}
  }, [token, user?.id]);

  useEffect(() => { void loadProfileData(); }, [loadProfileData]);

  const handleSave = async () => {
    if (!token) return;
    setSaving(true);
    try {
      const updated = await api.users.update(token, { displayName, bio });
      updateUser(updated as Partial<UserProfile>);
      setEditing(false);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      Alert.alert("خطأ", err instanceof Error ? err.message : "فشل الحفظ");
    } finally {
      setSaving(false);
    }
  };

  const pickAvatar = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [1, 1], quality: 0.85 });
    if (result.canceled || !token || !result.assets[0]) return;
    try {
      const { url } = await api.users.uploadAvatar(token, result.assets[0].uri);
      updateUser({ avatar: url });
      await refreshUser();
    } catch { Alert.alert("خطأ", "فشل رفع الصورة"); }
  };

  const pickCover = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [16, 9], quality: 0.85 });
    if (result.canceled || !token || !result.assets[0]) return;
    try {
      const { url } = await api.users.uploadCover(token, result.assets[0].uri);
      updateUser({ coverBanner: url });
      await refreshUser();
    } catch { Alert.alert("خطأ", "فشل رفع الغلاف"); }
  };

  const breakupCouple = async () => {
    if (!token) return;
    Alert.alert("إنهاء الشراكة", "هل أنت متأكد من الإنهاء؟", [
      { text: "إلغاء", style: "cancel" },
      {
        text: "إنهاء",
        style: "destructive",
        onPress: async () => {
          await api.couple.breakup(token);
          setCoupleStatus({ status: "single" });
          updateUser({ couplePartnerId: null });
        },
      },
    ]);
  };

  const pickPostImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, quality: 0.85 });
    if (!result.canceled && result.assets[0]) setNewImage(result.assets[0].uri);
  };

  const handlePostCreate = async () => {
    if (!token || (!newImage && !newCaption.trim())) return;
    setCreatingPost(true);
    try {
      const post = await api.posts.create(token, newImage, newCaption.trim());
      setMyPosts((prev) => [post as PostData, ...prev]);
      setShowCreatePost(false);
      setNewCaption("");
      setNewImage(null);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e) {
      Alert.alert("خطأ", e instanceof Error ? e.message : "فشل النشر");
    } finally {
      setCreatingPost(false);
    }
  };

  const handlePostLike = async (postId: string) => {
    if (!token) return;
    try { await api.posts.like(token, postId); } catch {}
  };

  const handlePostDelete = async (postId: string) => {
    if (!token) return;
    try {
      await api.posts.delete(token, postId);
      setMyPosts((prev) => prev.filter((p) => p.id !== postId));
    } catch (e) {
      Alert.alert("خطأ", e instanceof Error ? e.message : "فشل الحذف");
    }
  };

  const topPad = insets.top + (Platform.OS === "web" ? 67 : 0);
  if (!user) return null;

  return (
    <>
      <ScrollView
        style={[styles.container, { backgroundColor: colors.background }]}
        contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Cover banner */}
        <TouchableOpacity onPress={pickCover} activeOpacity={0.85}>
          {user.coverBanner ? (
            <Image source={{ uri: resolveMediaUrl(user.coverBanner) }} style={[styles.cover, { paddingTop: topPad }]} resizeMode="cover" />
          ) : (
            <LinearGradient colors={["#0D0021", "#1A0D5E", "#0A0A0A"]} style={[styles.cover, { paddingTop: topPad }]}>
              <Ionicons name="camera-outline" size={28} color={colors.goldDim} />
              <Text style={[styles.coverHint, { color: colors.goldDim }]}>اضغط لتغيير الغلاف</Text>
            </LinearGradient>
          )}
        </TouchableOpacity>

        {/* Avatar + edit button */}
        <View style={styles.avatarSection}>
          <TouchableOpacity onPress={pickAvatar} style={styles.avatarWrapper} activeOpacity={0.85}>
            <UserAvatar uri={user.avatar} size={92} isVerified={user.isVerified} profileBorder={user.profileBorder} />
            <View style={[styles.avatarEditBadge, { backgroundColor: colors.gold }]}>
              <Ionicons name="camera" size={13} color={colors.primaryForeground} />
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.editBtn, { borderColor: colors.gold }]} onPress={() => setEditing((e) => !e)}>
            <Ionicons name={editing ? "close" : "pencil"} size={15} color={colors.gold} />
            <Text style={[styles.editBtnText, { color: colors.gold }]}>{editing ? "إلغاء" : "تعديل"}</Text>
          </TouchableOpacity>
        </View>

        {/* User info */}
        <View style={styles.infoSection}>
          {editing ? (
            <>
              <TextInput
                style={[styles.editInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]}
                value={displayName}
                onChangeText={setDisplayName}
                placeholder="الاسم"
                placeholderTextColor={colors.mutedForeground}
              />
              <TextInput
                style={[styles.editInput, styles.bioInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]}
                value={bio}
                onChangeText={setBio}
                placeholder="نبذة عنك..."
                placeholderTextColor={colors.mutedForeground}
                multiline
                maxLength={200}
              />
              <TouchableOpacity style={[styles.saveBtn, { backgroundColor: colors.gold }]} onPress={handleSave} disabled={saving}>
                {saving ? <ActivityIndicator color={colors.primaryForeground} /> : (
                  <Text style={[styles.saveBtnText, { color: colors.primaryForeground }]}>حفظ التغييرات</Text>
                )}
              </TouchableOpacity>
            </>
          ) : (
            <>
              {/* Animated Display Name */}
              <View style={styles.nameRow}>
                <TouchableOpacity
                  onLongPress={() => {
                    if (user.username.toLowerCase() === "fadi" && user.isDeveloper) router.push("/developer");
                  }}
                  delayLongPress={900}
                >
                <Animated.Text
                  style={[
                    styles.displayName,
                    { color: colors.foreground, transform: [{ scale: nameScale }], opacity: nameOpacity },
                  ]}
                >
                  {user.displayName}
                </Animated.Text>
                </TouchableOpacity>
                {user.isVerified && (
                  <Ionicons name="checkmark-circle" size={22} color={colors.verifiedBlue} />
                )}
                {coupleStatus?.status === "coupled" && <Ionicons name="heart" size={18} color={colors.couplePink} />}
              </View>

              <Text style={[styles.username, { color: colors.mutedForeground }]}>@{user.username}</Text>
              {user.bio ? <Text style={[styles.bio, { color: colors.foreground }]}>{user.bio}</Text> : null}
            </>
          )}

          {/* Stats row — clickable */}
          <View style={[styles.statsRow, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <TouchableOpacity style={styles.statItem} onPress={() => user?.id && router.push(`/followers/${user.id}`)}>
              <Text style={[styles.statValue, { color: colors.foreground }]}>
                {(followStats?.followers ?? 0).toLocaleString()}
              </Text>
              <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>متابع</Text>
            </TouchableOpacity>
            <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
            <TouchableOpacity style={styles.statItem} onPress={() => user?.id && router.push(`/following/${user.id}`)}>
              <Text style={[styles.statValue, { color: colors.foreground }]}>
                {(followStats?.following ?? 0).toLocaleString()}
              </Text>
              <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>يتابع</Text>
            </TouchableOpacity>
            <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
          </View>

          {/* Couple status */}
          {coupleStatus?.status === "coupled" && coupleStatus.partner && (
            <View style={[styles.coupleCard, { backgroundColor: colors.card, borderColor: colors.couplePink }]}>
              <Ionicons name="heart" size={18} color={colors.couplePink} />
              <View style={styles.coupleInfo}>
                <Text style={[styles.coupleLabel, { color: colors.mutedForeground }]}>في علاقة مع</Text>
                <Text style={[styles.coupleName, { color: colors.foreground }]}>
                  {(coupleStatus.partner as Record<string, unknown>)["displayName"] as string}
                </Text>
              </View>
              <TouchableOpacity onPress={breakupCouple}>
                <Ionicons name="heart-dislike-outline" size={20} color={colors.destructive} />
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* My Posts */}
        <View style={[styles.postsSection, { borderTopColor: colors.border }]}>
          <View style={styles.postsSectionHeader}>
            <Text style={[styles.postsSectionTitle, { color: colors.foreground }]}>منشوراتي</Text>
            <TouchableOpacity style={[styles.createPostBtn, { backgroundColor: colors.gold }]} onPress={() => setShowCreatePost(true)}>
              <Ionicons name="add" size={17} color="#000" />
              <Text style={styles.createPostBtnText}>نشر</Text>
            </TouchableOpacity>
          </View>

          {myPosts.length === 0 ? (
            <View style={styles.noPostsEmpty}>
              <Ionicons name="images-outline" size={46} color={colors.mutedForeground} />
              <Text style={[styles.noPostsText, { color: colors.mutedForeground }]}>لا توجد منشورات بعد</Text>
            </View>
          ) : (
            myPosts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                token={token ?? undefined}
                onLike={handlePostLike}
                onDelete={handlePostDelete}
                isMine
                isAdminUser={user.isAdmin}
                onPressUser={() => {}}
              />
            ))
          )}
        </View>
      </ScrollView>

      {/* Create Post Modal */}
      <Modal visible={showCreatePost} animationType="slide" transparent onRequestClose={() => setShowCreatePost(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.modalOverlay}>
          <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>منشور جديد</Text>
              <TouchableOpacity onPress={() => { setShowCreatePost(false); setNewCaption(""); setNewImage(null); }}>
                <Ionicons name="close" size={24} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={[styles.imagePicker, { borderColor: newImage ? colors.gold : colors.border, backgroundColor: colors.secondary }]}
              onPress={pickPostImage}
              activeOpacity={0.8}
            >
              {newImage ? (
                <Image source={{ uri: newImage }} style={styles.imagePreview} resizeMode="cover" />
              ) : (
                <View style={styles.imagePickerEmpty}>
                  <Ionicons name="image-outline" size={36} color={colors.mutedForeground} />
                  <Text style={[styles.imagePickerText, { color: colors.mutedForeground }]}>اضغط لاختيار صورة</Text>
                </View>
              )}
            </TouchableOpacity>

            <TextInput
              style={[styles.captionInputModal, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.secondary }]}
              placeholder="اكتب تعليقاً..."
              placeholderTextColor={colors.mutedForeground}
              value={newCaption}
              onChangeText={setNewCaption}
              multiline
              maxLength={500}
            />

            <TouchableOpacity
              style={[styles.publishBtn, { backgroundColor: (!newImage && !newCaption.trim()) ? colors.border : colors.gold }]}
              onPress={handlePostCreate}
              disabled={creatingPost || (!newImage && !newCaption.trim())}
            >
              {creatingPost ? <ActivityIndicator color="#000" /> : (
                <Text style={styles.publishBtnText}>نشر الآن</Text>
              )}
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  cover: { height: 210, alignItems: "center", justifyContent: "flex-end", paddingBottom: 16 },
  coverHint: { fontSize: 13, marginTop: 4, fontFamily: "Inter_400Regular" },
  avatarSection: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", paddingHorizontal: 18, marginTop: -46, marginBottom: 14 },
  avatarWrapper: { position: "relative" },
  avatarEditBadge: { position: "absolute", bottom: 0, right: 0, width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: "#0A0A0A" },
  editBtn: { flexDirection: "row", alignItems: "center", borderWidth: 1.5, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 8, gap: 5 },
  editBtnText: { fontSize: 13, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  infoSection: { paddingHorizontal: 18, gap: 9 },
  nameRow: { flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" },
  displayName: { fontSize: 26, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  adminBadge: { flexDirection: "row", alignItems: "center", gap: 4, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  adminText: { fontSize: 10, fontWeight: "700" as const, letterSpacing: 0.5 },
  titleBadge: { alignSelf: "flex-start", borderWidth: 1, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  titleText: { fontSize: 13, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  username: { fontSize: 15, fontFamily: "Inter_400Regular" },
  bio: { fontSize: 14, lineHeight: 21, fontFamily: "Inter_400Regular" },
  editInput: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, fontFamily: "Inter_400Regular" },
  bioInput: { minHeight: 80, textAlignVertical: "top" },
  saveBtn: { borderRadius: 14, paddingVertical: 14, alignItems: "center" },
  saveBtnText: { fontSize: 16, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  statsRow: { flexDirection: "row", borderWidth: StyleSheet.hairlineWidth, borderRadius: 16, overflow: "hidden", marginTop: 6 },
  statItem: { flex: 1, alignItems: "center", paddingVertical: 14, gap: 4 },
  statDivider: { width: StyleSheet.hairlineWidth },
  statValue: { fontSize: 15, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  statLabel: { fontSize: 11, fontFamily: "Inter_400Regular" },
  coupleCard: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 14, padding: 12, gap: 10, marginTop: 4 },
  coupleInfo: { flex: 1 },
  coupleLabel: { fontSize: 11, fontFamily: "Inter_400Regular" },
  coupleName: { fontSize: 15, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  postsSection: { marginTop: 10, borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 16 },
  postsSectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18, marginBottom: 10 },
  postsSectionTitle: { fontSize: 18, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  createPostBtn: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 14, paddingVertical: 7, borderRadius: 18 },
  createPostBtnText: { fontSize: 13, fontWeight: "700" as const, color: "#000", fontFamily: "Inter_700Bold" },
  noPostsEmpty: { alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 44 },
  noPostsText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  modalOverlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.6)" },
  modalCard: { borderTopLeftRadius: 24, borderTopRightRadius: 24, borderWidth: 1, padding: 20, gap: 16 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  modalTitle: { fontSize: 20, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  imagePicker: { borderWidth: 1.5, borderRadius: 16, borderStyle: "dashed", overflow: "hidden", minHeight: 140 },
  imagePreview: { width: "100%", height: 200 },
  imagePickerEmpty: { alignItems: "center", justifyContent: "center", gap: 8, padding: 32 },
  imagePickerText: { fontSize: 14, fontFamily: "Inter_400Regular" },
  captionInputModal: { borderWidth: 1, borderRadius: 12, padding: 14, fontSize: 15, fontFamily: "Inter_400Regular", minHeight: 80, textAlignVertical: "top" },
  publishBtn: { borderRadius: 14, paddingVertical: 14, alignItems: "center" },
  publishBtnText: { fontSize: 16, fontWeight: "700" as const, color: "#000", fontFamily: "Inter_700Bold" },
});
