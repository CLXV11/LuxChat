/**
 * Main tab bar — each tab has its own vibrant accent color.
 */
import { BlurView } from "expo-blur";
import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import React from "react";
import { Platform, StyleSheet, View } from "react-native";
import { useColors } from "@/hooks/useColors";

// Each tab has its own vivid color
const TAB_COLORS = {
  chats: "#00CFFF",      // cyan
  discover: "#9B59B6",   // purple
  feed: "#FF4D6D",       // red-pink
  profile: "#FF6B9D",    // pink
};

export default function TabLayout() {
  const colors = useColors();
  const isIOS = Platform.OS === "ios";

  return (
    <Tabs
      screenOptions={{
        tabBarInactiveTintColor: "#444444",
        headerShown: false,
        tabBarStyle: {
          position: "absolute",
          backgroundColor: isIOS ? "transparent" : "#0D0D0D",
          borderTopWidth: 1,
          borderTopColor: "#1A1A1A",
          elevation: 0,
          ...(Platform.OS === "web" ? { height: 84 } : {}),
        },
        tabBarBackground: () =>
          isIOS ? (
            <BlurView intensity={90} tint="dark" style={StyleSheet.absoluteFill} />
          ) : (
            <View style={[StyleSheet.absoluteFill, { backgroundColor: "#0D0D0D" }]} />
          ),
        tabBarLabelStyle: {
          fontSize: 10,
          fontFamily: "Inter_600SemiBold",
          marginBottom: 2,
        },
      }}
    >
      <Tabs.Screen
        name="chats"
        options={{
          title: "المحادثات",
          tabBarActiveTintColor: TAB_COLORS.chats,
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="chatbubbles" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="discover"
        options={{
          title: "اكتشف",
          tabBarActiveTintColor: TAB_COLORS.discover,
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="people" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="feed"
        options={{
          title: "المنشورات",
          tabBarActiveTintColor: TAB_COLORS.feed,
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="images" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: "بروفايلي",
          tabBarActiveTintColor: TAB_COLORS.profile,
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="person-circle" size={size} color={color} />
          ),
        }}
      />
      {/* Redirect only — hidden from tab bar */}
      <Tabs.Screen name="index" options={{ href: null }} />
    </Tabs>
  );
}
