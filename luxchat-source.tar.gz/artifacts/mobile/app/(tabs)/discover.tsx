/**
 * Discover — search and find users, send friend requests.
 */
import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  Platform,
  Alert,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { useSocket } from "@/contexts/SocketContext";
import { UserAvatar } from "@/components/UserAvatar";
import { api } from "@/lib/api";

interface DiscoverUser {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  isVerified: boolean;
  title: string | null;
  profileBorder: string | null;
}

export default function DiscoverScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { token, user } = useAuth();
  const { onlineUsers } = useSocket();

  const [query, setQuery] = useState("");
  const [users, setUsers] = useState<DiscoverUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [pendingRequests, setPendingRequests] = useState<Set<string>>(new Set());

  const loadUsers = useCallback(
    async (q: string) => {
      if (!token || !q.trim()) {
        setUsers([]);
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        const data = await api.users.list(token, q.trim());
        setUsers((data as DiscoverUser[]).filter((u) => u.id !== user?.id));
      } finally {
        setLoading(false);
      }
    },
    [token, user?.id],
  );

  useEffect(() => {
    // Don't load on mount — wait for user to type
    setLoading(false);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      void loadUsers(query);
    }, 400);
    return () => clearTimeout(timer);
  }, [query, loadUsers]);

  const sendFriendRequest = async (toUserId: string) => {
    if (!token) return;
    try {
      await api.friends.request(token, toUserId);
      setPendingRequests((prev) => new Set([...prev, toUserId]));
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Friend Request Sent", "Your request has been sent!");
    } catch (err) {
      Alert.alert(
        "Error",
        err instanceof Error ? err.message : "Failed to send request",
      );
    }
  };

  const topPad = insets.top + (Platform.OS === "web" ? 67 : 0);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 16, backgroundColor: colors.card, borderBottomColor: colors.border }]}>
        <Text style={[styles.title, { color: colors.foreground }]}>Discover</Text>
        <View style={[styles.searchBar, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
          <Ionicons name="search-outline" size={18} color={colors.mutedForeground} />
          <TextInput
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="ابحث بالاسم الدقيق..."
            placeholderTextColor={colors.mutedForeground}
            value={query}
            onChangeText={setQuery}
            autoCapitalize="none"
            autoCorrect={false}
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={() => setQuery("")}>
              <Ionicons name="close-circle" size={18} color={colors.mutedForeground} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator color={colors.gold} size="large" />
        </View>
      ) : (
        <FlatList
          data={users}
          keyExtractor={(u) => u.id}
          contentContainerStyle={{ paddingBottom: insets.bottom + 90 }}
          renderItem={({ item }) => {
            const isOnline = onlineUsers.includes(item.id);
            const isPending = pendingRequests.has(item.id);
            return (
              <TouchableOpacity
                style={[styles.userRow, { borderBottomColor: colors.border }]}
                onPress={() => router.push(`/user/${item.id}`)}
                activeOpacity={0.7}
              >
                <UserAvatar
                  uri={item.avatar}
                  size={50}
                  isVerified={item.isVerified}
                  isOnline={isOnline}
                  profileBorder={item.profileBorder}
                  showOnline
                />
                <View style={styles.userInfo}>
                  <View style={styles.nameRow}>
                    <Text style={[styles.displayName, { color: colors.foreground }]}>
                      {item.displayName}
                    </Text>
                    {item.isVerified && (
                      <Ionicons name="checkmark-circle" size={14} color={colors.verifiedBlue} style={{ marginLeft: 4 }} />
                    )}
                  </View>
                  {item.title && (
                    <Text style={[styles.titleText, { color: colors.gold }]}>{item.title}</Text>
                  )}
                  <Text style={[styles.username, { color: colors.mutedForeground }]}>
                    @{item.username} · {isOnline ? "Online" : "Offline"}
                  </Text>
                </View>
                <TouchableOpacity
                  style={[
                    styles.addBtn,
                    {
                      backgroundColor: isPending ? colors.surface : colors.gold,
                      borderColor: isPending ? colors.border : colors.gold,
                    },
                  ]}
                  onPress={() => !isPending && sendFriendRequest(item.id)}
                  disabled={isPending}
                >
                  <Ionicons
                    name={isPending ? "checkmark" : "person-add-outline"}
                    size={18}
                    color={isPending ? colors.mutedForeground : colors.primaryForeground}
                  />
                </TouchableOpacity>
              </TouchableOpacity>
            );
          }}
          ListEmptyComponent={
            <View style={styles.empty}>
              {query.trim() ? (
                <>
                  <Ionicons name="person-outline" size={48} color={colors.mutedForeground} />
                  <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                    لا يوجد مستخدم بهذا الاسم
                  </Text>
                  <Text style={[styles.emptyHint, { color: colors.mutedForeground }]}>
                    تأكد من كتابة الاسم الدقيق
                  </Text>
                </>
              ) : (
                <>
                  <Ionicons name="search-outline" size={48} color={colors.mutedForeground} />
                  <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                    ابحث عن صديق
                  </Text>
                  <Text style={[styles.emptyHint, { color: colors.mutedForeground }]}>
                    اكتب اسم المستخدم الدقيق للعثور عليه
                  </Text>
                </>
              )}
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 16,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: "700" as const,
    fontFamily: "Inter_700Bold",
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  loadingContainer: { flex: 1, alignItems: "center", justifyContent: "center" },
  userRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 14,
  },
  userInfo: { flex: 1, gap: 2 },
  nameRow: { flexDirection: "row", alignItems: "center" },
  displayName: {
    fontSize: 16,
    fontWeight: "600" as const,
    fontFamily: "Inter_600SemiBold",
  },
  titleText: {
    fontSize: 12,
    fontWeight: "600" as const,
    fontFamily: "Inter_600SemiBold",
  },
  username: { fontSize: 13, fontFamily: "Inter_400Regular" },
  addBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  empty: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingTop: 80,
    gap: 12,
  },
  emptyText: { fontSize: 16, fontFamily: "Inter_400Regular" },
  emptyHint: { fontSize: 13, fontFamily: "Inter_400Regular", textAlign: "center", paddingHorizontal: 40 },
});
