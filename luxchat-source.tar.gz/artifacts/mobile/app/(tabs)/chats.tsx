/**
 * Chats screen — Friends inbox + People you follow section.
 */
import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  FlatList,
  ActivityIndicator,
  Platform,
  RefreshControl,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useFocusEffect, useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { useSocket } from "@/contexts/SocketContext";
import { UserAvatar } from "@/components/UserAvatar";
import { api } from "@/lib/api";

interface UserBasic {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  isVerified: boolean;
  isAdmin?: boolean;
  title: string | null;
  profileBorder: string | null;
}

interface FriendEntry {
  requestId: string;
  user: UserBasic;
  status?: string;
}

export default function ChatsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { token, user } = useAuth();
  const { onlineUsers } = useSocket();

  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<UserBasic[]>([]);
  const [searching, setSearching] = useState(false);
  const [friends, setFriends] = useState<FriendEntry[]>([]);
  const [incomingRequests, setIncomingRequests] = useState<FriendEntry[]>([]);
  const [following, setFollowing] = useState<UserBasic[]>([]);
  const [loadingFriends, setLoadingFriends] = useState(false);
  const [loadingFollowing, setLoadingFollowing] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    if (!token) return;
    setLoadingFriends(true);
    setLoadingFollowing(true);
    try {
      const [friendsData, followingData] = await Promise.all([
        api.friends.list(token),
        api.follows.myFollowing(token),
      ]);
      const fd = friendsData as { friends: FriendEntry[]; incoming: FriendEntry[] };
      setFriends(fd.friends ?? []);
      setIncomingRequests(fd.incoming ?? []);
      setFollowing(followingData as UserBasic[]);
    } catch {}
    finally {
      setLoadingFriends(false);
      setLoadingFollowing(false);
    }
  }, [token]);

  useFocusEffect(useCallback(() => { void loadData(); }, [loadData]));

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleSearch = async (q: string) => {
    setSearchQuery(q);
    if (!q.trim() || !token) { setSearchResults([]); return; }
    setSearching(true);
    try {
      const res = await api.users.list(token, q);
      setSearchResults(res as UserBasic[]);
    } catch {}
    finally { setSearching(false); }
  };

  const acceptFriend = async (requestId: string) => {
    if (!token) return;
    try {
      await api.friends.accept(token, requestId);
      setIncomingRequests((prev) => prev.filter((r) => r.requestId !== requestId));
      await loadData();
    } catch {}
  };

  const openChat = (userId: string) => router.push(`/chat/${userId}`);

  const topPad = insets.top + (Platform.OS === "web" ? 67 : 0);
  const botPad = insets.bottom + (Platform.OS === "web" ? 34 : 0);

  const allOnline = following.filter((u) => onlineUsers.includes(u.id));
  const allOffline = following.filter((u) => !onlineUsers.includes(u.id));
  const sortedFollowing = [...allOnline, ...allOffline];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <LinearGradient
        colors={["#0D0021", "#0A0A1E", colors.background]}
        style={[styles.header, { paddingTop: topPad + 6 }]}
      >
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>الرسائل</Text>
        <TouchableOpacity onPress={() => router.push("/global-chat" as never)}>
          <View style={[styles.globalChatBtn, { backgroundColor: colors.gold + "22", borderColor: colors.gold }]}>
            <Ionicons name="earth" size={15} color={colors.gold} />
            <Text style={[styles.globalChatText, { color: colors.gold }]}>الدردشة العامة</Text>
          </View>
        </TouchableOpacity>
      </LinearGradient>

      <ScrollView
        contentContainerStyle={{ paddingBottom: botPad + 20 }}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={colors.gold} />}
      >
        {/* Search bar */}
        <View style={[styles.searchContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Ionicons name="search" size={18} color={colors.mutedForeground} />
          <TextInput
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="ابحث عن مستخدم..."
            placeholderTextColor={colors.mutedForeground}
            value={searchQuery}
            onChangeText={handleSearch}
            returnKeyType="search"
          />
          {searching && <ActivityIndicator size="small" color={colors.gold} />}
        </View>

        {/* Search results */}
        {searchQuery.trim().length > 0 && (
          <View style={[styles.section, { borderBottomColor: colors.border }]}>
            {searchResults.length === 0 && !searching ? (
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>لا توجد نتائج</Text>
            ) : (
              searchResults.map((u) => (
                <UserRow key={u.id} user={u} isOnline={onlineUsers.includes(u.id)} colors={colors} onPress={() => openChat(u.id)} />
              ))
            )}
          </View>
        )}

        {/* Incoming friend requests */}
        {incomingRequests.length > 0 && (
          <View style={styles.section}>
            <SectionHeader title={`طلبات الصداقة (${incomingRequests.length})`} colors={colors} />
            {incomingRequests.filter((req) => !!req.user).map((req) => (
              <View key={req.requestId} style={[styles.requestRow, { borderBottomColor: colors.border }]}>
                <UserAvatar uri={req.user?.avatar} size={44} isVerified={req.user?.isVerified} profileBorder={req.user?.profileBorder} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.reqName, { color: colors.foreground }]}>{req.user?.displayName ?? "مستخدم"}</Text>
                  <Text style={[styles.reqUser, { color: colors.mutedForeground }]}>@{req.user?.username ?? "—"}</Text>
                </View>
                <TouchableOpacity style={[styles.acceptBtn, { backgroundColor: colors.gold }]} onPress={() => acceptFriend(req.requestId)}>
                  <Ionicons name="checkmark" size={16} color={colors.primaryForeground} />
                  <Text style={[styles.acceptText, { color: colors.primaryForeground }]}>قبول</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        )}

        {/* Friends */}
        {(loadingFriends ? true : friends.length > 0) && (
          <View style={styles.section}>
            <SectionHeader title="الأصدقاء" colors={colors} />
            {loadingFriends ? (
              <ActivityIndicator color={colors.gold} style={{ marginVertical: 20 }} />
            ) : friends.length === 0 ? (
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>لا يوجد أصدقاء بعد</Text>
            ) : (
              friends.filter((f) => !!f.user).map((f) => (
                <UserRow key={f.requestId ?? f.user.id} user={f.user} isOnline={onlineUsers.includes(f.user.id)} colors={colors} onPress={() => openChat(f.user.id)} />
              ))
            )}
          </View>
        )}

        {/* People You Follow */}
        <View style={styles.section}>
          <SectionHeader title="ممن تتابعهم" colors={colors} />
          {loadingFollowing ? (
            <ActivityIndicator color={colors.gold} style={{ marginVertical: 20 }} />
          ) : sortedFollowing.length === 0 ? (
            <View style={styles.emptySection}>
              <Ionicons name="people-outline" size={38} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>لا تتابع أحداً بعد</Text>
              <Text style={[styles.emptySubText, { color: colors.mutedForeground }]}>ابحث عن مستخدمين واتبعهم لتظهروا هنا</Text>
            </View>
          ) : (
            sortedFollowing.map((u) => (
              <UserRow key={u.id} user={u} isOnline={onlineUsers.includes(u.id)} colors={colors} onPress={() => openChat(u.id)} showOnlinePill />
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
}

function SectionHeader({ title, colors }: { title: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={styles.sectionHeader}>
      <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>{title}</Text>
      <View style={[styles.sectionLine, { backgroundColor: colors.border }]} />
    </View>
  );
}

function UserRow({
  user,
  isOnline,
  colors,
  onPress,
  showOnlinePill = false,
}: {
  user: UserBasic;
  isOnline: boolean;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
  showOnlinePill?: boolean;
}) {
  return (
    <TouchableOpacity style={[styles.userRow, { borderBottomColor: colors.border }]} onPress={onPress} activeOpacity={0.7}>
      <UserAvatar uri={user.avatar} size={46} isVerified={user.isVerified} isOnline={isOnline} profileBorder={user.profileBorder} showOnline />
      <View style={{ flex: 1 }}>
        <View style={styles.userNameRow}>
          <Text style={[styles.userName, { color: colors.foreground }]}>{user.displayName}</Text>
          {user.isVerified && <Ionicons name="checkmark-circle" size={13} color={colors.verifiedBlue} />}
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <Text style={[styles.userHandle, { color: colors.mutedForeground }]}>@{user.username}</Text>
          {isOnline && showOnlinePill && (
            <View style={[styles.onlineDot, { backgroundColor: colors.onlineGreen }]} />
          )}
        </View>
      </View>
      <Ionicons name="chevron-forward" size={18} color={colors.mutedForeground} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 18, paddingBottom: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  headerTitle: { fontSize: 26, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  globalChatBtn: { flexDirection: "row", alignItems: "center", gap: 5, borderWidth: 1, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6 },
  globalChatText: { fontSize: 13, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  searchContainer: { flexDirection: "row", alignItems: "center", gap: 10, margin: 14, borderRadius: 14, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 10 },
  searchInput: { flex: 1, fontSize: 15, fontFamily: "Inter_400Regular" },
  section: { paddingHorizontal: 16, paddingBottom: 8, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "#252525", marginBottom: 4 },
  sectionHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 8, marginTop: 8 },
  sectionTitle: { fontSize: 12, fontWeight: "600" as const, textTransform: "uppercase", letterSpacing: 0.8, fontFamily: "Inter_600SemiBold" },
  sectionLine: { flex: 1, height: StyleSheet.hairlineWidth },
  emptySection: { alignItems: "center", gap: 6, paddingVertical: 28 },
  emptyText: { textAlign: "center", fontSize: 14, fontFamily: "Inter_400Regular", paddingVertical: 14 },
  emptySubText: { fontSize: 12, textAlign: "center", fontFamily: "Inter_400Regular" },
  userRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 11, borderBottomWidth: StyleSheet.hairlineWidth },
  userNameRow: { flexDirection: "row", alignItems: "center", gap: 5 },
  userName: { fontSize: 15, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  userHandle: { fontSize: 13, fontFamily: "Inter_400Regular" },
  adminBadgeTiny: { borderRadius: 4, padding: 2 },
  onlineDot: { width: 7, height: 7, borderRadius: 3.5 },
  requestRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth },
  reqName: { fontSize: 14, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  reqUser: { fontSize: 12, fontFamily: "Inter_400Regular" },
  acceptBtn: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16 },
  acceptText: { fontSize: 13, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
});
