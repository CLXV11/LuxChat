/**
 * AuthContext — manages user session, JWT token, and profile updates.
 * Persists token in AsyncStorage for cross-session auth.
 */
import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
} from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  coverBanner: string | null;
  bio: string;
  coins: number;
  joinedAt: string;
  isVerified: boolean;
  isAdmin: boolean;
  goldBadge: boolean;
  isDeveloper?: boolean;
  title: string | null;
  theme: string;
  profileBorder: string | null;
  couplePartnerId: string | null;
}

interface AuthState {
  token: string | null;
  user: UserProfile | null;
  isLoading: boolean;
}

interface AuthContextValue extends AuthState {
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string, displayName: string) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (updates: Partial<UserProfile>) => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);
const API_BASE = `https://${process.env["EXPO_PUBLIC_DOMAIN"]}/api`;

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>({ token: null, user: null, isLoading: true });

  useEffect(() => {
    void (async () => {
      try {
        const token = await AsyncStorage.getItem("@luxchat_token");
        if (token) {
          // Verify token is still valid against the server
          const res = await fetch(`${API_BASE}/users/me`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (res.ok) {
            const user = (await res.json()) as UserProfile;
            await AsyncStorage.setItem("@luxchat_user", JSON.stringify(user));
            setState({ token, user, isLoading: false });
          } else {
            // Token invalid or expired — clear everything and force re-login
            await AsyncStorage.multiRemove(["@luxchat_token", "@luxchat_user"]);
            setState({ token: null, user: null, isLoading: false });
          }
        } else {
          setState((s) => ({ ...s, isLoading: false }));
        }
      } catch {
        // Network error — restore cached session optimistically
        try {
          const token = await AsyncStorage.getItem("@luxchat_token");
          const userJson = await AsyncStorage.getItem("@luxchat_user");
          if (token && userJson) {
            setState({ token, user: JSON.parse(userJson) as UserProfile, isLoading: false });
          } else {
            setState((s) => ({ ...s, isLoading: false }));
          }
        } catch {
          setState((s) => ({ ...s, isLoading: false }));
        }
      }
    })();
  }, []);

  const saveSession = async (token: string, user: UserProfile) => {
    await AsyncStorage.setItem("@luxchat_token", token);
    await AsyncStorage.setItem("@luxchat_user", JSON.stringify(user));
  };

  const login = useCallback(async (username: string, password: string) => {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    if (!res.ok) {
      const err = (await res.json()) as { error: string };
      throw new Error(err.error);
    }
    const data = (await res.json()) as { token: string; user: UserProfile };
    await saveSession(data.token, data.user);
    setState({ token: data.token, user: data.user, isLoading: false });
  }, []);

  const register = useCallback(async (username: string, password: string, displayName: string) => {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password, displayName }),
    });
    if (!res.ok) {
      const err = (await res.json()) as { error: string };
      throw new Error(err.error);
    }
    const data = (await res.json()) as { token: string; user: UserProfile };
    await saveSession(data.token, data.user);
    setState({ token: data.token, user: data.user, isLoading: false });
  }, []);

  const logout = useCallback(async () => {
    await AsyncStorage.multiRemove(["@luxchat_token", "@luxchat_user"]);
    setState({ token: null, user: null, isLoading: false });
  }, []);

  const updateUser = useCallback((updates: Partial<UserProfile>) => {
    setState((s) => {
      if (!s.user) return s;
      const updated = { ...s.user, ...updates };
      void AsyncStorage.setItem("@luxchat_user", JSON.stringify(updated));
      return { ...s, user: updated };
    });
  }, []);

  const refreshUser = useCallback(async () => {
    if (!state.token) return;
    try {
      const res = await fetch(`${API_BASE}/users/me`, {
        headers: { Authorization: `Bearer ${state.token}` },
      });
      if (res.ok) {
        const user = (await res.json()) as UserProfile;
        setState((s) => ({ ...s, user }));
        await AsyncStorage.setItem("@luxchat_user", JSON.stringify(user));
      } else if (res.status === 401) {
        // Token invalidated — auto logout
        await AsyncStorage.multiRemove(["@luxchat_token", "@luxchat_user"]);
        setState({ token: null, user: null, isLoading: false });
      }
    } catch {}
  }, [state.token]);

  return (
    <AuthContext.Provider value={{ ...state, login, register, logout, updateUser, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
