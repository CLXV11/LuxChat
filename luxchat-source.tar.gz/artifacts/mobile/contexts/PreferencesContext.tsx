/**
 * Local app preferences shared by the drawer and the rest of the app.
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

export type Language = "ar" | "en";
export type Theme = "dark" | "light";

interface Preferences {
  language: Language;
  theme: Theme;
  notifications: boolean;
  soundEnabled: boolean;
}

interface PreferencesContextValue extends Preferences {
  setLanguage: (language: Language) => void;
  setTheme: (theme: Theme) => void;
  setNotifications: (enabled: boolean) => void;
  setSoundEnabled: (enabled: boolean) => void;
}

const defaults: Preferences = {
  language: "ar",
  theme: "dark",
  notifications: true,
  soundEnabled: true,
};

const STORAGE_KEY = "@luxchat_preferences";
const PreferencesContext = createContext<PreferencesContextValue | null>(null);

export function PreferencesProvider({ children }: { children: React.ReactNode }) {
  const [preferences, setPreferences] = useState<Preferences>(defaults);

  useEffect(() => {
    void AsyncStorage.getItem(STORAGE_KEY).then((stored) => {
      if (!stored) return;
      try {
        setPreferences((current) => ({ ...current, ...(JSON.parse(stored) as Partial<Preferences>) }));
      } catch {
        // Ignore malformed local preferences and keep safe defaults.
      }
    });
  }, []);

  const update = useCallback((changes: Partial<Preferences>) => {
    setPreferences((current) => {
      const next = { ...current, ...changes };
      void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const setLanguage = useCallback((language: Language) => update({ language }), [update]);
  const setTheme = useCallback((theme: Theme) => update({ theme }), [update]);
  const setNotifications = useCallback((notifications: boolean) => update({ notifications }), [update]);
  const setSoundEnabled = useCallback((soundEnabled: boolean) => update({ soundEnabled }), [update]);

  return (
    <PreferencesContext.Provider
      value={{ ...preferences, setLanguage, setTheme, setNotifications, setSoundEnabled }}
    >
      {children}
    </PreferencesContext.Provider>
  );
}

export function usePreferences() {
  const context = useContext(PreferencesContext);
  if (!context) throw new Error("usePreferences must be used within PreferencesProvider");
  return context;
}