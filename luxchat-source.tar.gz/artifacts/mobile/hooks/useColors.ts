/**
 * useColors — always returns the dark luxury LuxChat palette.
 * LuxChat is dark-only — no light mode.
 */
import colors from "@/constants/colors";
import { usePreferences } from "@/contexts/PreferencesContext";

export function useColors() {
  const { theme } = usePreferences();
  return {
    ...(theme === "light" ? colors.light : colors.dark),
    radius: colors.radius,
  };
}
