# LuxChat

A full-stack real-time chat mobile app with a dark luxury theme (deep black + #FFD700 gold), built with Expo + Express + Socket.io.

## Run & Operate

- API server auto-runs via workflow at port 8080
- Expo mobile app auto-runs via workflow at port 18115
- `pnpm --filter @workspace/api-server run typecheck` — typecheck API server
- `pnpm --filter @workspace/mobile run typecheck` — typecheck mobile app
- Required env: `SESSION_SECRET` — JWT secret (already set as Replit secret)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- **Backend**: Express 5 + Socket.io 4 + `node:sqlite` (built-in) + bcryptjs + multer
- **Mobile**: Expo SDK 54, Expo Router v6, React Native
- **Auth**: JWT tokens, 30-day expiry
- **Real-time**: Socket.io at path `/api/socket.io`

## Where things live

- `artifacts/api-server/src/db/index.ts` — SQLite schema (node:sqlite)
- `artifacts/api-server/src/middleware/auth.ts` — JWT auth
- `artifacts/api-server/src/routes/` — all REST routes
- `artifacts/api-server/src/socket/index.ts` — Socket.io handlers
- `artifacts/api-server/data/luxchat.db` — SQLite database file
- `artifacts/api-server/uploads/` — uploaded media files
- `artifacts/mobile/constants/colors.ts` — LuxChat dark luxury design tokens
- `artifacts/mobile/contexts/AuthContext.tsx` — auth state + JWT
- `artifacts/mobile/contexts/SocketContext.tsx` — Socket.io connection
- `artifacts/mobile/lib/api.ts` — typed REST API client
- `artifacts/mobile/app/` — all screens (Expo Router)

## API Routes

- `POST /api/auth/register` — create account
- `POST /api/auth/login` — login, returns JWT
- `GET /api/users` — list/search users
- `GET /api/users/me` — own profile
- `PUT /api/users/me` — update profile
- `POST /api/users/me/avatar` — upload avatar
- `POST /api/users/me/cover` — upload cover banner
- `POST /api/users/upload/media` — upload chat media
- `GET /api/messages/global` — global chat history
- `GET /api/messages/room/:roomId` — private room history
- `POST /api/messages/:id/reaction` — react to message
- `GET /api/coins` — coin balance
- `POST /api/coins/redeem` — redeem promo code
- `GET /api/shop/items` — VIP shop items
- `POST /api/shop/purchase` — buy VIP item
- `GET /api/friends` — friend list + pending requests
- `POST /api/friends/request` — send friend request
- `PUT /api/friends/:id/accept` — accept request
- `DELETE /api/friends/:id` — remove friend
- `GET /api/couple` — couple status
- `POST /api/couple/request` — send couple request
- `PUT /api/couple/:id/accept` — accept couple request
- `DELETE /api/couple` — break up
- `POST /api/follows/:id` — follow user
- `DELETE /api/follows/:id` — unfollow user
- `GET /api/follows/:id/stats` — followers/following count + isFollowing
- `GET /api/follows/me/stats` — own follower stats
- `GET /api/follows/:id/followers` — public list of followers
- `GET /api/follows/:id/following` — public list of people a user follows
- `GET /api/follows/me/followers` — own followers list
- `GET /api/follows/me/following` — own following list
- `POST /api/posts` — create post (multipart: image + caption)
- `GET /api/posts/feed` — global posts feed
- `GET /api/posts/user/:id` — posts by user
- `POST /api/posts/:id/like` — toggle like
- `DELETE /api/posts/:id` — delete own post (admin can delete any)
- `GET /api/posts/:id/comments` — get comments on a post
- `POST /api/posts/:id/comments` — add a comment
- `DELETE /api/posts/:id/comments/:commentId` — delete a comment
- `DELETE /api/messages/:id` — delete message for all (own or admin)
- `PUT /api/messages/:id` — edit own message

## Socket.io Events

- **Client → Server**: `join_room`, `leave_room`, `send_message`, `typing`, `add_reaction`, `delete_message`, `edit_message`
- **Server → Client**: `new_message`, `reaction_updated`, `typing`, `online_users`, `message_deleted`, `message_edited`
- Socket path: `/api/socket.io`

## Promo Codes (server-side secret)

- `DEVMASTER999` → 99,999,999 coins
- `VIP5000` → 5,000 coins
- `DIAMOND8888` → 8,888 coins
- `ROYAL3000` → 3,000 coins
- `BONUS2000` → 2,000 coins
- `GOLD1000` → 1,000 coins
- `SECRET750` → 750 coins
- `LUCKY500` → 500 coins
- `SPECIAL1200` → 1,200 coins
- `LUXCHAT100` → 100 coins
- `123654` → 100,000 متابع (followersBoost)
- `FGR` → إطار التنين الذهبي (profile_border_dragon_gold)
- `LUXADMIN2026` → منح صلاحيات Admin

## VIP Shop Items

| ID | Name | Price | Type |
|---|---|---|---|
| verified | Verified Badge | 500 | badge |
| legendary_theme | Legendary Theme | 1000 | theme |
| profile_border_gold | Gold Border | 800 | border |
| profile_border_diamond | Diamond Border | 1500 | border |
| profile_border_dragon_gold | Dragon Frame إطار التنين | 5000 | border |
| profile_border_shield | Shield Frame درع البروفايل | 2000 | border |
| title_moderator | مشرف | 300 | title |
| title_leader | قائد | 500 | title |
| title_emperor | إمبراطور | 1000 | title |

## Architecture Decisions

- **node:sqlite** (built-in Node 24) used instead of better-sqlite3 to avoid native binary compilation issues in the Replit environment.
- **Socket.io path** set to `/api/socket.io` so requests route through the shared proxy's `/api` prefix without rewriting.
- **Private chat room IDs** are two user IDs sorted alphabetically and joined with `_` — e.g. `abc_xyz` — so both users compute the same room ID independently.
- **Promo codes** stored exclusively server-side (not in DB) so they can't be extracted from client code.
- **JWT tokens** are 30-day expiry; stored in AsyncStorage on the mobile client.

## Gotchas

- Run `pnpm approve-builds` if better-sqlite3 (unused) complains; we use `node:sqlite` instead.
- Socket.io client must use `path: '/api/socket.io'` — the shared proxy routes `/api` to the API server.
- `req.params["key"]` must always be cast `as string` when passed to `node:sqlite` statement methods.
- Uploaded files are served as `/api/uploads/<filename>` (static via Express).

## User Preferences

_Populate as you build — explicit user instructions worth remembering across sessions._
